PROGRAM Computer_Usage_Records
!-------------------------------------------------------------
! Program to read id numbers from the kyeboard, search a file
! computer usage records to determine if this is the number 
! of a computer user, and if so, retrieve and display 
! information about that user.  Identifiers used are:
!  Computer_Usage_Info	: name of a derived type
!  FileName		: name of computer usage file
!  OpenStatus		: status variable for OPEN
!  InputStatus          : status variable for READ
!  User			: structure of type Computer_Usage_Info
!  InputNumber		: an id number entered from the keyboard
!  UserNumber		: an id number in the computer usage file
!  Found		: indicates if InputNumber matches some
!                         user's id number in the file
!
!Input (keyboard) : InputNumber
!Input (file) : UserNumber and computer usage record assigned
!               to User
!Output (screen) : User's id number, name, and percentage of
!                  computer recources remaining or a message
!                  that the id number was not found in the file
!---------------------------------------------------------------

IMPLICIT NONE

TYPE Computer_Usage_Info
   CHARACTER(15) :: LastName, FirstName
   INTEGER :: IdNumber
   CHARACTER(6) Password
   INTEGER :: ResourceLimit
   REAL :: ResourceUsed
END TYPE Computer_Usage_Info

CHARACTER(20) :: FileName
TYPE(Computer_Usage_Info) :: User
INTEGER :: OpenStatus, InputStatus, InputNumber, UserNumber
LOGICAL :: Found

! Get name of file and open it for input
WRITE(*, '(1X, A)', ADVANCE = "NO") "Enter name of computer usage file: "
READ *, FileName
OPEN(UNIT=10, FILE = FileName, STATUS = "OLD", IOSTAT = OpenStatus)
IF(OpenStatus > 0) STOP "*** Cannot open file ***"

! Read id numbers and search file for matches
DO
   PRINT *
   WRITE(*, '(1X, A)', ADVANCE="NO") "Enter id number (0 to stop):"
   READ *, InputNumber
   IF (InputNumber == 0) EXIT
   ! If no more id numbers to process, terminate repetition
   
   ! Otherwise search file for id number
   DO
     READ(10, '(T31, I5)', IOSTAT = InputStatus) UserNumber
     IF (InputStatus > 0) STOP "*** Input error ***"
     IF (InputStatus < 0) EXIT ! end of file
     ! If end of file reached, stop searching
  
     ! Else check if ids match
     Found = (InputNumber == UserNumber)
     IF (Found) EXIT
   END DO

   ! Id found -- backup in the file, read the user info
   ! and display the required information
   IF(Found) THEN
      BACKSPACE 10   ! by one line
      READ (10, '(2A15, 10X, I4, F5.2)') &
          User%LastName, User%FirstName, &
          User%ResourceLimit, User%ResourceUsed
      PRINT &
        '(1X, I5, 1X, 2A / 1X, "has used", F5.1, "% of resources")', &
        UserNumber, User%FirstName, User%LastName, &
        100.0 * (User%ResourceLimit - User%ResourceUsed) & 
        / User%ResourceLimit
   ELSE
      PRINT *, InputNumber, " not found"
   END IF

   ! Rewind file and get new id number
   REWIND 10
END DO

END PROGRAM Computer_Usage_Records
