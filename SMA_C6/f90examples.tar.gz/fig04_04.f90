PROGRAM Temperature_Conversion_3
!-----------------------------------------------------------
! Program to convert temperatures on the Celsius scale to the
! corresponding temperatures on the Fahrenheit scale.  A 
! query-controlled input loop is used to process several
! temperatures.
! Variables use are:
! Celsius : temperature on the Celsius scale
! Fahrenheit : temperature on the Fahrenheit scale
! Response : user's response to the more-data query
!
! Input : Celsius, Response
! Output : Fahrenheit
  IMPLICIT NONE
  REAL :: Celsius, Fahrenheit
  CHARACTER(1) :: Response

  ! Query-controlled loop to process temperature
  DO
    ! Obtain Celsius temperature
    PRINT *, "Enter temperature in degrees Celsius:"
    READ *, Celsius
 
    ! Calculate corresponding Fahrenheit temperature
    Fahrenheit = 1.8 * Celsius + 32.0
 
    ! Display temperatures
    PRINT *, Celsius, "degrees Celsius =", &
             Fahrenheit, "degrees Fahrenheit"

    ! Ask usr if there is more data
    PRINT *
    PRINT *, "More temperatures to convert (Y or N)?"
    READ *, Response
    IF (Response == "N") EXIT
  END DO

END PROGRAM Temperature_Conversion_3
