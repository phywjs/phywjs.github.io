PROGRAM Temperature_Conversion_1 
!------------------------------------------------------------- 
! Progrm to convert a temperature on the Celsius scale to the
! corresponding temperature on the Fahrenheit scale.
! Variables used are:
!  Celsius     : temperature on the Celsius scale
!  Fahrenheit  : temperature on the Fahrenheit scale
!
! Input: Celsius
! Output: Fahrenheit
!-------------------------------------------------------------

  IMPLICIT NONE
  REAL :: Celsius, Fahrenheit

  ! Obtain Celsius temperature
  PRINT *, "Enter temperature in degrees Celsius:"
  READ *, Celsius
  
  ! Calculate corresponding Fahrenheit temperature
  Fahrenheit = (9.0/5.0)* Celsius + 32.0

  ! Display temperatures
  PRINT *, Celsius, "degree Celsius = ", & 
           Fahrenheit, "degree Fahrenheit"

END PROGRAM Temperature_Conversion_1
