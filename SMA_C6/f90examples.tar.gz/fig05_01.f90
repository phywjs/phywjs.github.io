PROGRAM Temperature_Volume_Readings
!-------------------------------------------------------------
! Program to read temperatures and volumes from a file
! containing time, temperature, presure, and volume readings
! made by some monitoring device.  The temperature and
! volume measurements are displayed in tabular form, and the 
! average temperature and the average volume are caculated
! and displays.
! Variables used are:
!  FileName	: name of data file
!  OpenStatus	: status variable for OPEN statement
!  InputStatus	: status variable for READ statement
!  Temperature	: temperature recorded
!  Volume	: volume recorded
!  Count	: count of (Temperarure, Volume) pairs
!  SumofTemps	: sum of temperatures
!  SumOfVols	: sum of volumes
!  MeanTemperarure : mean temperature
!  MeanVolume	: mean volume
!
! Input (file)	: collection of temperature and volume readings
! Output (screen): Table of readings, average temperature, and
!                  average volume
!-------------------------------------------------------------
IMPLICIT NONE
INTEGER :: Count = 0, OpenStatus, InputStatus
CHARACTER(20) :: FileName
REAL :: Temperature, Volume, SumOfTemps = 0.0, &
        SumOfVols = 0.0, MeanTemperature, MeanVolume
! Open the file as unit 15.  If successful, set up the
! input and output formats, and display the table heading

WRITE(*, '(1X, A)', ADVANCE = "NO") "Enter name of data file:"
READ *, FileName
OPEN(UNIT=15, FILE=FileName, STATUS="OLD", IOSTAT= OpenStatus)
IF(OpenStatus > 0) STOP "*** Cannot open the file ***"

100 FORMAT(4X, F4.1, T13, F4.1)
110 FORMAT(1X, A11, A10)
120 FORMAT(1X, F8.1, F12.1)

PRINT *
PRINT 110, "Temperature", "Volume"
PRINT 110, "===========", "======"

! While there is more data, read temperatures and volumes,
! display each in the table, and calculate the necessary sums
DO
  READ(UNIT=15, FMT=100, IOSTAT=InputStatus) Temperature, Volume
  IF (InputStatus > 0) STOP "*** Input error ***"
  IF (InputStatus < 0) Exit ! end of file
  PRINT 120, Temperature, Volume
  Count = Count + 1
  SumOfTemps = SumOfTemps + Temperature
  SumOfVols = SumOfVols + Volume
END DO

! Find average temperature and average volume

MeanTemperature = SumOfTemps / REAL(Count)
MeanVolume = SumOfVols / REAL(Count)

PRINT 130, "temperature", MeanTemperature, "Volume", Meanvolume
130 FORMAT(//2(1X, "Average ", A, " is: ", F6.2 /))

CLOSE(15)

END PROGRAM Temperature_Volume_Readings
