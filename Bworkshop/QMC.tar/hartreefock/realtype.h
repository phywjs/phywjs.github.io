/* Header file to define real, SIZE_OF_REAL and Occ_type, State_type, 
   Model_type */

typedef double real;
#define SIZE_OF_REAL 8                               /* must be sizeof(real) */

typedef struct {              /* single particle state energy and occupation */
   real eng;
   int n, m, s;
} Occ_type;

typedef struct {                                   /* many-body wavefunction */
   double Eng;
   int L;
   int S;
   int *ind;                                     /* pointers to spsGlobal[i] */
} State_type;


/* This Model_type structure is used for two kinds of perturbations : (1) 
   double Gaussian peaks/valleys at (r0,0) and (-r0,0) with standard 
   deviation sigma; (2) a cosine ring bump starting from r0 and end at r1, 
   as studied by Devrim A Guclud.  Both of them have magnitude V0.
*/
typedef struct {                 /* A structure to hold the model parameters */
   real omega0;                                          /* zero field omega */
   real omega;                                /* omega =sqrt(omega0^2+B^2/4) */
   real r0;                        /* location of gaussian/start of cos bump */
   real r1;                           /* end  of cos bump perturbation range */
   real sigma2;                            /* variance (sigma^2) of gaussian */
   real V0;                                        /* perturbation amplitude */
   real B;                                                 /* magnetic field */
   real g;                                                   /* Lande factor */
} Model_type;
