/** test the functions in dot.c
    also test constructH() here.
**/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include "realtype.h"

extern Occ_type *spsGlobal;

void read_model_parameters(FILE *fin, FILE *fout);

int find_states(int no_elec, int nex, int fixedLS, int Lin, int Sin,
                 int state_size, State_type *pickedstate);
void constructH(State_type *state, int n, int nelec, real *H);
int get_index(int i, int j, int n);
void init_hash(void);

main()
{
   int i, j, n, no_elec, nex, fixedLS, L, S, state_size;
   State_type *pickedstate;
   real *H;

   read_model_parameters(stdin, stdout);

   printf("enter number of electrons\n");
   scanf("%d", &no_elec);
   printf("enter extra single particle states nex\n");
   scanf("%d", &nex);
   printf("fixed L and S? (1 for yes, 0 for no)\n");
   scanf("%d", &fixedLS);
   if(fixedLS) {
      printf("enter L and S\n");
      scanf("%d%d", &L, &S);
   } else {
      L = 0;
      S = 0;
   }
   printf("enter number of many-body states wanted\n"); 
   scanf("%d", &state_size);

   spsGlobal = (Occ_type *) malloc((no_elec+nex)*sizeof(Occ_type));
   pickedstate = (State_type *) malloc( (state_size)*sizeof(State_type) );
   for(i = 0; i < state_size; ++i) {
      pickedstate[i].ind = (int *) malloc(no_elec*sizeof(int));
   }

   n = find_states(no_elec, nex, fixedLS, L, S, state_size, pickedstate);

   printf("Single particle states are:\n");
   for(i = 0; i < no_elec+nex; ++i) {
      printf("spsGlobal[%d] : %d %d %d  %g\n",
         i, spsGlobal[i].n, spsGlobal[i].m, spsGlobal[i].s, spsGlobal[i].eng);
   }
   printf("The choose many-body states are ");
   printf("(seq, L  S  Eng  (index to spsGlobal):\n");
   for(i = 0; i < n; ++i) {
      printf("%d, %d %d %g, (", i, 
         pickedstate[i].L, pickedstate[i].S, pickedstate[i].Eng);
      for(j = 0; j < no_elec; ++j) {
         printf("%d ", pickedstate[i].ind[j]);
      }
      printf(")\n");
   }

   if(n > 0) {
      init_hash();
      H = (real *) malloc(n*n*sizeof(real));
      constructH(pickedstate, n, no_elec, H);
      printf("The Hamiltonian H is:\n");
      for(i = 0; i < n; ++i) {
         for(j = 0; j < n; ++j) {
            printf("%6g ", H[get_index(i,j,n)]);
         }
         printf("\n");
      }
   }

}
