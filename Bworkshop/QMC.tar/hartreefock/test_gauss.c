/* test the integrals 
*/

#include <stdio.h>
#include <math.h>
#include <assert.h>

#include "realtype.h"

real devrim2D(int n1, int m1, int n2, int m2, int n3, int m3, int n4, int m4);
real qgauss(int n1, int m1, int n2, int m2, real (*g)(int, real) );
real qromberg(int n1, int m1, int n2, int m2, real (*g)(int, real) );
real perturb_matel(int n1, int m1, int n2, int m2);
void read_model_parameters(FILE *fin, FILE *fecho);

real g0(int q, real x)
{
   return 1.0;
}

real g1(int q, real x)
{
   real k, r;

   k = 1.2;
   r = sqrt(x);
   return jn(q, (double) (k*r));
}

int main()
{
   double res, res0, res1, d;
   real k;
   int n1, m1, n2, m2, n3, m3, n4, m4;
   int ni, mi, nj, mj, nk, mk, nl, ml;
   real (*g)(int, real);

   printf("enter n1, m1, n3, m3\n");
   scanf("%d%d%d%d", &n1, &m1, &n3, &m3);

   g = g1;
   res = qgauss(n1, m1, n3, m3, g);
   printf("gauss quadrature = %.15g\n", res);
   res1 = qromberg(n1, m1, n3, m3, g);
   printf("romberg quadrature = %.15g,  dif = %g\n", res1, res1-res);

   read_model_parameters(stdin, stdout);
   res = perturb_matel(n1, m1, n3, m3);
   printf(" <%d %d|dV|%d %d> = %.15g\n", n1, m1, n3, m3, res);

   printf("For devrim2D, enter n2, m2, n4, m4\n");
   scanf("%d%d%d%d", &n2, &m2, &n4, &m4);
   res = devrim2D(n1, m1, n2, m2, n3, m3, n4, m4);
   printf("2D res = %.15g\n", (double) res); 

/***
   printf("testing symmetry\n");

         ni = n1;
         mi = m1;
         nj = n2;
         mj = m2;
         nk = n3;
         mk = m3;
         nl = n4;
         ml = m4;
         res0 = devrim2D(ni, mi, nj, mj, nk, mk, nl, ml);
         printf("%.16g\n", res0);
         res = devrim2D(nj, mj, ni, mi, nl, ml, nk, mk); 
         printf("%.16g\n", res);
         assert( fabs(res-res0) < 1.e-9);
         res = devrim2D(nk, mk, nl, ml, ni, mi, nj, mj); 
         printf("%.16g\n", res);
         assert( fabs(res-res0) < 1.e-9);
         res = devrim2D(nl, ml, nk, mk, nj, mj, ni, mi);
         printf("%.16g\n", res);
         assert( fabs(res-res0) < 1.e-9);

   printf("symmetry test past\n");
***/
   return 0;
}
