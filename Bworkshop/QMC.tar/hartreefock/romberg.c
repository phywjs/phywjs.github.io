/* Romberg Integration from "Numerical Recipes in C", page 140, 137, and 109.
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include "realtype.h"

/* polynomial interpolation.
 */
void polint(real xa[], real ya[], int n, real x, real *y, real *dy)
{
   int i, m, ns = 1;
   real den, dif, dift, ho, hp, w;
   real *c, *d;
   
   dif = fabs(x-xa[1]);
   c = (real *) malloc((n+1)*sizeof(real));
   d = (real *) malloc((n+1)*sizeof(real));
   assert(c != NULL);
   assert(d != NULL);

   for(i = 1; i <= n; ++i) {
      if( (dift = fabs(x-xa[i])) < dif) {
        ns = i;
        dif = dift;
      }
      c[i] = ya[i];
      d[i] = ya[i];
   }
   *y = ya[ns--];
   for(m = 1; m < n; ++m) {
      for(i = 1; i <= n-m; ++i) {
         ho = xa[i] - x;
         hp = xa[i+m] - x;
         w = c[i+1] - d[i];
         if( (den=ho-hp) == 0.0) {
            fprintf(stderr, "Error in routine polint\n");
         }
         den = w/den;
         d[i] = hp*den;
         c[i] = ho*den;
      }
      *y += (*dy = (2*ns<(n-m)? c[ns+1] : d[ns--]));
   }
   free(c);
   free(d);
}


#define FUNC(x) ((*f)(x))

/* input s is result of previous integration step.
 */
real trapzd(real (*f)(real), real a, real b, int n, real s)
{
   real x, tnm, sum, del;
   int it, j;

   if(n == 1) {
      return (s=0.5*(b-a)*(FUNC(a) + FUNC(b)));
   } else {
      for(it = 1, j = 1; j < (n-1); ++j) {
         it <<= 1;
      }
      tnm = it;
      del = (b-a)/tnm;
      x = a + 0.5*del;
      for(sum = 0.0, j = 1; j <= it; j++, x+= del) sum += FUNC(x);
      s = 0.5*(s + (b-a)*sum/tnm);
      return s;
   }
}

#define EPS (1.0e-6)                            /* EPS is absolute precision */
#define JMAX 12
#define JMAXP (JMAX+1)
#define K 5

real qromb(real (*f)(real), real a, real b)
{
   real ss, dss, err;
   real s[JMAXP], h[JMAXP+1];
   int j;

   h[1] = 1.0;
   s[0] = 0.0;
   err = 1.0;
   for(j = 1; j <= JMAX; ++j) {
      s[j] = trapzd(f, a, b, j, s[j-1]);
      if(j >= K) {
         polint(&h[j-K], &s[j-K], K, 0.0, &ss, &dss);
         err = fabs(dss);                     /* small ss use absolute error */
         if (fabs(ss) > 1.0 ) {                 /* big ss use relative error */
            err = err/fabs(ss);
         }
         if(err <= EPS) { 
            return ss;
         }
      }
      h[j+1] = 0.25*h[j];
   }
   if(err > 10*EPS) {
      fprintf(stderr, "Too many steps (%d) in qromb, ss=%g, dss=%g\n", 
                      JMAX, (double) ss, (double) dss); 
   }
   return ss;
}
