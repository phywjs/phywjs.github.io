/**--------------------------------------------------------------------------- 
                E X A C T   D I A G O N A L I Z A T I O N 
   ---------------------------------------------------------------------------
   main program for exact diagonalization method for the spectrum of a 
   quantum dot.   
   
   21 Nov 2001,  by Wang Jian-Sheng
**/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include "realtype.h"

extern Occ_type *spsGlobal;                                         /* dot.c */

void read_model_parameters(FILE *fin, FILE *fout);             /* from dot.c */
int find_states(int no_elec, int nex, int fixedLS, int Lin, int Sin, /* same */
                 int state_size, State_type *pickedstate);
int get_index(int i, int j, int n);                                  /* same */
void constructH(const State_type *state, 
                int n, int nelec, real *H);                  /* constructH.c */
void init_hash(void);                                              /* hash.c */
void hash_info(void);                                                /* same */
void dump_hash(void);                                                /* same */
void eigensystem(const real *h, real *epsilon, real *psi, int dim, int nov);
void print_matrix(const real *h, int dim);                        /* eigen.c */

int main(int argc, char **argv)
{
   FILE *fin, *fout, *fecho;
   int i, j, n, nov, no_elec, nex, fixedLS, L, S, state_size;
   State_type *pickedstate;
   real *H, *epsilon, *psi;

   fin = stdin;                  /* if no argument is given, the program ... */
   fout = stdout;         /* read from standard in/write to standard out ... */
   fecho = stderr;                      /* and echo message to standard err. */

   if(argc > 1) {                                /* case of a.out input_file */
      fin = fopen(argv[1], "r");               /* read file, write to stdout */
      assert(fin != NULL);
   }
   if(argc > 2) {                              /* case of a.out input result */
      fout = fopen(argv[2], "a");
      assert(fout != NULL);
   }

   read_model_parameters(fin, fecho);

   fprintf(fecho, "enter number of electrons\n");
   fscanf(fin, "%d", &no_elec);
   fprintf(fecho, "enter number of lowerst eigenvalues wanted\n");
   fscanf(fin, "%d", &nov);
   fprintf(fecho, "enter extra single particle states nex\n");
   fscanf(fin, "%d", &nex);
   fprintf(fecho, "fixed L and S? (0 for no, 1 for S, 2 for L and S)\n");
   fscanf(fin, "%d", &fixedLS);
   if(fixedLS == 2) {
      fprintf(fecho, "enter L and S\n");
      fscanf(fin, "%d%d", &L, &S);
   } else if (fixedLS == 1) {
      fprintf(fecho, "enter S\n");
      fscanf(fin, "%d", &S);
      L = 0;
   } else {
      L = 0;
      S = 0;
   }
   fprintf(fecho, "enter number of many-body states wanted\n"); 
   fscanf(fin, "%d", &state_size);

   spsGlobal = (Occ_type *) malloc((no_elec+nex)*sizeof(Occ_type));
   pickedstate = (State_type *) malloc( (state_size)*sizeof(State_type) );
   for(i = 0; i < state_size; ++i) {
      pickedstate[i].ind = (int *) malloc(no_elec*sizeof(int));
   }

   n = find_states(no_elec, nex, fixedLS, L, S, state_size, pickedstate);

   fprintf(fout, "Single particle states are:\n");
   for(i = 0; i < no_elec+nex; ++i) {
      fprintf(fout, "spsGlobal[%d] : %d %d %d  %g\n",
         i, spsGlobal[i].n, spsGlobal[i].m, 
            spsGlobal[i].s, (double) spsGlobal[i].eng);
   }
   fprintf(fout, "The choose many-body states are ");
   fprintf(fout, "(seq, L  S  Eng, index to spsGlobal):\n");
   for(i = 0; i < n; ++i) {
      fprintf(fout, "%d, %d %d %g, (", i, 
         pickedstate[i].L, pickedstate[i].S, (double) pickedstate[i].Eng);
      for(j = 0; j < no_elec; ++j) {
         fprintf(fout, "%d ", pickedstate[i].ind[j]);
      }
      fprintf(fout, ")\n");
   }

   if(n > 0) {
      init_hash();
      H = (real *) malloc(n*n*sizeof(real));
      assert(H != NULL);
      constructH(pickedstate, n, no_elec, H);
      printf("The Hamiltonian H is:\n");
      print_matrix(H, n);

      if(nov > n) { nov = n; }

      epsilon = (real *) malloc(n*sizeof(real));              /* must size n */
      psi = (real *) malloc(n*nov*sizeof(real));
      assert(epsilon != NULL);
      assert(psi != NULL);

      eigensystem(H, epsilon, psi, n, nov);

      fprintf(fout, "Matrix size is %d x %d, eigenvalues:\n", n, n);
      for(i = 0; i < nov; ++i) {
         fprintf(fout, "%.8g ", (double) epsilon[i]);
      }
      fprintf(fout, "\n");
      hash_info();
      dump_hash();

      free(psi);
      free(epsilon);
      free(H);
   }

   free(pickedstate);                                  /* .ind not handled!! */
   free(spsGlobal);

   return 0;
}
