#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include "realtype.h"

                                             /* external data/functions used */
void print_matrix(const real *h, int dim);                        /* eigen.c */
void eigensystem(const real *h, real *epsilon, real *psi, int dim, int nov);

int main()
{
   real *h, *psi, *eps;
   int i, n, nov;
   double d;

   printf("Test symmetric eigenvalue problem H Psi = eps Psi\n");
   printf("enter matrix size n\n");
   scanf("%d", &n);
   printf("enter number (<=n) of eigenvalues to compute\n");
   scanf("%d", &nov);

   h = (real *) malloc(n*n*sizeof(real));
   psi = (real *) malloc(n*nov*sizeof(real));
   eps = (real *) malloc(n*sizeof(real));
   assert(h != NULL);
   assert(psi != NULL);
   assert(eps != NULL);

   printf("enter h (column vise)\n");
   for(i = 0; i < n*n; ++i) {
      scanf("%lf", &d);
      h[i] = d;
   }

   eigensystem(h, eps, psi, n, nov);
   print_matrix(psi, n); 
   printf("eigenvalues\n"); 
   for(i = 0; i < nov; ++i) {
      printf("%g ", eps[i]);
   }
   printf("\n");

   return 0;
}
