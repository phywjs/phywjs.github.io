/*----------------------------------------------------------------------------
                             H a s h - T a b l e
  ----------------------------------------------------------------------------
   Store two-particle interaction integral <ij|1/r|kl> into a hash table.

   From the state indices n1,m1,...,n4,m4, we generate a key through a 
   hash function.  We look starting from the location key, in step of
   offset, i.e., we look for key, key+offset, key+2offset, until we find
   the first empty slot (item then does not exist), or find the item.
   Hashtable can dynamically increase.  From user point of view, he does
   not need to know the internal implementations, but just use 
   get_element(), and store() to access the hash table.  Init_hash()
   must be called before use.  hash_info() prints some statistics about
   the table.
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include "realtype.h"

#define SMAX 127                               /* max value of signed "byte" */

typedef struct {                              /* an entry of hash table item */
   unsigned long long int state;    /* (n1,m1,...,m4) in one unsigned ll int */
   real val;                                         /* value of <ij/1/r|kl> */
   int valid;                  /* 0 means entry is empty, 1 means valid data */
} Hash_table_type;

static Hash_table_type *hash;                                   /* the table */
static int Hash_size;                                          /* table size */
static int Hash_item_count=0;              /* how many we have stored so far */

/* Enlarge the table size by a factor of e
 */
static void big_size_rehash(void)
{
   int n1, n2, n3, n4;
   int m1, m2, m3, m4;
   int i, key, size_old, cnt, count_old;
   unsigned long long int jLL;
   real val;
   signed char c;
   Hash_table_type *hash_old;

   int store(real val, int n1, int m1, int n2, int m2, int n3, int m3, 
                    int n4, int m4);

   size_old = Hash_size;
   hash_old = hash;
   Hash_size = 2.71828182846*size_old;               /* avoid exact multiple */
   hash = (Hash_table_type *) calloc( Hash_size, sizeof(Hash_table_type) );
   assert(hash != NULL);
   assert(Hash_size > size_old);

   count_old = Hash_item_count;
   Hash_item_count = 0;                         /* recount from 0 by store() */
   cnt = 0;
   for(i = 0; i < size_old; ++i) {            /* copy to a bigger hash table */
      if(hash_old[i].valid) {
         jLL = hash_old[i].state;                    /* decompress the state */
         n1 = c = (jLL & 0xFF);               /* must properly sign extended */
         m1 = c = ( (jLL>>8) & 0xFF);
         n2 = c = ( (jLL>>16) & 0xFF);
         m2 = c = ( (jLL>>24) & 0xFF);
         n3 = c = ( (jLL>>32) & 0xFF);
         m3 = c = ( (jLL>>40) & 0xFF);
         n4 = c = ( (jLL>>48) & 0xFF);
         m4 = c = ( (jLL>>56) & 0xFF);
         val = hash_old[i].val;
         key = store(val, n1, m1, n2, m2, n3, m3, n4, m4);
         ++cnt;
         assert(key >= 0 && key < Hash_size);
      }
   }
   assert(count_old <= size_old);
   assert(cnt == count_old);
   free(hash_old);
}


/* hashing() takes index[8] and construct single long long word state jLL,
   the key and offset value.
 */
static void hashing(const int index[8], 
                    unsigned long long int *jLL, int *key, int *offset)
{
   unsigned long long int j;
   int i;

   *jLL = 0;
   for(i = 0; i < 8; ++i) {
      j = (index[i] & 0xFF);                       /* take only the 0th byte */
      assert(abs(index[i]) < SMAX);                /* only make sense if ... */
      *jLL |= (j << (8*i));                 /* each byte is signed small int */
   }

   j = (*jLL) * 6364136223846793005ll;

   *key = j % Hash_size;
   assert(*key >= 0 && *key < Hash_size);
   *offset = 1;
}

int get_element(int n1, int m1, 
                int n2, int m2, 
                int n3, int m3, 
                int n4, int m4, real *val)
{
   int try, nm[8], key, offset, eq;
   unsigned long long int jLL; 

   nm[0] = n1;
   nm[1] = m1;
   nm[2] = n2;
   nm[3] = m2;
   nm[4] = n3;
   nm[5] = m3;
   nm[6] = n4;
   nm[7] = m4;
   hashing(nm, &jLL, &key, &offset);

   try = 0;
   do {
      if (hash[key].valid) {           /* table has something, compare state */
         eq = (jLL == hash[key].state); 
         if (eq) {                                 /* when eq==1, we find it */
            *val = hash[key].val;
            return key;
         }
      } else {                         /* empty slot find, pattern not find */
         *val = 1.0e30;                                /* return "infinity" */
         return -1;
      }
      key = (key + offset) % Hash_size;
      ++try;
   } while (try < Hash_size);

   fprintf(stderr, "in get_element(), not find, hash table full!\n");

   return -2;
}

int store(real val, int n1, int m1, 
                    int n2, int m2, 
                    int n3, int m3, 
                    int n4, int m4)
{
   int try, key, offset, nm[8], eq;
   unsigned long long int jLL;

   nm[0] = n1;
   nm[1] = m1;
   nm[2] = n2;
   nm[3] = m2;
   nm[4] = n3;
   nm[5] = m3;
   nm[6] = n4;
   nm[7] = m4;
   hashing(nm, &jLL, &key, &offset);

   try = 0;
   do {
      if (hash[key].valid) {           /* table has something, compare state */
         eq = (jLL == hash[key].state); 
         if (eq) {                                 /* when eq==1, we find it */
            /**
               fprintf(stderr, "this value already stored earlier, ");
               fprintf(stderr, "old value %g, current value %g\n",
                               (double) hash[key].val, (double) val);
            **/
            assert(fabs(hash[key].val - val) < 1.0e-6);
            return key;
         }
      } else {                          /* empty slot find, pattern not find */
         hash[key].valid = 1;
         hash[key].state = jLL;
         hash[key].val = val;
         ++Hash_item_count;                /* how many we have stored so far */

         if(Hash_item_count > 0.8*Hash_size) {
            fprintf(stderr, "hash table near 80%% full, size doubled!\n");
            big_size_rehash();
         }
         return key;
      }
      key = (key + offset) % Hash_size;
      ++try;
   } while (try < Hash_size);

   fprintf(stderr, "in store(), hash table full!, but this cannot happen!\n");

   return -2;
}


/* Allocate memory for the hash, and initialize value by previously
   saved file, if it exists.
 */
void init_hash(void)
{
   FILE *fp;
   int i, hsize, nm[8];
   real val;
   double d;

   Hash_size = 101;

   fp = fopen("HASHTABLE.dat", "r");
   if(fp != NULL) {
      fscanf(fp, "%d", &hsize);       /* number of actual items in the table */
      if(hsize > 0.8*Hash_size) {
         Hash_size = 3.14159265358979 * hsize;
      }
      hash = (Hash_table_type *) calloc(Hash_size, sizeof(Hash_table_type));
      for(i = 0; i < hsize; ++i) {
         if(fscanf(fp, "%d%d%d%d%d%d%d%d%lf", 
                     nm, nm+1, nm+2, nm+3, nm+4, nm+5, nm+6, nm+7,
                     &d) != 9) { 
           fprintf(stderr, "in init_hash(), reading terminated prematurely!\n");
           break;
         }
         val = d;
         assert(nm[0] >= 0 && nm[0] < SMAX);                /*  0 <= n < 127 */
         assert(nm[2] >= 0 && nm[2] < SMAX);
         assert(nm[4] >= 0 && nm[4] < SMAX);
         assert(nm[6] >= 0 && nm[6] < SMAX);
         assert(abs(nm[1]) < SMAX);                             /* |m| < 127 */
         assert(abs(nm[3]) < SMAX);
         assert(abs(nm[5]) < SMAX);
         assert(abs(nm[7]) < SMAX);
         assert(val != 0.0);                 /* we only saved nonzero values */
         assert(nm[1]+nm[3] == nm[5]+nm[7]);          /* rotational symmetry */
         store(val, nm[0], nm[1], nm[2], nm[3], nm[4], nm[5], nm[6], nm[7]);
      }
      fclose(fp);
   } else {                                      /* calloc() zero the values */
      hash = (Hash_table_type *) calloc(Hash_size, sizeof(Hash_table_type));
   } 
}

/* Save the entries on the hash table
 */
void dump_hash(void)
{
   FILE *fp;
   int i, k, hsize;
   signed char c;
   unsigned long long int jLL;

   hsize = 0;
   for(i = 0; i < Hash_size; ++i) {                /* count the stored items */
      if(hash[i].valid) {
          ++hsize;
      }
   }
   assert(hsize == Hash_item_count);

   fprintf(stderr, "hash table file is overwritten!\n");
   fp = fopen("HASHTABLE.dat", "w");
   assert(fp != NULL);
   fprintf(fp, "%d\n", hsize);
   for(i = 0; i < Hash_size; ++i) {
      if(hash[i].valid) { 
         jLL = hash[i].state;
         for(k = 0; k < 8; ++k) {
            c = (jLL & 0xFF); 
            jLL >>= 8;
            fprintf(fp, "%d ", (int) c);
         }
         fprintf(fp, "%.15g\n", (double) hash[i].val);
      }
   }
   fclose(fp);

   free(hash);         /* once dump is called, we can no long use hash table */
}

void hash_info(void)
{
   int i, j, key, offset, cnt, hash_cnt[10];
   real lav, lsq, lct;

   for(i = 0; i < 10; ++i) {                /* hold statistics of run length */ 
      hash_cnt[i] = 0;
   }
   lav = 0.0;
   lsq = 0.0;
   lct = 0.0;
   for(j = 0; j < Hash_size; ++j) {
      cnt = 0;
      key = j; 
      offset = 1;
      do {
         if (!hash[key].valid) break;
         key = (key + offset) % Hash_size;
         ++cnt;
      } while (cnt < Hash_size);

      if (cnt > 0 ) {
         lav += cnt;
         lsq += cnt*cnt;
         lct += 1;
      }
      if (cnt >= 10) {
        cnt = 9;
      }
      ++hash_cnt[cnt];
   }
   if(lct > 0) {
      lav = lav/lct;
      lsq = lsq/lct - lav*lav;
   }
   if ( lsq > 0.0 ) 
      lsq = sqrt(lsq);
   printf("Hash Table Utilization: load factor = %f, hash_size = %d\n", 
          (double) lct/Hash_size, Hash_size);
   printf("probe length average = %f, deviation = %f\n", 
          (double) lav, (double) lsq);
   printf(" %.2g%% %d, ", 100.0*hash_cnt[0]/Hash_size, 0);
   if(lct > 0) {
      for(i = 1; i < 10; ++i)
         printf("%.2g%% %d, ", (double) (100.0*hash_cnt[i]/lct), i);
   }
   printf("\n");
}
