/* Testing reading, get, and store of hash table */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include "realtype.h"

void init_hash(void);
void hash_info(void);
void dump_hash(void);
int store(real val, int n1, int m1, int n2, int m2, int n3, int m3, int n4, int m4);
int  get_element(int n1, int m1, int n2, int m2, int n3, int m3,int n4, int m4, real *res);

int main()
{
   int n1, n2, n3, n4;
   int m1, m2, m3, m4;
   int i, n, key;
   double d;
   real res;

   printf("Testing hash table.\n");

   init_hash();

   printf("enter n, the number of items to be stored\n");
   scanf("%d", &n);
   printf("enter n1 m1 n2 n2 n3 m3 n4 m4 and res\n");
   for(i = 0; i < n; ++i) {
     scanf("%d%d%d%d%d%d%d%d%lf", 
               &n1, &m1, &n2, &m2, &n3, &m3, &n4, &m4, &d);
      res = d;
      key = store(res, n1, m1, n2, m2, n3, m3, n4, m4);
      printf("stored at key = %d\n", key);
   }
   hash_info();

   printf("enter n1 m2 ... to retrieve an item\n");
   scanf("%d%d%d%d%d%d%d%d", &n1, &m1, &n2, &m2, &n3, &m3, &n4, &m4);
   key = get_element(n1, m1, n2, m2, n3, m3, n4, m4, &res);
   printf("obtained from key = %d, value = %g\n", key, (double) res);
   
   dump_hash();
 
   return 0;
}

