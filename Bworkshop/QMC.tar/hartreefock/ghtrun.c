/**-------------------------------------------------------------------------
    H a r t r e e - F o c k   S c a n - -  M a i n   P r o g r a m
   -------------------------------------------------------------------------
    Run the QMC program, scanning for values of B, or scan any of the
    model parameters via one of the options -o0, -r0, -r1, -s, -V, -B, -g,
    using Hartree-Fock solution for trial wavefunction.  General space and
    spin unrestricted HF calculation.  15 Dec 2001, by Jian-Sheng Wang 
 **/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <assert.h>

#include "realtype.h"

extern Model_type model;                                 /* defined in dot.c */
                                                       /* exernal functions: */
void read_model_parameters(FILE *fin, FILE *fecho);                 /* dot.c */
real hartree_fock(FILE *fp, int nmax, Occ_type occ[],           /* ghtfock.c */
                  int nelec, int fixm, real c[], real *Ei);
void init_hash(void);                                              /* hash.c */
void dump_hash(void);                                                /* same */
void hash_info(void);                                                /* same */

int main(int argc, char **argv)
{
   FILE *fin, *fout;
   char infile[200], resfile[200], logfile[200];
   char commd[200], s[200];
   const char *s_var[7] = {"omega0", "r0", "r1", "sigma", "V0", "B", "g"};
   double var, var0, var1, dvar;
   Occ_type *occ;
   real res, Ei, d, *c;
   int i, j, size, nmax, nelec, fixm, line;
   int do_var, narg, L, S;
   time_t tm;

   if(argc < 4 || argc > 7) {
      printf("use: %s exec_file input_file [-B] B0 [ B1 dB ]\n", argv[0]);
      printf("     where B can be o0, r0, r1, s, V, B, g\n");
      exit(0);
   }

   if(argv[3][0] == '-') {
      if(argv[3][1] == 'o' && argv[3][2] == '0') {
         do_var = 0;
      } else if (argv[3][1] == 'r' && argv[3][2] == '0') {
         do_var = 1;
      } else if (argv[3][1] == 'r' && argv[3][2] == '1') {
         do_var = 2;
      } else if (argv[3][1] == 's') {
         do_var = 3;
      } else if (argv[3][1] == 'V') {
         do_var = 4;
      } else if (argv[3][1] == 'B') {
         do_var = 5;
      } else if (argv[3][1] == 'g') {
         do_var = 6;
      } else {
         fprintf(stderr, "unknown scanning option!\n");
         exit(1);
      }
      narg = 4;
   } else {                                            /* default is to do B */
      do_var = 5;
      narg = 3;
   }
   var0 = atof(argv[narg]);
   if(argc == narg + 3) {
      var1 = atof(argv[narg+1]);
      dvar = atof(argv[narg+2]);
   } else {                                           /* optional B1 dB case */
      var1 = var0 + 0.01;
      dvar = 1.0;                  /* this make for-loop for B run only once */
   }

   strncpy(infile, argv[2], 100);
   strncat(infile, ".in", 3);
   strncpy(resfile, argv[2], 100);
   strncat(resfile, ".res", 4);
   strncpy(logfile, argv[2], 100);
   strncat(logfile, ".log", 4);
                        /* redirection of standard output and standard error 
                                                  work with bash/ksh/sh only */
   sprintf(commd, "%s %s %s 1>>%s 2>>%s\n", 
           argv[1], infile, resfile, logfile, logfile);
   printf("Run %s", commd);
   printf("For input file %s, %s from %g to %g in step %g\n",
           argv[2], s_var[do_var], var0, var1, dvar);

   fin = fopen(argv[2], "r");
   assert(fin != NULL);
   read_model_parameters(fin, stdout);     /* read-in model parameters first */
   fscanf(fin, "%d", &i);                                /* skip dimension D */
   fscanf(fin, "%d", &nelec);                    /* read number of electrons */
   fscanf(fin, "%d", &i);                          /* skip number of walkers */
   fscanf(fin, "%lf", &d);                                       /* skip tau */
   fscanf(fin, "%d", &i);                                        /* skip DMC */
   fscanf(fin, "%d%d", &i, &j);                            /* skip MC, MCdis */
   fscanf(fin, "%d%d", &i, &j);                       /* skip int0, interval */
   fscanf(fin, "%d", &i);                                 /* read occ or not */
   assert(i == 1);                                   /* occ must be supplied */
   
   occ = (Occ_type *) malloc(nelec*sizeof(Occ_type));
   assert(occ != NULL);
   L = 0;
   S = 0;
   for(i = 0; i < nelec; ++i) {
      fscanf(fin, "%d%d%d", &occ[i].n, &occ[i].m, &occ[i].s);
      assert(occ[i].n >= 0 && occ[i].n < 127);    /* hashtable cannot handle */
      assert(abs(occ[i].m) < 127);                  /* if bigger than 1 byte */
      assert(abs(occ[i].s) == 1);
      L += occ[i].m;
      S += occ[i].s;
   }
   fscanf(fin, "%d%d", &nmax, &fixm);           /* fixm==1 if m is conserved */
   assert(nmax >= 0 && nmax < 127); 
   fclose(fin);

   printf("nelec=%d, L=%d, S=%d, nmax=%d\n", nelec, L, S, nmax);

   size = (nmax+1)*nelec;                   /* size of basis functions in HF */
   c = (real *) malloc(size*nelec*sizeof(real));
   assert(c != NULL);

   init_hash();

   for(var = var0; var <= var1; var += dvar) {
                                      /* generate an input data file for qmc */
      switch (do_var) {
         case 0:
            model.omega0 = var;
            model.omega = sqrt(var*var + 0.25*model.B*model.B);
            break;
         case 1:
            model.r0 = var;
            break;
         case 2:
            model.r1 = var;
            break;
         case 3:
            model.sigma2 = var*var;
            break;
         case 4:
            model.V0 = var;
            break;
         case 5:
            model.B = var;
            model.omega = sqrt(model.omega0*model.omega0 + 0.25*var*var);
            break;
         case 6:
            model.g = var;
            break;
         default:
            fprintf(stderr, "unknown do_var!\n");
            exit(1);
      } 
         
      fin = fopen(argv[2], "r");
      fout = fopen(infile, "w");
      assert(fin != NULL);
      assert(fout != NULL);

      fprintf(fout, "%g\n", model.omega0);         /* write model parameters */
#ifdef MODEL_RING_BUMP
      fprintf(fout, "%g %g\n", model.r0, model.r1);
#else
      fprintf(fout, "%g %g\n", model.r0, sqrt(model.sigma2));
#endif
      fprintf(fout, "%g\n", model.V0);
      fprintf(fout, "%g\n", model.B);
      fprintf(fout, "%g\n", model.g);

      line = 0;                                             /* copy the rest */
      while( fgets(s, 100, fin) != NULL  && line < 13) {
         ++line;
         if(line > 5) {
            fputs(s, fout);
         }
      }
      fclose(fin);
      assert(line == 13);
                               /* the rest of file written by hartree_fock() */
      res = hartree_fock(fout, nmax, occ, nelec, fixm, c, &Ei);
      fclose(fout);

      tm = time(NULL);
      printf("%s= %g  Ei= %g  E_hf= %g  %s", 
              s_var[do_var], var, (double) Ei, (double) res, ctime(&tm));
      fflush(stdout);
      system(commd);
   }

   hash_info();
   dump_hash();
   free(c);
   free(occ);

   printf("finished!\n");
   return 0;
}
