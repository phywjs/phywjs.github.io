/*----------------------------------------------------------------------------
         C o n s t r u c t   t h e  e x a c t  H a m i l t o n i a n
 ----------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include "realtype.h"

real one_particle_int(int i, int j);                                /* dot.c */
real overlap_int(int i, int j, int k, int l);                        /* same */
int get_index(int i, int j, int n);                                  /* same */


/* Given two sets of occupations indA and indB, find the single particle
   states sA (complement) that are in A but not in B, and sB that are in 
   B but not in A, and the common set (intersection) that are the same.
   Read Szabo's book, particularly table 2.3 and 2.4 for more information.
   inputs: indA, indB, nelec;
   outputs: sA, sB, same
   return no of same state cnt_same
 */
int find_difference(const int *indA, const int *indB, int nelec, 
                           int *sA, int *sB, int *same)
{
   int i, p, q;
   int dif, cnt_same, cnt_A, cnt_B;
 
   for(i = 0; i < (nelec-1); ++i) {                  /* input must be sorted */
      assert(indA[i] < indA[i+1]);
      assert(indB[i] < indB[i+1]);
   }

   cnt_same = 0;
   cnt_A = 0;
   cnt_B = 0;
   p = 0;
   q = 0;           /* we  try to merge the two sequences, pick the same and
                                                      differences on the way */
   while(p < nelec || q < nelec) {
      if(p < nelec && q < nelec) {
         dif = indA[p] - indB[q];
      } else {           /* need to do this because indA[nelec] is undefined */
         if(p < nelec) {
           dif = -1;
         } else if (q < nelec) {
           dif = 1;
         } else {
           assert(0);                                       /* cannot happen */ 
         }
      }
      if(dif > 0) {  
        sB[cnt_B++] = indB[q];                    /* we must set indA[nelec] */
        ++q;                                  /* and indB[nelec] to infinite */
      } else if (dif < 0) {                        /* for proper termination */
        sA[cnt_A++] = indA[p];
        ++p;
      } else {                                                   /* same sps */
         same[cnt_same++] = indA[p];
         assert(indA[p] == indB[q]);
         ++p;
         ++q;
      } 
   }
   assert(p == nelec && q == nelec);                      /* all ind visited */
   assert(cnt_same <= nelec);
   assert(cnt_A <= nelec);
   assert(cnt_B <= nelec);
   assert(cnt_A + cnt_same == nelec);
   assert(cnt_B + cnt_same == nelec);

   return cnt_same;
}

/* find_sign() find the parity of number of exchange needed when
   the set of sps are moved from their original position in ind to
   to the front.
*/
int find_sign(const int *ind, int nelec, const int *sA, int ndif)
{
   int i, m, k, swp;

   for(i = 0; i < (nelec-1); ++i) {
      assert(ind[i] < ind[i+1]);
   }
   for(i = 0; i < (ndif-1); ++i) {
      assert(sA[i] < sA[i+1]);
   }
   swp = 0;
   for(m = 0; m < ndif; ++m) {
      k = 0;                                   /* try find sA[m] in ind list */
      while(k < nelec && (ind[k]!=sA[m]) ) {
         ++k;
      }                /* if k == nelec, we did not find, this cannot happen */
      assert(k<nelec);                                          /* must find */
      swp += (k-m);
   }
   if( swp % 2 == 0 ) {
      return 1;
   } else {
      return -1;
   }
}


/* constructH() take a list of states and generate the Hamiltonian
   matrix of size n by n, n is the length of the states. */

void constructH(const State_type *state, int n, int nelec, real *H)
{
   int i, j, k, p, q;
   int indx, sgn, *sA, *sB, *same;
   int no_same, ndif;
   real res;

   same = (int *) malloc(nelec*sizeof(int));
   sA = (int *) malloc(nelec*sizeof(int));
   sB = (int *) malloc(nelec*sizeof(int));
   assert(same != NULL);
   assert(sA != NULL);
   assert(sB != NULL);

   for(k = 0; k < n*n; ++k) {
      H[k] = 0.0;
   }
   for(i = 0; i < n; ++i) {
      for(j = i; j < n; ++j) {
         indx = get_index(i,j,n);
         no_same = find_difference(state[i].ind, state[j].ind, nelec, 
                                   sA, sB, same);
         ndif = nelec - no_same;
         switch(ndif) {
            case 0:                              /* state i & j are the same */
               assert(i == j);
               for(p = 0; p < nelec; ++p) {
                  for(q = p+1; q < nelec; ++q) {
                     H[indx] += overlap_int(state[i].ind[p],
                                            state[i].ind[q],
                                            state[j].ind[p],
                                            state[j].ind[q]);
                  }
                  H[indx] += one_particle_int(state[i].ind[p], state[j].ind[p]);
               }
               break;
            case 1:                             /* i & j differ by 1 orbital */
               sgn = find_sign(state[i].ind, nelec, sA, 1) *
                     find_sign(state[j].ind, nelec, sB, 1);
               res = 0.0;
               for(p = 0; p < nelec-1; ++p) {
                  res += overlap_int(sA[0], same[p], sB[0], same[p]);
               }  
               H[indx] += sgn * res;
               H[indx] += sgn * one_particle_int(sA[0], sB[0]);
               break;
            case 2:                            /* i & j differ by 2 orbitals */
               sgn = find_sign(state[i].ind, nelec, sA, 2) *
                     find_sign(state[j].ind, nelec, sB, 2);
               H[indx] += sgn * overlap_int(sA[0], sA[1], sB[0], sB[1]); 
               break;
            default: 
               assert(ndif > 2);
          }
      }
   }   
                  /* only upper triangle is computed, other half by symmetry */
   for(i = 0; i < n; ++i) {
      for(j = i+1; j < n; ++j) {
         H[get_index(j,i,n)] = H[get_index(i,j,n)];
      }
   }

   free(sB);
   free(sA);
   free(same);

}
