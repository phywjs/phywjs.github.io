/*----------------------------------------------------------------------------
            G a u s s  -  L a g u e r r e   Q u a d r a t u r e
  ----------------------------------------------------------------------------
  Computation of one-particle <i|dV|j> and two-particle <ij|1/r|kl> integrals. 

  Note: The function lgamma() (log Gamma) is not ANSI standard, but is 
  standard in Xopen and C99.  The Bessel function jn(n,x) is not standard.
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include "realtype.h"
  
#define INTEGRAL  qgauss                    /* choice of qromberg and qgauss */

real qromb( real (*f)(real), real a, real b);              /* from romberg.c */
real bessi(int q, real x);                                 /* from besselI.c */

/* Gaussian quadrature with Laguerre polynomial weight,
   int_0^inf x^alf exp(-x) f(x) dx = sum_{j=0}^(n-1) w_j f(x_j)
   x is abscissas, w weights, n number of points, alf the exponent.
   The result is exact for f(x) being a polynomial of order 2n.
   gaulag() from "Numerical Recipes", p. 152-153, modified.
   It turns out gauss quadrature has problem when n is large (10^3),
   due to numerical inaccuracy of the solution of zeros of very 
   high order Laguerre polynomials.  
 */

typedef struct {               /* an entry of table of Gauss quadrature info */
          real *xvalue;
          real *weight;
          int length;
          int valid;         /* if data in abscissa and weight are generated */
} gauss_int_type;

#define MAX_TB_SIZE 7                /* gaussian pt of length 4, 8, 16, etc */
#define MAX_SPIN_M  200              /* associated with difference alf value */
#define MAX_GAUSS_IT 7           /* maximum iterations for gauss quadrature */
#define MAX_NEWTON_IT 50                  /* max Newton iterations for roots */
#define EPS_GAUSS (1.0e-6)         /* absolute error tolerance for gauss int */
#define EPS_ROOTS (1.0e-14) /* absolute error tolerance for polynomial roots */

static gauss_int_type table[MAX_SPIN_M][MAX_TB_SIZE];

static int gaulag(real x[], real w[], int n, real alf) 
{
   int i, its, j;
   long double ai;
   long double p1, p2, p3, pp, z, z1;

   z = 0.0;
   for(i = 0; i < n; ++i) {
      if(i == 0) {
         z = (1.0+alf)*(3.0+0.92*alf)/(1.0+2.4*n+1.8*alf);
      } else if (i == 1) {
         z += (15.0+6.25*alf)/(1.0+0.9*alf+2.5*n);
      } else {
         ai = i-1;
         z += ((1.0 + 2.55*ai)/(1.9*ai)+1.26*ai*alf/
              (1.0+3.5*ai))*(z-x[i-2])/(1.0 + 0.3*alf);
      }
      for(its = 1; its <= MAX_NEWTON_IT; ++its) {        /* Newton iteration */
         p1 = 1.0;
         p2 = 0.0;
         for(j = 1; j <= n; ++j) {
            p3 = p2;
            p2 = p1;
            p1 = ( (2*j-1+alf-z)*p2 - (j-1+alf)*p3 )/j;
         }
         pp = (n*p1-(n+alf)*p2)/z;
         z1 = z;
         z = z1 - p1/pp;
         if(fabs((z-z1)) <= EPS_ROOTS) break;
      }
      if(its > MAX_NEWTON_IT) {
         fprintf(stderr, "too many iterations in gaulag\n");
      }
      x[i] = z;
      w[i] = -exp(lgamma((double)(alf+n))-lgamma( (double) n) ) /(pp*n*p2);
      assert(x[i] >= 0.0);
      assert(w[i] >= 0.0);
      if(fabs(w[i]) < 1.0e-30)  {                 /* omit very small weights */
         break;                             /* min double value is 10^(-308) */
      }
   }

   return i;               /* i <= n, large x, small w points can be omitted */
}


/* Generalized Laguerre polynomials Laguerre(n, m, x) are related to hydrogen
   atom as well as 2D oscillator wave functions in quantum mechanics. They 
   satisfy the differential equation, 
        x y'' + (1+m-x) y' + n y = 0,
   and the orthogonality relation 
        int_0^inf L(n,m,x) L(n', m, x) x^m exp(-x) dx = 0 when n != n'
   and (n+m)!/n! when n = n'.

   The definition here follow Mathematica and Arfken.
*/

real laguerre(int n, int m, real x)
{
   real p1, p2, p3;
   int j;
   
   assert(n>= 0 && m >= 0);
   p2 = 0.0;
   p1 = 1.0;
   for(j = 0; j < n; ++j) {        /* Laguerre polynomial recursion relation */
      p3 = p2;                              /* see Arfken p.620, or NR p.153 */
      p2 = p1;
      p1 = ( (2*j+m+1-x)*p2 - (j+m)*p3 )/(j+1);
   };

   return p1;
}

static real norm(int n, int m)  /* the normalization const sqrt(n!/(n+|m|)!) */
{                                        /* this is without the omega factor */
   real val;
   int i;

   if(m<0) { m = -m; }
   assert(n>=0);
 
   val = 1.0;
   for(i = 1; i <= m; ++i) {
      val *= (n+i);
   };
   
   return sqrt(1.0/val);
}

/* qgauss does inner 1D integral of the special form
   int_0^inf f(n1,m1) f(n2,m2) g(|m2-m1|, x) dx, where f(n,m) = 
   sqrt(n!/(n+|m|)!) x^|m|/2 exp(-x/2) laguerre(n,|m|, x), and g(q, x)
   is any arbitrary function of type real g(int q, real x).
   Compute gauss points and weight if it is not yet generated
   on the table.  The handling of the table is transparent to the
   user.
*/
real qgauss(int n1, int m1, int n2, int m2, real (*g)(int, real) )
{
   real *abscissa, *weight;
   real sum, sumold, alf, x, err, c;
   int i, dm, npt;
   int tb, mem, m_ind, len;

   dm = abs(m2-m1);                                  /* pass |m| to laguerre */
   if(m1 < 0) { m1 = -m1; }            /* but bessel functions need the sign */
   if(m2 < 0) { m2 = -m2; } 
   m_ind = m1 + m2; 
   alf = 0.5 * m_ind;
   c = norm(n1, m1) * norm(n2, m2);
   sumold = 1.0e30;                                 /* start with "infinity" */
   npt = 4;              /* start with 4 points and double in each iteration */
   tb = 0;

Loop:
   if(tb < MAX_TB_SIZE && m_ind < MAX_SPIN_M) {
      if(table[m_ind][tb].valid) {
        abscissa = table[m_ind][tb].xvalue; 
          weight = table[m_ind][tb].weight; 
             len = table[m_ind][tb].length;     /* actual useful data length */
      } else {                       /* npt>= len include zero weight points */
          abscissa = (real *) malloc( npt*sizeof(real));
          weight = (real *) malloc( npt*sizeof(real));
          assert(abscissa != NULL);
          assert(weight != NULL);
          len = gaulag(abscissa, weight, npt, alf);
          table[m_ind][tb].valid = 1;
          table[m_ind][tb].xvalue = abscissa;
          table[m_ind][tb].weight = weight;
          table[m_ind][tb].length = len;
      }
      mem = 0;                             /* should we free memory? No here */ 
   } else {
      fprintf(stderr, "gauss quad table full, generate on the fly\n");
      abscissa = (real *) malloc( npt*sizeof(real));
      weight = (real *) malloc( npt*sizeof(real));
      assert(abscissa != NULL);
      assert(weight != NULL);
      len = gaulag(abscissa, weight, npt, alf);
      mem = 1;               /* free non-table memory, otherwise memory leak */
   }

   assert(len <= npt);
   sum = 0.0;
   for(i = 0; i < len; ++i) {
      x = abscissa[i];
      sum += weight[i] * laguerre(n1,m1,x) 
                       * laguerre(n2,m2,x) * (*g)(dm, x);
      /* assert(fabs(laguerre(npt,alf,x))<1.0e-9); this must be true, but .. */
   }                                    /* have numerical stability problem! */
   sum *= c;

   if(mem) {                            /* we don't free memory on the table */
      free(abscissa);                                /* must inside the loop */
      free(weight);
   }

   ++tb;

   err = fabs(sum - sumold);      /* for small value < 1, use absolute error */
   if(fabs(sum) > 1.0) {                /* for big value, use relative error */
      err = err/fabs(sum);
   }
   if(err > EPS_GAUSS) {
      if(tb < MAX_GAUSS_IT) {
         npt *= 2;
         sumold = sum;
         goto Loop;
      } else {
         if(err > 100*EPS_GAUSS) {
            fprintf(stderr, 
               "qgauss not converging after %d iterations, sum=%g, err=%g\n", 
                tb, (double) sum, (double) err);
         }
      }
   }

   return sum;
}

                    /* used to communicate extra variables for 1D integrands */
static int n1_com, n2_com;
static int m1_com, m2_com;
static real k_com, c_com;
static real (*g_com)(int, real);                    /* pointer to a function */

/*** function g for two particle inner integral
    g(x) = jn(q, k * sqrt(x))
    Note that it is not k * sqrt(x/omega) since k is scaled by
    sqrt(omega).
***/
static real scaled_bessel(int q, real x)
{
   real y;

   y = k_com*sqrt(x); 
   return jn(q, y);
}

/* 1D integrand
 */
static real f_inner(real x) 
{
   int abs_m1, abs_m2, dm;
   real alf, res;
  
   dm = abs(m2_com-m1_com);
   abs_m1 = abs(m1_com);
   abs_m2 = abs(m2_com);
   alf = 0.5*(abs_m1 + abs_m2);

   res = c_com * pow(x, alf) * laguerre(n1_com, abs_m1, x) 
                             * laguerre(n2_com, abs_m2, x)
                             * (*g_com)(dm, x) * exp(-x);
   return res;
}

static real f_inv(real t) 
{
   int abs_m1, abs_m2, dm;
   real alf, res, x;
  
   abs_m1 = abs(m1_com);
   abs_m2 = abs(m2_com);
   dm = abs(m2_com-m1_com);
   alf = 2.0 + 0.5*(abs_m1 + abs_m2);
 
   if(t < 1.0e-12) {
      return 0.0;
   }
   x = 1/t;

   res = c_com * exp(-x) * pow(x, alf) * laguerre(n1_com, abs_m1, x) 
                                       * laguerre(n2_com, abs_m2, x)
                                       * (*g_com)(dm, x);
   return res;
}

/* Do exact the same as qgauss() but with romberg algorithm. 
   The normalization constant is multiplied here in f_*.
 */
real qromberg(int n1, int m1, int n2, int m2, real (*g)(int, real) )
{
   real res1, res2;
   real xcut;

   n1_com = n1;                         /* pass everything except variable x */ 
   m1_com = m1;                                   /* through "common blocks" */
   n2_com = n2;
   m2_com = m2;
   c_com = norm(n1, m1) * norm(n2, m2);
   g_com = g;

   xcut = 5.0;
   res1 = qromb(f_inner, 0.0, xcut);
   res2 = qromb(f_inv, 0.0, 1.0/xcut);

   return res1 + res2;
}

static int n1_c, m1_c, n3_c, m3_c;           /* common block for 2D integral */
static int n2_c, m2_c, n4_c, m4_c;               /* cannot be shared with 1D */

/* Integrand for the outer k integration.  f2d_inner is for variable k.
 */
static real f2d_inner(real k)
{
   real res1, res2;

   k_com = k;
   res1 = INTEGRAL(n1_c, m1_c, n3_c, m3_c, scaled_bessel);
   res2 = INTEGRAL(n2_c, m2_c, n4_c, m4_c, scaled_bessel);

   return  res1 * res2;
}


/* Finally, compute two-point integral <ij|kl>, method of Derim Guclu. 
 */
real devrim2D(int n1, int m1, int n2, int m2, int n3, int m3, int n4, int m4)
{
   real kmin, kmax, res, d, err;

   if(-m1-m2+m3+m4 != 0) {                       /* due to rotation symmetry */
      return 0.0;
   }
 
   n1_c = n1;            /* pass indices information through "common" blocks */
   m1_c = m1;                  /* as integrand f2d_* takes only one argument */
   n2_c = n2;
   m2_c = m2;
   n3_c = n3;
   m3_c = m3;
   n4_c = n4;
   m4_c = m4;
   
   res = 0.0;
   kmin = 0.0;
   kmax = 4.5;
   do {
      d = qromb(f2d_inner, kmin, kmax);
      kmin = kmax;
      kmax += 2.0;
      res += d;
      err = fabs(d);
      if( fabs(res) > 1.0 ) {
         err = err/fabs(res);
      }
   } while (err > EPS_GAUSS && (kmax < 15.0) );

   return res;
}

/* function g for one-particle perturbation integral
    g(x) = exp(-r^2/(2sigma^2) - r0^2/(2simga^2)) bessi(q, r r0/simga^2)
    x is rho = omega r^2.  Since qgauss() use absolute error for
    convergence, it was a bad idea to factor the constant piece
    outside the integral.
 */
static real scaled_bessi(int q, real x)
{
   real r, r0, res;

   extern Model_type model;                              /* defined in dot.c */

   r = sqrt(x/model.omega);                        /* x is rho = omega * r^2 */
   r0 = model.r0;

#ifdef MODEL_RING_BUMP
   if (q != 0) {
      res = 0.0;
   } else if ( r <= model.r0 || r >= model.r1) {
      res = 0.0;
   } else {                      /* need 0.5 because perturb_matel() timed 2 */
      res = 0.5 * ( 1.0 - cos(2.0*M_PI*(r-r0)/(model.r1-r0)) );
   }
#else
   res = exp( -0.5*(x/model.omega + r0*r0)/model.sigma2 ) * 
         bessi(q, r*r0/model.sigma2);
#endif
   return res;
}


/* perturb_matel() computes the matrix elements of a double gaussian
   perturbation (centered at (r0,0) and (-r0, 0)), i.e. 
   < n1 m1 | dV | n2 m2>, where dV is
   V0 ( exp( - ((x - r0)^2 + y^2)/(2sigma^2) ) + 
        exp( - ((x + r0)^2 + y^2)/(2sigma^2) ) )
   and |n m> is the standard Fock-Darwin state.  The computation uses
   gauss quadrature.  The angular part is integrated analytically
   using
   besselI(n, x) = (1/(2pi)) int_0^(2pi) exp(-i*n*q + x*cos(q)) dq.
   Note: the model parameters in the structure of Model_type is
   needed!
*/
real perturb_matel(int n1, int m1, int n2, int m2)
{
   real res;

   extern Model_type model;                              /* defined in dot.c */
 
   if( (m2-m1) % 2 != 0 ) {           /* only (m2-m1) even has nonzero value */ 
      return 0.0;
   }

   res = INTEGRAL(n1, m1, n2, m2, scaled_bessi); 
   res *= 2.0 * model.V0;
   
   return res;
}
