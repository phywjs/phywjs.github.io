/*----------------------------------------------------------------------------
                 H a r t r e e  -  F o c k   M e t h o d
  ----------------------------------------------------------------------------
  Compute the Hartree-Fock solution of parabolic quantum dot.
  To be able to handle general situation.  For reference, see
  "Modern Quantum Chemistry", A Szabo & N S Ostlund, McGraw-Hill, 1989.
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include "realtype.h"

/* The Model_type is (defined in realtype.h)
struct {
   real omega0;                                           zero field omega 
   real omega;                                 omega =sqrt(omega0^2+B^2/4) 
   real r0;                                    gauss bump or start of ring 
   real r1;                                             perturbation range 
   real simga2;                                       variance of gaussian 
   real V0;                                         perturbation amplitude 
   real B;                                                  magnetic field 
   real g;                                                    Lande factor 
} 
   Single particle basis energy and state labels 
   is Occ_type contains struct { real eng; int n, m, s; }
*/

                                                         /* global variables */
extern Occ_type *spsGlobal;                              /* defined in dot.c */
extern Model_type  model;                                            /* same */

int get_index(int i, int j, int size);                              /* dot.c */
real one_particle_int(int i, int j);                                 /* same */
real overlap_int(int i, int j, int k, int l);                        /* same */
int compare(Occ_type *a, Occ_type *b);                               /* same */
void eigensystem(const real *h, real *epsilon, real *psi, 
                 int dim, int nov);                               /* eigen.c */
void print_matrix(const real *h, int n);                             /* same */


/* Assuming that the single particle state spsGlobal[i] for i = 0 to size-1 
   is properly initialized, fockOP() computes the Fock operator F using 
   the coefficients of the wave function c and h1.  h1 is non-interacting 
   one-particle Hamiltonian matrix.  When converged we have F c = c eps, 
   where eps is diagonal with the eigenvalues.  F is a matrix of size by 
   size, c is size by nelec.  [opposite to Mathematica program].
   The function returns the current estimate of Hartree-Fock energy.
   p is both input (for mixing) and output.  But we do mixing only
   if mix != 0.
 */
static real fockOP(const real c[], const real h1[], real p[],
                   real F[], int nelec, int size, int mix)
{
   int a, b, u, v, n, ind;
   real dot, eng, e, g, hcore, pv;
   
                                     /* compute density operator P = C . C^T */
   for(b = 0; b < size; ++b) {
      for(a = b; a < size; ++a) {
         dot = 0.0;
         for(n = 0; n < nelec; ++n) {
            dot += c[get_index(a,n,size)] * c[get_index(b,n,size)];
         }
         ind = get_index(a,b,size);
         if(mix) {
            p[ind] = 0.4*p[ind] + 0.6*dot;                    /* mixing of P */
         } else {
            p[ind] = dot; 
         }
      }
   }

   for(b = 0; b < size; ++b) {                             /* P is symmetric */
      for(a = b+1; a < size; ++a) {
         p[get_index(b,a,size)] = p[get_index(a,b,size)];
      }
   }

   eng = 0.0;
   for(b = 0; b < size; ++b) {               /* run over F and p column-wise */
      for(a = b; a < size; ++a) {                              /* lower half */
         g = 0.0;
         for(v = 0; v < size; ++v) {
            for(u = 0; u < size; ++u) {
               pv = p[get_index(u,v,size)];
               if(fabs(pv) > 1.e-13) {
                  g += overlap_int(a, u, b, v) * pv;
               }
            }
         }
         hcore = h1[get_index(a,b,size)];
         F[get_index(a,b,size)] = hcore + g;
         e = p[get_index(a,b,size)] * (2.0*hcore + g);
         if(a == b) {            /* we don't want diagonal term summed twice */
            eng += 0.5 * e;
         } else {
            eng += e;
         }
      }
   }
   for(b = 0; b < size; ++b) {            /* upper triangle of F by symmetry */
      for(a = b+1; a < size; ++a) {
         F[get_index(b,a,size)] = F[get_index(a,b,size)]; 
      }
   }
   
   return eng;
}

/* Solve Hartree-Fock equation by looping for convergence, call Lapack 
   to solve eigenvalue problem.  We looks for single particle states 
   for with n = 0, 1, nmax, if m is fixed (fixm==1); otherwise we take 
   (nmax+1)*nelec states according to single particle energy.  The 
   states without interacting is specified by occ.  Since the total spin
   S is a good quantum number, we look for solution (by selecting a
   set of lowerst Hartree-Fock states that give S) that give a fixed
   S consistent with occ[].  nelec is the number of electrons.  The 
   coefficient c (number of basis by nelec) is returned.  Results are 
   written out for qmc.exe to read.
 */

#define HF_EPS (1.0e-6)                             /* accuracy of HF energy */
#define N_MAX 50                                         /* range of n and m */
#define M_MIN (-100)
#define M_MAX 100

real hartree_fock(FILE *fp, int nmax, Occ_type occ[], 
                  int nelec, int fixm, real c[], real *Ei)
{
   real eng, engold, err, val, norm, psimax;
   real *F, *psi, *epsilon, *h1_matel, *p;
   int i, j, jmax, k, n, m, s, cnt, size, lp, ind;
   int a, aeq, nterm, nup, ndown, up, down, S, spin;
   Occ_type *temp_occ;
   static int ncall = 0;

   ++ncall;                        /* how many times this function is called */

   size = (1+nmax) * nelec;                           /* size of HF matrix F */
   spsGlobal = (Occ_type *) malloc(size * sizeof(Occ_type)); 
   assert(spsGlobal != NULL);

   nup = 0;
   ndown = 0;
   S = 0;                                          /* count how many spin up */
   for(i = 0; i < nelec; ++i) {                      /* and spin down states */
      S += occ[i].s;
      if(occ[i].s == 1) {
         ++nup;
      } else {
         ++ndown;
      }
   }
   assert( S == (nup-ndown) );
                                                     /* generate spsGlobal[] */ 
   if(fixm) {                         /* if m_i is fixed, we run over n only */
      cnt = 0;
      for(j = 0; j < nelec; ++j) {
         m = occ[j].m;
         s = occ[j].s;
         aeq = -1;
         for(n = 0; n <= nmax; ++n) {
            if(occ[j].n == n) { aeq = cnt; }        /* which basis is input? */
            spsGlobal[cnt].eng = (2*n+abs(m)+1)*model.omega + 
                                 0.5*model.B*(m + 0.5*model.g*s);
            spsGlobal[cnt].n = n;
            spsGlobal[cnt].m = m;
            spsGlobal[cnt].s = s;
            ++cnt;
         }
         assert(aeq >= 0 && aeq < size);                        /* must find */
         if(ncall == 1) {              /* initialize c only for the 1st time */
            for(a = 0; a < size; ++a) {
               c[get_index(a,j,size)] = 0.0;
            }
            c[get_index(aeq,j,size)] = 1.0;
         }
      }
      assert(cnt == size);

   } else {   /* we run over all n,m,s, sort them and take first size states */
                                           /* input occ[] is used for S only */
      jmax = N_MAX*(M_MAX-M_MIN)*2;
      assert(jmax > nelec);
      temp_occ = (Occ_type *) malloc( jmax*sizeof(Occ_type) );
      assert(temp_occ != NULL);

      j = 0;
      for(n = 0; n < N_MAX; ++n) {
         for(m = M_MIN; m < M_MAX; ++m) {
            for(s = -1; s <= 1; s += 2) {
               temp_occ[j].eng = (2*n+abs(m)+1)*model.omega + 
                                 0.5*model.B*(m + 0.5*model.g*s);
               temp_occ[j].n = n;
               temp_occ[j].m = m;
               temp_occ[j].s = s;
               ++j;
            }
         }
      }
      assert(j == jmax);

      qsort(temp_occ, jmax, sizeof(Occ_type), compare);

      for(j = 0; j < size; ++j) {
         spsGlobal[j] = temp_occ[j]; 
      }
      free(temp_occ); 
      for(i = 0; i < size*nelec; ++i) {               /* always start from 0 */
         c[i] = 0.0;
      }
   }
 
   F = (real *) malloc( size*size*sizeof(real) );
   psi = (real *) malloc( size*size*sizeof(real) );
   epsilon = (real *) malloc( size*sizeof(real) );
   h1_matel = (real *) malloc( size*size*sizeof(real) );
   p = (real *) calloc(size*size, sizeof(real));                   /* zeroed */
   assert(F != NULL);
   assert(psi != NULL);
   assert(epsilon != NULL);
   assert(h1_matel != NULL);
   assert(p != NULL);
 
   for(j = 0; j < size; ++j) {       /* <nms|h(1)|n'm's> should compute once */
      for(i = j; i < size; ++i) {
         h1_matel[get_index(i,j,size)] = one_particle_int(i, j);
      }
   }
   for(j = 0; j < size; ++j) {                      /* h1_matel is symmetric */
      for(i = j+1; i < size; ++i) {
         h1_matel[get_index(j,i,size)] = h1_matel[get_index(i,j,size)];
      }
   }

   eng = 1.0e20;
   err = 1.0;
   lp = 0;
   while(lp < 100 && err > HF_EPS) {
      ++lp;
   
      engold = eng;
      eng = fockOP(c, h1_matel, p, F, nelec, size, (lp>2));
      err = fabs(eng - engold);
      if(fabs(eng) > 1.0) {
         err = err/fabs(eng);
      }

      if(lp == 1) {               /* energy of noninteracting trial function */
         *Ei = eng;                    /* but this is true only if ncall = 1 */
      }
      eigensystem(F, epsilon, psi, size, size);
                               /* epsilon already sorted from small to large */
      up = 0;           /* count how many up and down state collected so far */
      down = 0;
      k = 0;                                 /* count selected wavefunctions */
      for(i = 0; (i<size) && (k<nelec); ++i) {
         psimax = 0.0;
         jmax = -1;
         for(j = 0; j < size; ++j) {        /* find j with max amplitude psi */
           val = fabs(psi[get_index(j,i,size)]);
           if(val > psimax) {
              psimax = val;
              jmax = j;
           }
         }
         assert(jmax >= 0);
         spin = spsGlobal[jmax].s;             /* state psi_i has this spin */

         if ( (spin == 1 && up < nup) || (spin == -1 && down < ndown) ) {
            if(spin == 1) {
               ++up;
            } else {
               ++down;
            }
            norm = 0.0;
            for(j = 0; j < size; ++j) {
               ind = get_index(j,i,size);
               val = fabs(psi[ind]);
               norm += val*val;
               c[get_index(j,k,size)] = (val>1.0e-6)? psi[ind] : 0.0;
               if(!(c[get_index(j,k,size)] == 0.0 || spsGlobal[j].s == spin)) {
                 fprintf(stderr, 
                 "in hartree_fock(), lp=%d, mixed with difference spin, corrected.\n", lp);
                 c[get_index(j,k,size)] = 0.0;
               }
               assert(c[get_index(j,k,size)] == 0.0 || spsGlobal[j].s == spin);
            } 
            if( fabs(norm - 1.0) > 1.e-6) {
               printf("Warning, normalization problem!, norm = %g\n", 
                      (double) norm);
            }

            ++k;
         }
      }
      assert(k == nelec);
      assert(up == nup);
      assert(down == ndown);
   }
   
   if(err > 10*HF_EPS) {
      fprintf(stderr, 
         "HF did not converge after %d iterations! eng=%g, err=%g\n",
         lp, (double) eng, fabs(eng-engold) );
   }
                                                           /* output to file */
   for(i = 0; i < nelec; ++i) {
      nterm = 0;
      for(j = 0; j < size; ++j) {
         if(fabs(c[get_index(j,i,size)]) > 1.0e-4) { ++nterm; } 
      }
      fprintf(fp, "%d  ", nterm);               /* how many non-vanish coeff */
      for(j = 0; j < size; ++j) { 
         ind = get_index(j,i,size);
         if(fabs(c[ind]) > 1.0e-4) { 
            fprintf(fp, "%g %d %d %d  ", c[ind], 
                    spsGlobal[j].n,             /* st: pointer to the states */
                    spsGlobal[j].m, 
                    spsGlobal[j].s );
            
         }
      }
      fprintf(fp, "\n");                            /* one electron per line */
   }

   free(p);
   free(h1_matel);
   free(epsilon);
   free(psi);
   free(F);
   free(spsGlobal);

   return eng;
}
