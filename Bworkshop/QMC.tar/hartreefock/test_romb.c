#include <stdio.h>

#include "realtype.h"

void polint(real xa[], real ya[], int n, real x, real *y, real *dy);

main()
{
   real *xa, *ya, x, y, dy;
   int n, i;

   printf("enter n\n");
   scanf("%d", &n);

   xa = (real *) malloc((n+1)*sizeof(real));
   ya = (real *) malloc((n+1)*sizeof(real));

   printf("enter n pair of (x,y)\n");
 
   for(i = 1; i <= n; ++i) {
      scanf("%lf%lf", &xa[i], &ya[i]);
   }
   printf("enter x\n");
   scanf("%lf", &x);

   polint(xa, ya, n, x, &y, &dy);

   printf("x = %g, y = %g, dy = %g\n", x, y, dy);
   
}
