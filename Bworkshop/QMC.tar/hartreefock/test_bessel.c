#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* To use GSL (Gnu Scientific Library), compile as
   gcc -static .... -lgsl -lgslcblas
*/
#include <gsl/gsl_sf_bessel.h>

#include "realtype.h"

real bessi(int n, real x);

int main()
{
   real x, y, y1;
   double d;
   int n;

   printf("Testing modified bessel function bessi(n, x)\n");
   printf("enter n and x\n");
   scanf("%d%lf", &n, &d);

   x = d;
   y = bessi(n, x);
   printf("bessi(%d, %g) = %.15g\n", n, (double) x, (double) y);
   y1 = gsl_sf_bessel_In(n, x);
   printf("GSL version = %.15g,  dif=%g\n", (double) y1, (double) (y-y1));
 
   x = d;
   y = jn(n, x);
   printf("jn(%d, %g) = %.15g\n", n, (double) x, (double) y);
   y1 = gsl_sf_bessel_Jn(n, x);
   printf("GSL version = %.15g,  dif=%g\n", (double) y1, (double) (y-y1));
 
   return 0;
}
