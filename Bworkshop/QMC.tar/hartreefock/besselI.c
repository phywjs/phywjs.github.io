/* ---------------------------------------------------------------------------
             M o d i f i e d   B e s s e l   f u n c t i o n
   ---------------------------------------------------------------------------
   From "Numerical Recipes in C" page 237 -240 and from GSL the Gnu
   Scientific library.
*/

#include <math.h>
#include <assert.h>

#include "realtype.h"

#define GSL_SQRT_DBL_EPSILON   1.4901161193847656e-08
#define GSL_DBL_MIN        2.2250738585072014e-308
#define GSL_LOG_DBL_MAX    7.0978271289338397e+02
#ifndef M_SQRT2
#define M_SQRT2	   1.41421356237309504880168872421    
#endif

struct cheb_series_struct {
  real * c;     /* coefficients                */
  int order;    /* order of expansion          */
  real a;       /* lower interval point        */
  real b;       /* upper interval point        */
  int order_sp; /* effective single precision order */
};
typedef struct cheb_series_struct cheb_series;


static real bi0_data[12] = {
  -.07660547252839144951,
  1.92733795399380827000,
   .22826445869203013390, 
   .01304891466707290428,
   .00043442709008164874,
   .00000942265768600193,
   .00000014340062895106,
   .00000000161384906966,
   .00000000001396650044,
   .00000000000009579451,
   .00000000000000053339,
   .00000000000000000245
};
static cheb_series bi0_cs = {
  bi0_data,
  11,
  -1, 1,
  11
};

static real ai0_data[21] = {
   .07575994494023796, 
   .00759138081082334,
   .00041531313389237,
   .00001070076463439,
  -.00000790117997921,
  -.00000078261435014,
   .00000027838499429,
   .00000000825247260,
  -.00000001204463945,
   .00000000155964859,
   .00000000022925563,
  -.00000000011916228,
   .00000000001757854,
   .00000000000112822,
  -.00000000000114684,
   .00000000000027155,
  -.00000000000002415,
  -.00000000000000608,
   .00000000000000314,
  -.00000000000000071,
   .00000000000000007
};
static cheb_series ai0_cs = {
  ai0_data,
  20,
  -1, 1,
  13
};

static real ai02_data[22] = {
   .05449041101410882,
   .00336911647825569,
   .00006889758346918,
   .00000289137052082,
   .00000020489185893,
   .00000002266668991,
   .00000000339623203,
   .00000000049406022,
   .00000000001188914,
  -.00000000003149915,
  -.00000000001321580,
  -.00000000000179419,
   .00000000000071801,
   .00000000000038529,
   .00000000000001539,
  -.00000000000004151,
  -.00000000000000954,
   .00000000000000382,
   .00000000000000176,
  -.00000000000000034,
  -.00000000000000027,
   .00000000000000003
};
static cheb_series ai02_cs = {
  ai02_data,
  21,
  -1, 1,
  11
};

static real bi1_data[11] = {
  -0.001971713261099859,
   0.407348876675464810,
   0.034838994299959456,
   0.001545394556300123,
   0.000041888521098377,
   0.000000764902676483,
   0.000000010042493924,
   0.000000000099322077,
   0.000000000000766380,
   0.000000000000004741,
   0.000000000000000024
};
static cheb_series bi1_cs = {
  bi1_data,
  10,
  -1, 1,
  10
};

static real ai1_data[21] = {
  -0.02846744181881479,
  -0.01922953231443221,
  -0.00061151858579437,
  -0.00002069971253350,
   0.00000858561914581,
   0.00000104949824671,
  -0.00000029183389184,
  -0.00000001559378146,
   0.00000001318012367,
  -0.00000000144842341,
  -0.00000000029085122,
   0.00000000012663889,
  -0.00000000001664947,
  -0.00000000000166665,
   0.00000000000124260,
  -0.00000000000027315,
   0.00000000000002023,
   0.00000000000000730,
  -0.00000000000000333,
   0.00000000000000071,
  -0.00000000000000006
};
static cheb_series ai1_cs = {
  ai1_data,
  20,
  -1, 1,
  11
};

static real ai12_data[22] = {
   0.02857623501828014,
  -0.00976109749136147,
  -0.00011058893876263,
  -0.00000388256480887,
  -0.00000025122362377,
  -0.00000002631468847,
  -0.00000000383538039,
  -0.00000000055897433,
  -0.00000000001897495,
   0.00000000003252602,
   0.00000000001412580,
   0.00000000000203564,
  -0.00000000000071985,
  -0.00000000000040836,
  -0.00000000000002101,
   0.00000000000004273,
   0.00000000000001041,
  -0.00000000000000382,
  -0.00000000000000186,
   0.00000000000000033,
   0.00000000000000028,
  -0.00000000000000003
};
static cheb_series ai12_cs = {
  ai12_data,
  21,
  -1, 1,
  9
};



static real cheb_eval(const cheb_series * cs, const real x)
{
  int j;
  real d  = 0.0;
  real dd = 0.0;

  real y  = (2.0*x - cs->a - cs->b) / (cs->b - cs->a);
  real y2 = 2.0 * y;

  for(j = cs->order; j>=1; j--) {
    real temp = d;
    d = y2*d - dd + cs->c[j];
    dd = temp;
  }

  d = y*d - dd + 0.5 * cs->c[0];

  return d;
}

static real bessel_I0_scaled(const real x)
{
  real res;
  real y = fabs(x);

  if(y < 2.0 * GSL_SQRT_DBL_EPSILON) {
    res = 1.0 - y;
  }
  else if(y <= 3.0) {
    const real ey = exp(-y);
    res = cheb_eval(&bi0_cs, y*y/4.5-1.0);
    res = ey * (2.75 + res);
  }
  else if(y <= 8.0) {
    const real sy = sqrt(y);
    res = cheb_eval(&ai0_cs, (48.0/y-11.0)/5.0);
    res  = (0.375 + res) / sy;
  }
  else {
    const real sy = sqrt(y);
    res = cheb_eval(&ai02_cs, 16.0/y-1.0);
    res = (0.375 + res) / sy;
  }
  return res;
}


real bessel_I0(const real x)
{
  real y = fabs(x);
  real res;

  if(y < 2.0 * GSL_SQRT_DBL_EPSILON) {
    res = 1.0;
  }
  else if(y <= 3.0) {
    res = cheb_eval(&bi0_cs, y*y/4.5-1.0);
    res  += 2.75;
  }
  else if(y < GSL_LOG_DBL_MAX - 1.0) {
    res = bessel_I0_scaled(x);
    res  *= exp(y);
  } else {
    assert(0);
  }
  return res;
}


#define ROOT_EIGHT (2.0*M_SQRT2)

static real bessel_I1_scaled(const real x)
{
  real res;
  const real xmin    = 2.0 * GSL_DBL_MIN;
  const real x_small = ROOT_EIGHT * GSL_SQRT_DBL_EPSILON;
  const real y = fabs(x);

  if(y == 0.0) {
    res = 0.0;
  }
  else if(y < xmin) {
    assert(0);
  }
  else if(y < x_small) {
    res = 0.5*x;
  }
  else if(y <= 3.0) {
    const real ey = exp(-y);
    res = cheb_eval(&bi1_cs, y*y/4.5-1.0);
    res = x * ey * (0.875 + res);
  }
  else if(y <= 8.0) {
    const real sy = sqrt(y);
    real b;
    real s;
    res = cheb_eval(&ai1_cs, (48.0/y-11.0)/5.0);
    b = (0.375 + res) / sy;
    s = (x > 0.0 ? 1.0 : -1.0);
    res  = s * b;
  }
  else {
    const real sy = sqrt(y);
    real b;
    real s;
    res = cheb_eval(&ai12_cs, 16.0/y-1.0);
    b = (0.375 + res) / sy;
    s = (x > 0.0 ? 1.0 : -1.0);
    res = s * b;
  }
  return res;
}


real bessel_I1(const real x)
{
  real res;
  const real xmin    = 2.0 * GSL_DBL_MIN;
  const real x_small = ROOT_EIGHT * GSL_SQRT_DBL_EPSILON;
  const real y = fabs(x);

  if(y == 0.0) {
    res = 0.0;
  }
  else if(y < xmin) {
    assert(0);
  }
  else if(y < x_small) {
    res = 0.5*x;
  }
  else if(y <= 3.0) {
    res = cheb_eval(&bi1_cs, y*y/4.5-1.0);
    res = x * (0.875 + res);
  }
  else if(y < GSL_LOG_DBL_MAX) {
    res = bessel_I1_scaled(x);
    res *= exp(y);
  }
  else {
     assert(0);
  }
  return res;
}

#define ACC 80.0
#define BIGNO 1.0e10
#define BIGNI 1.0e-10

real bessi(int n, real x)
{
   int j;
   real bi, bim, bip, tox, ans;

   if( n == 0) {
      return bessel_I0(x);
   } else if (n == 1) {
      return bessel_I1(x);
   } else {
      assert(n > 1);
      if(x == 0.0) {
         return 0.0;
      } else {
         tox = 2.0/fabs(x);
         bip = ans = 0.0;
         bi = 1.0;
         for(j = 2*(n+ (int) sqrt(ACC*n) ); j > 0; j--) {
            bim = bip + j*tox*bi;
            bip = bi;
            bi = bim;
            if( fabs(bi) > BIGNO) {
               ans *= BIGNI;
               bi *= BIGNI;
               bip *= BIGNI;
            }
            if(j == n) ans = bip;
         }
         ans *= bessel_I0(x)/bi;
         return (x < 0.0 && (n & 1) ? -ans : ans);
      }
   }
}
