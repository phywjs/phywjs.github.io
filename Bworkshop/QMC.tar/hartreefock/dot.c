/*----------------------------------------------------------------------------
                     T h e   q u a n t u m   d o t
  ----------------------------------------------------------------------------
  Model related code should go here.
  (0) read_model_parameters().
  (1) computation of one_particle_int() and overlap_int() [actually two 
      particle integral].
  (2) find relevant states, find_states().
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include "realtype.h"

#define MAX_STATE_SIZE  100000       /* max memory use for collection states */
                                                         /* from integrals.c */
real devrim2D(int ni, int mi, int nj, int mj, int nk, int mk, int nl, int ml);
real perturb_matel(int ni, int mi, int nj, int mj);                  /* same */
int get_element(int n1, int m1, int n2, int m2, int n3, int m3, 
                int n4, int m4, real *val);                   /* from hash.c */
int store(real val, int n1, int m1, int n2, int m2, int n3, int m3,
                int n4, int m4);                                     /* same */

/* See realtype.h for definitions of the structure Model_type, Occ_type,
   and State_type.
*/
                                                         /* global variables */
Occ_type *spsGlobal;                             /* ghtfock.c also need this */
Model_type  model;                             /* integrals.c also need this */

/* We handle two models, the ring-bump model of cos perturbation studied by
   Guclud Devrim and double-peak/valley gaussian at (r0,0) and (-r0,0)
   of standard deviation sigma.  The default is gaussian.  #define 
   MODEL_RING_BUMP will get the ring model.
*/
void read_model_parameters(FILE *fin, FILE *fecho)
{
   double dum, dum1;
   real omega0;

   fprintf(fecho, "Model parameters -- all in (effective) atomic units\n");
   fprintf(fecho, "enter parameter omega0\n");
   fscanf(fin, "%lf", &dum);
   omega0 = dum;
   model.omega0 = omega0;
#ifdef MODEL_RING_BUMP
   fprintf(fecho, "enter perturbation range r0 r1\n");
   fscanf(fin, "%lf%lf", &dum, &dum1); 
   model.r0 = dum;
   model.r1 = dum1;
   model.sigma2 = 0.0;
   assert(model.r0 <= model.r1);
#else
   fprintf(fecho, "enter gaussian center r0 and standard deviation sigma\n");
   fscanf(fin, "%lf%lf", &dum, &dum1); 
   model.r0 = dum;
   model.r1 = 0.0;
   model.sigma2 = dum1*dum1;                     /* this is variance simga^2 */
#endif
   fprintf(fecho, "enter height of perturbation V0\n");
   fscanf(fin, "%lf", &dum); 
   model.V0 = dum;
   fprintf(fecho, "enter magnetic field B\n");
   fscanf(fin, "%lf", &dum); 
   model.B = dum;
   model.omega = sqrt( omega0*omega0 + 0.25*model.B*model.B );
   fprintf(fecho, "enter Lande factor g\n");
   fscanf(fin, "%lf", &dum); 
   model.g = dum;

   fprintf(fecho, 
        "initial model parameters: omega0=%g, omega=%g, [r0,r1,simga^2]=[%g,%g,%g], V0=%g, B=%g, g=%g\n",
            (double) model.omega0, (double) model.omega, (double) model.r0, 
            (double) model.r1, (double) model.sigma2, (double) model.V0, 
            (double) model.B, (double) model.g );
}
   
void set_B_field(real B)                              /* object-oriented way */
{
   model.B = B;                         /* when B change, omega also change! */
   model.omega = sqrt( model.omega0*model.omega0 + 0.25*model.B*model.B );
}

/* matel() decides if computation of the matrix is needed. It first checks
   if it is already on the hash table.  If not, call the integral routine 
   devrim2D(), and store the results on hash table.
 */
static real matel(int ni, int mi, int nj, int mj, 
                  int nk, int mk, int nl, int ml)
{
   int k, k1, k2, k3, k4;
   real res;

   k = get_element(ni, mi, nj, mj, nk, mk, nl, ml, &res);
   if(k >= 0) {                               /* k < 0 means it is not there */
      return res;
   } else {
      res = devrim2D(ni, mi, nj, mj, nk, mk, nl, ml);
      if(res != 0.0) {                           /* store only nonzero entry */
         k1 = store(res, ni, mi, nj, mj, nk, mk, nl, ml);
         k2 = store(res, nj, mj, ni, mi, nl, ml, nk, mk); /* due to symmetry */
         k3 = store(res, nk, mk, nl, ml, ni, mi, nj, mj); 
         k4 = store(res, nl, ml, nk, mk, nj, mj, ni, mi);
         assert(k1 >= 0);
         assert(k2 >= 0);
         assert(k3 >= 0);
         assert(k4 >= 0);
      }
      return res;
   }
}

int get_index(int i, int j, int size)         /* must use Fortran conversion */
{                                           /* because we are calling lapack */
   return (i+size*j);
}

/* one_particle_int(i,j) compute single-particle h(1) matrix element.
   i and j is indices to global single-particle states, spsGlobal.
 */
real one_particle_int(int i, int j)
{
   int ni, nj, mi, mj, si, sj;
   real res;

   res = 0.0;
   if(i == j) {
      res += spsGlobal[i].eng;
   }

   if( model.V0 != 0.0 ) {       /* contribute due to perturbation potential */
      si = spsGlobal[i].s;
      sj = spsGlobal[j].s;

      assert(abs(si)==1 && abs(sj)==1);

      if(si == sj) {               /* different spin orbitals are orthogonal */
         ni = spsGlobal[i].n;
         nj = spsGlobal[j].n;
         mi = spsGlobal[i].m;
         mj = spsGlobal[j].m;
         res += perturb_matel(ni, mi, nj, mj);
      }
   }

   return res;
}

/* overlap_int(i,j,k,l) compute the coulomb/exchange interaction.
 */
real overlap_int(int i, int j, int k, int l)
{
   int si, sj, sk, sl;
   int ni, nj, nk, nl;
   int mi, mj, mk, ml;
   real res;

   if(k == l) {                         /* due to <ij||kl> = <ij|kl>-<ij|lk> */
      return 0.0;
   }
   si = spsGlobal[i].s;
   sj = spsGlobal[j].s;
   sk = spsGlobal[k].s;
   sl = spsGlobal[l].s;
   ni = spsGlobal[i].n;
   nj = spsGlobal[j].n;
   nk = spsGlobal[k].n;
   nl = spsGlobal[l].n;
   mi = spsGlobal[i].m;
   mj = spsGlobal[j].m;
   mk = spsGlobal[k].m;
   ml = spsGlobal[l].m;

   assert(abs(si)==1 && abs(sj)==1 && abs(sk)==1 && abs(sl)==1);

   res = 0.0;
   if(si == sk && sj == sl) {
      res += matel(ni, mi, nj, mj, nk, mk, nl, ml);
   }
   if(si == sl && sj == sk) {
      res -= matel(ni, mi, nj, mj, nl, ml, nk, mk);
   }

   return res * sqrt(model.omega);
}


/* utility for find_states() */

int compare(Occ_type *a, Occ_type *b)
{
  if((*a).eng < (*b).eng) {
    return -1;
  } else if ((*a).eng == (*b).eng) {
    return 0;
  } else {
    return 1;
  }
}

static int compare_state(State_type *a, State_type *b)
{
  if((*a).Eng < (*b).Eng) {
    return -1;
  } else if ((*a).Eng == (*b).Eng) {
    return 0;
  } else {
    return 1;
  }
}

static double binomial(int n, int m)
{
   int k, i;
   double prod;

   k = (m < (n-m)) ? m : (n-m);                      /* take the smaller one */
   prod = 1.0;
   for(i = 1; i <= k; ++i) {                       /* compute  n!/(m!(n-m)!) */
      prod *= (double) (n-i+1)/ (double) i;
   };
   return prod;
}

/* Find the first state_size many-body wavefunction basis, based on 
   single particle energy and S^2 correction.  find_states() also set
   the spsGlobal array (of size nelec+nex).  nelec: number of electrons, 
   nex : extra number of single particle states.  If fixedLS is true (1),
   we find only L==Lin and S==Sin states, otherwise, all states are 
   considered.  pickedstate: return list of states.  The function 
   return the number of picked good states, which can be less than 
   state_size asked for.  The calling program is responsible
   for the memory of spsGlobal and pickedstate.
*/
#define N_MAX 50
#define M_MIN (-100)
#define M_MAX 100
#define modelK  0.27
#define modelJ  0.80

int find_states(int no_elec, int nex, int fixedLS, int Lin, int Sin,
                 int state_size, State_type *pickedstate)
{
   double omega, B, g, etot;
   Occ_type *temp_occ;
   State_type *state;
   int i, j, jmax, k, n, m, s, L, S;
   int cnt, seq, seqmax, state_length, useful_length, use;
   int *remove, *has;

   jmax = N_MAX*(M_MAX-M_MIN)*2;
   assert(nex+no_elec <= jmax);
   temp_occ = (Occ_type *) malloc( jmax*sizeof(Occ_type) );
   assert(temp_occ != NULL);

   omega = model.omega;
   B = model.B;
   g = model.g;
   j = 0;
   for(n = 0; n < N_MAX; ++n) {
      for(m = M_MIN; m < M_MAX; ++m) {
         for(s = -1; s <= 1; s += 2) {
            temp_occ[j].eng = (2*n + 1 + abs(m))*omega + 0.5*B*(m + 0.5*g*s);
            temp_occ[j].n = n;
            temp_occ[j].m = m;
            temp_occ[j].s = s;
            ++j;
         }
      }
   }
   assert(j == jmax);

   qsort(temp_occ, jmax, sizeof(Occ_type), compare);

   for(j = 0; j < no_elec + nex; ++j) {
      spsGlobal[j] = temp_occ[j];    /* spsGlobal memory allocated by main() */
   }
       
   free(temp_occ);

/* We need to do a combinatorial choice of no_elec from nex + no_elec.
   We remove nex orbitals from total nex+no_elec.  remove[i] is the
   index to orbital spsGlobal[] that is removed.  We maintain 
   remove[i] < remove[i+1].  The outer while loop runs exactly 
   (no_elec+nex)!/(nex! * no_elec!) times.  We generate all the states 
   and sort them according to total energy.
 */

   remove = (int *) malloc( (nex+1)*sizeof(int));
   has = (int *) malloc( (no_elec+nex)*sizeof(int) );
   assert(remove != NULL);
   assert(has != NULL);

   state_length = binomial( no_elec+nex, nex ) + 0.001;
   if(state_length > MAX_STATE_SIZE) {               /* limit the memory use */
      state_length = MAX_STATE_SIZE;
   }
   state = (State_type *) malloc(state_length*sizeof(State_type));
   assert(state != NULL);

   for(i = 0; i < nex; ++i) {            /* initially, last nex are not used */
     remove[i] = no_elec + i;
   }
   remove[nex] = 0;               /* extra counter for terminating condition */

   seq = 0;                                           /* all possible states */
   use = 0;                                                   /* used states */
   while(remove[nex] == 0) {
      for(j = 0; j < nex+no_elec; ++j) {
         has[j] = 1;
      }
      for(i = 0; i < nex; ++i) {
         assert(remove[i]>=0 && remove[i] < no_elec+nex);
         assert(remove[i] < remove[i+1] || i == (nex-1));
         has[remove[i]] = 0; 
      }

      state[use].ind = (int *) malloc( no_elec*sizeof(int) );
      assert(state[use].ind != NULL);
      etot = 0.0;
      L = 0;
      S = 0;
      cnt = 0;
      for(j = 0; j < nex+no_elec; ++j) {
         if(has[j]) {
            state[use].ind[cnt] = j;
            etot += spsGlobal[j].eng;
            L += spsGlobal[j].m;
            S += spsGlobal[j].s;
            ++cnt;
         }
      }
      assert(cnt == no_elec);
                                  /* energy use a constant interaction model */
      state[use].Eng = etot + sqrt(omega)*( - 0.25*modelK*S*S   
                       + 0.5*no_elec*(no_elec-1)*modelJ 
                       - 0.25*no_elec*(no_elec-2)*modelK );
      state[use].L = L;
      state[use].S = S;

      if(fixedLS) { /* advance counter only if it is what we are looking for */
         if(fixedLS == 2) {
            if(state[use].L == Lin && state[use].S == Sin) {
               ++use;
            }
         } else if (fixedLS == 1) {
            if(state[use].S == Sin) {
                ++use;
            }
         }
      } else {
         ++use;
      }

      --remove[0]; 
      if(remove[0] < 0) {              /* trick, move but keep the less than */
         k = 0;
         while( remove[k] < k && k < nex) {
            --remove[k+1];
            for(j = k; j >= 0; --j) {
               remove[j] = remove[j+1]-1;
            }
            ++k;
         }
      }

      ++seq;

      if(use >= state_length) {
         fprintf(stderr, 
            "in find_states(), too many states, no more memory to store\n");
         break;
      }
      
   }

   useful_length = use;
   assert(useful_length <= seq);
   printf("find %d good states\n", useful_length);
   
   qsort(state, useful_length, sizeof(State_type), compare_state);

   seqmax = (state_size < useful_length) ? state_size : useful_length;
   for(seq = 0; seq < seqmax; ++seq) {
      if(fixedLS == 2) {
         assert(state[seq].L == Lin && state[seq].S == Sin);
      } else if(fixedLS == 1) {
         assert(state[seq].S == Sin);
      };
      pickedstate[seq].Eng = state[seq].Eng; 
      pickedstate[seq].L = state[seq].L;    
      pickedstate[seq].S = state[seq].S;
      for(j = 0; j < no_elec; ++j) {
         pickedstate[seq].ind[j] = state[seq].ind[j];
      }
   } 
  
   for(seq = 0; seq < useful_length; ++seq) {           /* state is 2D array */
      free(state[seq].ind);
   }
   free(state);
   free(has);
   free(remove); 

   return seqmax;
}
