/** test constructH.c
**/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include "realtype.h"

int find_difference(const int *indA, const int *indB, int nelec, 
                           int *sA, int *sB, int *same);
int find_sign(const int *ind, int nelec, const int *sA, int ndif);

main()
{
   int *indA, *indB, *sA, *sB, *same;
   int i, nelec, no_same, ndif, sgn;

   printf("Test find_difference()\n");
   printf("enter nelec, and two list of nelec numbers\n");
   scanf("%d", &nelec);
   indA = (int *) malloc(nelec*sizeof(int));
   indB = (int *) malloc(nelec*sizeof(int));
   sA = (int *) malloc(nelec*sizeof(int));
   sB = (int *) malloc(nelec*sizeof(int));
   same = (int *) malloc(nelec*sizeof(int));
   assert(indA != NULL);
   assert(indB != NULL);
   assert(sA != NULL);
   assert(sB != NULL);
   assert(same != NULL);

   for(i = 0; i < nelec; ++i) {
      scanf("%d", &indA[i]);
   }
   for(i = 0; i < nelec; ++i) {
      scanf("%d", &indB[i]);
   }
   no_same = find_difference(indA, indB, nelec, sA, sB, same);
   printf("for (");
   for(i = 0; i < nelec; ++i) {
      printf("%d, ", indA[i]);
   }
   printf(") and \n    (");
   for(i = 0; i < nelec; ++i) {
      printf("%d, ", indB[i]);
   }
   ndif = nelec - no_same;
   printf(")\n the extra number in A is (");
   for(i = 0; i < ndif; ++i) {
      printf("%d, ", sA[i]);
   }
   printf(")\n the extra number in B is (");
   for(i = 0; i < ndif; ++i) {
      printf("%d, ", sB[i]);
   }
   printf(")\n and the common number is (");
   for(i = 0; i < no_same; ++i) {
      printf("%d, ", same[i]);
   }
   printf(")\n");

   sgn = find_sign(indA, nelec, sA, ndif);
   printf("the sign to move the extra number in front for A is %d\n", sgn);
   sgn = find_sign(indB, nelec, sB, ndif);
   printf("the sign to move the extra number in front for B is %d\n", sgn);

}
