#include <stdio.h>
#include <complex.h>
#include <math.h>

#include "complex.h"

main()
{
   _Complex x, y, z;
   double a, b;
   complex cx, cy, cz;

   z = 0.500002 + 2.3*I;
   a = creal(z);
   b = cimag(z);
   printf("z=(%f, %f)\n", a, b);

   x = 1.5 + 2.0*I;
   a = creal(x);
   b = cimag(x);
   printf("x=(%f, %f)\n", a, b);
   cx.Re = a;
   cx.Im = b;

   y = 5.5 + 1.0*I;
   a = creal(y);
   b = cimag(y);
   printf("y=(%f, %f)\n", a, b);
   cy.Re = a;
   cy.Im = b;

   z = x + y;
   a = creal(z);
   b = cimag(z);
   printf("x+y=(%f, %f)\n", a, b);
   cz = c_add(cx,cy);
   printf(" my x+y=(%f, %f)\n", cz.Re, cz.Im);
   
   z = x - y;
   a = creal(z);
   b = cimag(z);
   printf("x-y=(%f, %f)\n", a, b);
   cz = c_sub(cx,cy);
   printf(" my x-y=(%f, %f)\n", cz.Re, cz.Im);

   z = x * y;
   a = creal(z);
   b = cimag(z);
   printf("x*y=(%f, %f)\n", a, b);
   cz = c_mul(cx,cy);
   printf(" my x*y=(%f, %f)\n", cz.Re, cz.Im);
   
   z = x / y;
   a = creal(z);
   b = cimag(z);
   printf("x/y=(%f, %f)\n", a, b);
   cz = c_div(cx,cy);
   printf(" my x/y=(%f, %f)\n", cz.Re, cz.Im);
   cz = c_conj(cx);
   printf(" my conj (x)=(%f, %f)\n", cz.Re, cz.Im);

   printf("|x| = %f\n", cabs(x));
   a = c_abs(cx);
   printf(" my |x|=%f\n", a);

   z = x * 4.0;
   a = creal(z);
   b = cimag(z);
   printf("4x=(%f, %f)\n", a, b);

   z = x + 1.0;
   a = creal(z);
   b = cimag(z);
   printf("1+x=(%f, %f)\n", a, b);

   z = csin(x);
   a = creal(z);
   b = cimag(z);
   printf("csin(x) =(%f, %f)\n", a, b);
   
   printf("sizeof(z) = %d\n", sizeof(z));

   y = 0 + 0*I;
   z = x/y;
   a = creal(z);
   b = cimag(z);
   printf("x/0 = (%f, %f)\n", a, b);
   cy.Re = 0;
   cy.Im = 0;
   cz = c_div(cx, cy);
   printf("  my x/0 = (%f, %f)\n", cz.Re, cz.Im);
   
}
