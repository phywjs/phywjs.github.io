/** run the QMC program, scanning for values of the occupations.
    This is changed to compute the coulomb part of energy 
    Q1 = <psi|1/r|psi> (at omega = 1)
 **/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <assert.h>

/* Single particle basis energy and state labels 
 */
typedef struct {
   double eng;
   int n, m, s;
} Occ_type;

static int compare(Occ_type *a, Occ_type *b)
{
  if((*a).eng < (*b).eng) {
    return -1;
  } else if ((*a).eng == (*b).eng) {
    return 0;
  } else {
    return 1;
  }
}

int main(int argc, char **argv)
{
   FILE *fin, *fout, *fp;
   char infile[200], resfile[200], logfile[200];
   char commd[200], delete[200], str[200];
   double omega0, omega, B, g, Eng, Q1;
   double dum, dum1;
   double Bin, ein;
   Occ_type *temp_occ;
   int i, j, jmax, k, n, m, s, L, S, DMC, Lin, Sin;
   int line, nex, no_elec, cnt, seq;
   int *remove, *has;
   time_t tm;

   if(argc != 4) {
      printf("use: %s exec_file input_file nex\n", argv[0]);
      exit(0);
   }

/* use all information provided in input_file except the
   occupation.  We use nex >= 0 more states to scan the occupations
 */
   nex = atoi(argv[3]);
   assert(nex < 100 && nex >=0);

   strncpy(infile, argv[2], 100);
   strncat(infile, ".sin", 4);
   strncpy(resfile, argv[2], 100);
   strncat(resfile, ".sres", 5);
   strncpy(logfile, argv[2], 100);
   strncat(logfile, ".slog", 5);
   
   sprintf(commd, "%s %s %s 1>>%s 2>>%s\n", 
           argv[1], infile, resfile, logfile, logfile);
   sprintf(delete, "rm -f %s\n", resfile);
   printf("Run %s", commd);
   printf("For input file %s\n", argv[2]);

   fin = fopen(argv[2], "r");
   fscanf(fin, "%lf", &omega0);
   fscanf(fin, "%lf%lf", &dum, &dum1);     /* skip r0 r1 */
   fscanf(fin, "%lf", &dum);               /* skip V0 */
   fscanf(fin, "%lf", &B);
   fscanf(fin, "%lf", &g);
   fscanf(fin, "%lf", &dum);               /* D */
   fscanf(fin, "%d", &no_elec);
   fscanf(fin, "%lf", &dum);               /* skip no_walkers */
   fscanf(fin, "%lf", &dum);               /* skip tau */
   fscanf(fin, "%d", &DMC);
   fclose(fin);

   if(DMC) {
      printf("Warning! it only makes sense to run in VMC mode!\n");
   }
   omega = sqrt(omega0*omega0+0.25*B*B);
   printf("Scan for omega=%g, B=%g, g=%g, elec N=%d, extra %d states\n",
           omega, B, g, no_elec, nex);

   /* find possible candidates by sorting from single particle
      energy. May be improved by taking into account of interactions.
   */
#define N_MAX 50
#define M_MIN (-100)
#define M_MAX 100

   jmax = N_MAX*(M_MAX-M_MIN)*2;
   assert(jmax > no_elec);
   temp_occ = (Occ_type *) malloc( jmax*sizeof(Occ_type) );
   assert(temp_occ != NULL);

   j = 0;
   for(n = 0; n < N_MAX; ++n) {
      for(m = M_MIN; m < M_MAX; ++m) {
         for(s = -1; s <= 1; s += 2) {
            temp_occ[j].eng = (2*n + 1 + abs(m))*omega + 
                               0.5*B*(m + 0.5*g*s);
            temp_occ[j].n = n;
            temp_occ[j].m = m;
            temp_occ[j].s = s;
            ++j;
         }
      }
   }
   assert(j == jmax);

   qsort(temp_occ, jmax, sizeof(Occ_type), compare);

/* output in a format suitable for Mathematica to read.
*/
   tm = time(NULL);
   printf("starting at %s", ctime(&tm) );
   printf("first %d single particle states are (n,m,s,eng):\n", no_elec+nex);
   for(j = 0; j < no_elec + nex; ++j) {
      printf("state[%d] = {%d, %d, %d};\n", j, 
              temp_occ[j].n, temp_occ[j].m,
              temp_occ[j].s);
   }
       
/* we need to do a combinatorial choice of no_elec from nex + no_elec.
   We remove nex orbitals from total nex+no_elec.  remove[i] is the
   index to orbital temp_occ that is removed.  We maintains 
   remove[i] < remove[i+1].  The outer while loop runs exactly 
   (no_elec+nex)!/(nex! * no_elec!) times.
 */

   remove = (int *) malloc( (nex+1)*sizeof(int));
   has = (int *) malloc( (no_elec+nex)*sizeof(int) );
   assert(remove != NULL);
   assert(has != NULL);

   assert(nex+no_elec <= jmax);
   for(i = 0; i < nex; ++i) {           /* initially, last nex are not used */
     remove[i] = no_elec + i;
   }
   remove[nex] = 0;

   printf("psi={\n");
   seq = 0;
   while(remove[nex] == 0) {
      for(j = 0; j < nex+no_elec; ++j) {
         has[j] = 1;
      }
      for(i = 0; i < nex; ++i) {
         assert(remove[i]>=0 && remove[i] < no_elec+nex);
         assert(remove[i] < remove[i+1] || i == (nex-1));
         has[remove[i]] = 0; 
      }

      fin = fopen(argv[2], "r");
      fout = fopen(infile, "w");

      line = 0;                        /* copy all lines before the occ list */
      while( fgets(str, 100, fin) != NULL && line < 13) {
         ++line;
         fputs(str, fout);
      }
      cnt = 0;                                       /* write new occupation */
      L = 0;
      S = 0;
      Eng = 0;
      printf("{{");
      for(j = 0; j < nex+no_elec; ++j) {
         if(has[j]) {
            ++cnt;
            if(cnt < no_elec) { 
               printf("%d, ", j); 
            } else {
               printf("%d}, ", j);
            }
            fprintf(fout, "%d %d %d\n", 
               temp_occ[j].n, temp_occ[j].m, temp_occ[j].s);
            L += temp_occ[j].m;
            S += temp_occ[j].s;
            Eng += temp_occ[j].eng;
         }
      }
      assert(cnt == no_elec);
      fclose(fin);
      fclose(fout);

      system(commd);                                          /* run qmc.exe */

      fp = fopen(resfile, "r");                         /* read the res file */
      fscanf(fp, "%lf%lf%d%d", &Bin, &ein, &Lin, &Sin);
      fclose(fp);
      assert(fabs(B-Bin) < 1.0e-6);    /* make sure we read the correct file */
      assert(Lin == L);
      assert(Sin == S);

      Q1 = (ein - Eng)/sqrt(omega);

      system(delete);                                     /* delete res file */
      
      --remove[0]; 
      if(remove[0] < 0) {              /* trick, move but keep the less than */
         k = 0;
         while( remove[k] < k && k < nex) {
            --remove[k+1];
            for(j = k; j >= 0; --j) {
               remove[j] = remove[j+1]-1;
            }
            ++k;
         }
      }

      ++seq;
      if(remove[nex] == 0) {
         printf("%g},\n", Q1);
      } else {
         printf("%g}}\n", Q1);
      }
      fflush(stdout);
   }
   
   tm = time(NULL);
   printf("ended at %s", ctime(&tm) );
   printf("total %d many-body wavefunctions, finished!\n", seq);
   
   free(temp_occ);
   free(has);
   free(remove);
   return 0;
}
