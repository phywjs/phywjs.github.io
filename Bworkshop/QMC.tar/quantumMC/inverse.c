/*-----------------------------------------------------------------------------
                           I N V E R S E   M A T R I X
 ------------------------------------------------------------------------------
 compute, update, and print inverse matrix elements C.
 */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>
#include "datatype.h"
#include "complex.h"

int get_index(int i, int j, int n);
void inverseSM(const real a[], int n, real inv[]);
void inverse(real a[], int n, real inv[]);
void sherman_morrison(real C[], int n, real v[], real u[], int l);
void lubksb(real a[], int n, int indx[], real b[]);
int LU_decomp(real a[], int n, int indx[]);
void print_matrix(const real a[], int n);

#ifdef COMPLEX_H
void c_sherman_morrison(complex C[], int n, complex v[], complex u[], int l);
complex c_determinant(complex a[], int n);
void print_c_matrix(const complex a[], int n);
#endif

/* Apply Sherman-Morrison n times. 
   This is much less accurate than LU decomposition, put here
   for debugging only.
 */
void inverseSM(const real a[], int n, real inv[])
{
   real *u, *v;
   int i, j;

   u = (real *) malloc(sizeof(real)*n);
   v = (real *) malloc(sizeof(real)*n);

   /* starting with identity matrix */
   for(i = 0; i < n; ++i) {
      for(j = 0; j < n; ++j) {
         if(i == j) {
            inv[get_index(i,j,n)] = 1.0;
         } else {
            inv[get_index(i,j,n)] = 0.0;
         }
      }
   }

   /* addition each row to 'a'. */
   for(i = 0; i < n; ++i) {
      for(j = 0; j < n; ++j) {
         v[j] = a[get_index(i,j,n)];
      }
      v[i] -= 1.0;
      sherman_morrison(inv, n, v, u, i);
   }

   free(u);
   free(v);
}

/* Sherman-Morrison formula, see "Numerical Recipes", page 73.
   (A+ uv^T)^(-1) = A^(-1) - (A^(-1).u)[v.A^(-1)]^T/(1+lambda),
    lambda = v.A^(-1).u.
   where u and v are column vectors.
   In this implementation, we assume u_i = delta_(i,l), so
   that uv^T is zero except the l-th row.
   The operation take O(N^2) steps.

   Input/output - C[]: matrix A^(-1) of n by n.
   input - n: matrix/vector size,
           l: lth row is added to A. 
           *v: vector of size n.
           *dum: temporary memory of size n.
 */
void sherman_morrison(real C[], int n, real v[], real dum[], int l)
{
   real factor, mul, u;
   int i, j;

   u = 0.0;
   for(i = 0; i < n; ++i) {
      dum[i] = C[get_index(i,l,n)];
      u += v[i]*dum[i];
   }

   factor = 1.0/(1.0+ u);                       /* bad then u[l] is near -1 */

   for(j = 0; j < n; ++j) {
      u = 0.0;
      for(i = 0; i < n; ++i) {
         u += v[i]*C[get_index(i,j,n)];
      }
      mul = u * factor;
      for(i = 0; i < n; ++i) {
         C[get_index(i,j,n)] -= mul * dum[i]; 
      }
   }
}


#ifdef COMPLEX_H
void c_sherman_morrison(complex C[], int n, complex v[], complex dum[], int l)
{
   complex factor, mul, u, z;
   real u2;
   int i, j, k;

   u.Re = 0.0;
   u.Im = 0.0;
   for(i = 0; i < n; ++i) {
      dum[i] = C[get_index(i,l,n)];            /* dum[] is l-th column of C */
      z = c_mul(v[i], dum[i]);
      u = c_add(u, z);
   }

   u2 = (1.0+u.Re)*(1.0+u.Re) + u.Im*u.Im;
   factor.Re = (1+u.Re)/u2;
   factor.Im = - u.Im/u2;
   
   for(j = 0; j < n; ++j) {
      u.Re = 0.0;
      u.Im = 0.0;
      for(i = 0; i < n; ++i) {
         z = c_mul(v[i], C[get_index(i,j,n)]);
         u = c_add(u, z);
      }
      mul = c_mul(u, factor);
      for(i = 0; i < n; ++i) {
         z = c_mul(mul, dum[i]); 
         k = get_index(i,j,n);
         C[k] = c_sub(C[k], z);
      }
   }
}
#endif

/* Determinant by LU factorization, permuted a[] is replaced by LU factor!
 * "Numerical Recipes in C", page 46.
 */
real determinant(real a[], int n)                     /* input a[] destroyed */
{
   real prod;
   int j;
   int *indx;

   indx = (int *) malloc(n*sizeof(int));
   assert(indx != NULL);

   prod = (real) LU_decomp(a, n, indx);

   for(j = 0; j < n; ++j) {
      prod *= a[get_index(j,j,n)];
   }

   free(indx);

   return prod;
}

/* Complex number version using minor expansion - this is very slow O(N!), 
   but for test only.
 */
#ifdef COMPLEX_H
complex c_determinant(complex a[], int n)
{
   complex det, z, *b;
   int i, j, k, kb;

   assert(n>0);
   if(n==1) {
      return a[0];
   } else {
      det.Re = 0.0;
      det.Im = 0.0;
      b = (complex *) malloc((n-1)*(n-1)*sizeof(complex));
      assert(b != NULL);
      for(j = 0; j < n; ++j) {                        /* over first row of a */
         kb = 0;
         for(k = 0; k < n; ++k) {
            if(k == j) { continue; }                     /* omit j-th column */
            for(i = 1; i < n; ++i) {
               b[get_index(i-1,kb,n-1)] = a[get_index(i,k,n)];
            }
            ++kb;
         }
         assert(kb == (n-1));
         z = c_determinant(b, n-1);
         z = c_mul(z, a[get_index(0,j,n)]);
         if((j % 2) == 0) {
            det = c_add(det, z);
         } else {
            det = c_sub(det, z);
         }
      };
      free(b);
      return det;
   }
}
#endif


/* inverse using LU decomposition
 */
void inverse(real a[], int n, real inv[])
{
   real *col;
   int *indx;
   int i, j;

   indx = (int *) malloc(n*sizeof(int));
   assert(indx != NULL);
   col = (real *) malloc(n*sizeof(real));
   assert(col != NULL);

   (void) LU_decomp(a,  n, indx);                         /* parity not used */

    for(j = 0; j < n; ++j) {                        /* solve Eq. A c_j = e_j */
       for(i = 0; i < n; ++i) {
          col[i] = 0.0;
       }
       col[j] = 1.0;
       lubksb(a, n, indx, col);
       for(i = 0; i < n; ++i) {
          inv[get_index(i,j,n)] = col[i];
       }
    }

   free(indx);
   free(col);
}

/* Solve equation A b = e_j by backward substitution,
   where A is n x n matrix, b is column vector, e_j is unit vector
   at j-th direction.
 */
void lubksb(real a[], int n, int indx[], real b[])
{
   int i, ii, ip, j;
   real sum;

   ii = -1;

   for(i = 0; i < n; ++i) {
      ip = indx[i];
      sum = b[ip];
      b[ip] = b[i];
      if(ii>=0) {
         for(j = ii; j <=i-1; ++j) {
            sum -= a[get_index(i,j,n)]*b[j];
         }
      } else if (sum != 0.0) {
         ii = i;
      }
      b[i] = sum;
   }
   for(i = n-1; i >= 0; --i) {
      sum = b[i];
      for(j = i+1; j < n; ++j) {
         sum -= a[get_index(i,j,n)]*b[j];
      }
      b[i] = sum/a[get_index(i,i,n)];
   }
}

/* do LU decomposition with partial pivot (row exchange)
 */
int LU_decomp(real a[], int n, int indx[])
{
   int i, imax, j, k, d;
   real big, dum, sum, temp;
   real *vv;

   vv = (real *) malloc(n*sizeof(real));
   assert(vv != NULL);

   d = 1;                                             /* (-1)^no_interchange */
   for(i = 0; i < n; ++i) {
      big = 0.0;
      for(j = 0; j < n; ++j) {                          /* find max in a row */
         if( (temp=fabs(a[get_index(i,j,n)])) > big) {
            big = temp;
         }
      }
      assert(big != 0.0);
      vv[i] = 1.0/big;
   }

   for(j = 0; j < n; ++j) {                             /* loop over columns */
      for(i = 0; i < j; ++i) {
         sum = a[get_index(i,j,n)];
         for(k = 0; k < i; ++k) {
            sum -= a[get_index(i,k,n)]*a[get_index(k,j,n)];
         }
         a[get_index(i,j,n)] = sum;
      }
      big = 0.0;
      for(i = j; i < n; ++i) {
         sum = a[get_index(i,j,n)];
         for(k = 0; k < j; ++k) {
            sum -= a[get_index(i,k,n)] * a[get_index(k,j,n)];
         }
         a[get_index(i,j,n)] = sum;
         if( (dum=vv[i]*fabs(sum)) >= big) {
            big = dum;
            imax = i;
         }
      }
      if(j != imax) {
         for(k = 0; k < n; ++k) {                        /* interchange rows */
            dum = a[get_index(imax,k,n)];
            a[get_index(imax,k,n)] = a[get_index(j,k,n)];
            a[get_index(j,k,n)] = dum;
         }
         d = -d;                                            /* change parity */
         vv[imax] = vv[j];
      }
      indx[j] = imax;
      if(j != (n-1)) {
         dum = 1.0/a[get_index(j,j,n)];
         for(i = j+1; i < n; ++i) {
            a[get_index(i,j,n)] *= dum;
         }
      }
   }                                                 /* end run over columns */
   free(vv);

   return d;
}


void print_matrix(const real a[], int n)
{
   int i, j;
 
   for(i = 0; i < n; ++i) {
      for(j = 0; j < n; ++j) {
         printf("%f ", (double) a[get_index(i,j,n)]);
      }
      printf("\n");
   }
}


#ifdef COMPLEX_H
void print_c_matrix(const complex a[], int n)
{
   int i, j;
 
   for(i = 0; i < n; ++i) {
      for(j = 0; j < n; ++j) {
         printf("(%f %f) ", (double) a[get_index(i,j,n)].Re,
                       (double) a[get_index(i,j,n)].Im);
      }
      printf("\n");
   }
}
#endif


int get_index(int i, int j, int n)
{
   assert(i>=0 && i<n);
   assert(j>=0 && j<n);
   return (i+j*n);                         /* column-wise Fortran convention */
}
