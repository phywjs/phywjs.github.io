/* ----------------------------------------------------------------------------
        R A N D O M   W A L K / D I F F U S I O N   M O N T E   C A R L O
   --------------------------------------------------------------------------
   References: [1] W. M. C. Foulkes, L. Mitas, R. J. Needs, and G. Rajagopal,
                   Rev. Mod. Phys. 73 (2001) 33;
               [2] C. J. Umrigar et al, J. Chem. Phys. 99 (1993) 2865;
               [3] D. M. Ceperley, Lectures on Quantum Monte Carlo, May 1996.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include "datatype.h"                        /* State, real, EPSILON defined */
                                         /* external functions in psi.c used */
void init_psi_inverse(real R[]);                           /* setup matrix C */
void update_psi_inv(real R[], real r_new, int i);            /* C <= C + ... */
int check_inverse_matrix(real R[]);                    /* check theta C == 1 */
real get_psi_ratio(real R[], real R_i, int i);             /* Psi(R')/Psi(R) */
real get_velocity(real R[], int i);                         /* ditto, v_i(R) */
real get_local_energy(real R[], int dof);                           /* ditto */

                                           /* functions defined in this file */
int walk(real R[], int no_dof, real tau); 
real smooth(real v, real tau);
real evolve(int mcstep, State *s, int DMC);
void init(State *s, FILE *fp);
void save_walkers(State *s, FILE *fp);
double drand_gaussian(void);
double drand64(void);
void srand64(long seed);


/* Core routine to attempt one time-step move of ONE walker; each degree 
   of freedom is moved once, one by one.  Compute the necessary information 
   to make the move. 

   Inputs: R[] -- Cartesian coordinates of all electrons (one walker),
           no_def -- size of R[]/the number of degrees of freedom (=N*D),
           tau -- time step size.
   Return value: number of moves made.
*/

int walk(real R[], int no_dof, real tau) 
{
   real r, rnew;                            /* R_i original and new position */
   real v, vnew;             /* ith velocity component before and after move */
   real A, ratio, sqrt_tau;         /* A=G_d(..)/G_d(..), ratio=(Psinew/Psi) */
   int i, moved;

   assert(R != NULL); 
   assert(no_dof > 0 && no_dof < 5000);
   assert(tau > 0.0 && tau < 2.0);

   sqrt_tau = sqrt(tau);
   moved = 0;                                     /* count of accepted moves */
   init_psi_inverse(R);               /* compute matrix theta_k(r_i) inverse */

   for(i = 0; i < no_dof; ++i) {           /* go over each degree of freedom */

   /* (1) Evaluate the ith component of velocity v_i = Psi^(-1)d Psi_T /dx_i.
          Is it more efficient to compute the velocity in one go? Or component
          by component?  we need to pass v to a smooth function to avoid 
          divergence.
    */
      v = get_velocity(R, i);
      v *= smooth(v, tau);

   /* (2) Propagate the ith component in time step tau.  Notice that
          variance of the gaussian distribution is tau, thus the 
          standard deviation is sqrt(tau). 
    */
      rnew = R[i] + sqrt_tau*drand_gaussian() + tau*v;

   /* (3) Compute Psi_T(R')/Psi_T(R), ratio of new to old.
          Reject the move if walker crossed node (this cannot happen
          in the fixed-phase DMC)?
    */
      ratio = get_psi_ratio(R, rnew, i);
                          /* We allow walkers to cross node. 
                             code commented out: if (ratio < 0.0) { continue; }
                           */

   /* (4) Compute the acceptance rate according to the formula
          min[1, G_d(R<-R') Psi(R')^2/ (G_d(R'<-R) Psi(R)^2 ]
          where R' is new, R is the old state.  G_d(R'<-R) is 
          a Gaussian distribution centered on R + tau*v(R) with 
          variance tau.
    */
      update_psi_inv(R, rnew, i);    /*  up-to-date C for vnew being correct */
      r = R[i];                                     /* remember the original */
      R[i] = rnew;                                 /* change R[] temporarily */
      vnew = get_velocity(R, i);            /* compute G_d(R<-R')/G_d(R'<-R) */
      vnew *= smooth(vnew, tau);
      A = exp( (v+vnew) * ( (r-rnew) + 0.5*tau*(v-vnew) ) ); 
      A = A * ratio * ratio;                   /* no need to cut back A to 1 */
      if (drand64() < A) { 
         ++moved;
      } else {
         update_psi_inv(R, r, i);                    /* undo the update to C */
         R[i] = r;                                            /* restore R[] */
      }

   }                                    /* end for each degree i of freedom  */
   /* the step (5), growing/shrinking population is done in calling routine. */
   
   assert(check_inverse_matrix(R) || no_dof == i);

   return moved;
}


/* This function is used to overcome divergence near a node for the
   velocity (limit to sqrt(2/tau)) and for the local energy.
*/
real smooth(real v, real tau)
{
   return 2.0/(1.0+sqrt(1.0+2.0*v*v*tau));        /* Umrigar smooth function */
}


/* Function evolve():
   Here is a high-level management of the walkers, (1) how many
   walkers we have currently, (2) which ones we want to move, (3) if
   we need to duplicate or delete walkers.
   Input: mcstep -- Monte Carlo steps, mcstep*tau is total evolving time, 
          s -- (pointer to) structure contains current state of the walker,
          DMC -- true if we do DMC, otherwise do variational MC.
   Return value: the average acceptance rate.
*/

real evolve(int mcstep, State *s, int DMC)
{
   real **R, **Rnew, **Rtmp;                 /* pointers to array of walkers */
   real *ptmp;                     /* temporary pointer for swapping v and E */
   real tau, tau_eff;                    /* original and effective time step */
   real Et;                                              /* trial energy E_T */
   real El, Elnew;                 /* local energy before and after the move */
   real val;                                            /* death/growth rate */
   real acc_rate;                                         /* acceptance rate */
   real y;                                          /* log number of walkers */
   int acc_cnt;                                         /* count of acc_rate */
   int M_new;               /* each one walk duplicates to M_new new walkers */
   int no_dof, no_walkers;       /* degree of freedom/total numer of walkers */
   int i, jwk, k, m, mc;
   
   R = s->R;                       /* copy from structure to local variables */
   Rnew = s->Rnew;
   tau = s->tau;
   tau_eff = tau;                              /* we'll handle tau_eff later */
   no_dof = s->no_dof;
   no_walkers = s->no_walkers;
   Et = s->Et;
   acc_rate = 0.0;
   acc_cnt = 0;

   if(no_walkers <= 0) {
      fprintf(stderr, "evolve() entered with no walkers!\n");
      return 0.0;
   }

   assert(R != NULL);
   assert(Rnew != NULL);
   assert(no_walkers <= s->max_walkers);
   assert(no_dof == (s->D)*(s-> N));

   for(mc = 0; mc < mcstep; ++mc) {                    /* run over time step */
      k = 0;                                         /* count of new walkers */
      for(jwk = 0; jwk < no_walkers; ++jwk) {    /* loop to be parallelized? */

         El = s->E[jwk];                          /* current walker's energy */
         s->sum_El += El;                  /* statistics for <El> and <El^2> */
         s->sum_El2 += El*El;                          /* and acc_rate below */
         s->sum_cnt += 1.0;

         acc_rate += walk(R[jwk], no_dof, tau);             /* move a walker */ 
         ++acc_cnt;

         /* already checked just before walk() returns, 
               assert(check_inverse_matrix(R[jwk]));  v will be wrong if ... */

         Elnew = get_local_energy(R[jwk], no_dof);

                                         /* duplicate memory for new walkers */
         if(DMC) {                    /* only if we do Diffusion Monte Carlo */
            /* (5) Make the copies to M_new, original included. 
                   El(R) smoothed to overcome 1/x divergence.
             */
            val = tau_eff * (  0.5*(El + Elnew) - Et);
            if (val < - 10.0) {
               fprintf(stderr, 
                  "El=%g, Et=%g, population will grow too large!\n",
                   (double) El, (double) Et);
            }
            M_new = (int) ( drand64() + exp(-val) );

            if (k+M_new > s->max_walkers) {
               fprintf(stderr, "total number of walkers = %d, ", k+M_new);
               fprintf(stderr, "Too many walkers, memory exhausted!\n");
               exit(1);
            }
            for(m = 0; m < M_new; ++m) {
              Rnew[k+m] = (real *) malloc( no_dof*sizeof(real) );
              assert(Rnew[k+m] != NULL);
              for(i = 0; i < no_dof; ++i) {    /* duplicate to new locations */
                 Rnew[k+m][i] = R[jwk][i];
              }
              s->E_curr[k+m] = Elnew;       /* associate walkers with new El */
            }
            k += M_new;                   /* number of new walkers increased */
            free(R[jwk]);              /* deallocate memory of jwk-th walker */
                                     /* why failed? assert(R[jwk] == NULL);  */
         } else {             /* do variational MC, walkers number no change */
            s->E[jwk] = Elnew;
            assert(jwk == k);
            ++k;
         }
      }
      assert(k <= s->max_walkers);
      if(DMC) {      /* walker number changes, memory need swap only for DMC */
         no_walkers = k;

         Rtmp = R;                            /* swap the role of Rnew and R */
         R = Rnew;
         Rnew = Rtmp;
         
         ptmp = s->E;                        /* after swap, E is most recent */
         s->E = s->E_curr;                 /* E_curr points to previous step */
         s->E_curr = ptmp;

         if(no_walkers <= 0) {
           fprintf(stderr, "walkers die out!, has too terminate.\n");
           goto End_Loop;
         }
         assert(no_walkers>0);
         y = log((double) no_walkers);
         s->Y0 += y;                               /* for population control */
         s->Y1 += (mc+1)*y;
         s->Yn += 1.0;                                  /* number of samples */

         if(no_walkers < 0.05*s->max_walkers) {
           fprintf(stderr, "%d walkers, too few, control after %d steps!\n", 
                           no_walkers, mc+1);
           goto End_Loop;
         }
         if(no_walkers > 0.8*s->max_walkers) {
           fprintf(stderr, "%d walkers, too many, control after %d steps!\n", 
                           no_walkers, mc+1);
           goto End_Loop;
         }
         
      }                                                     /* end if(DMC).. */

   }                                                   /* end over time step */

End_Loop:

   s->R = R;                               /* s->R pointing to current place */
   s->Rnew = Rnew;
   s->no_walkers = no_walkers;

   return acc_rate/acc_cnt/no_dof;
}


/* initialize variables, and allocate memory, read from file if 
   exists. 
*/
void init(State *s, FILE *fp)
{
   int jwk, i, n, dof;
   double d;

   s->R = (real **) calloc(s->max_walkers, sizeof(real *));
   s->Rnew = (real **) calloc(s->max_walkers, sizeof(real *));
   s->E = (real *) calloc(s->max_walkers, sizeof(real));
   s->E_curr = (real *) calloc(s->max_walkers, sizeof(real));
   
   if(fp != NULL) {
      fscanf(fp, "%d%d", &n, &dof);
      assert(n > 0 && n <= s->max_walkers);
      assert(dof == s->no_dof);
      s->no_walkers = n;
      fscanf(fp, "%lf", &d);
      s->Et = d;
   }
   for(jwk = 0; jwk < s->no_walkers; ++jwk) {
      s->R[jwk] = (real *) calloc(s->no_dof, sizeof(real)); 
      for(i = 0; i < s->no_dof; ++i) {
         if(fp != NULL) {               /* walker initial position from file */
            fscanf(fp, "%lf", &d);
            s->R[jwk][i] = d;
         } else {                                         /* random position */
            s->R[jwk][i] = 0.5 - drand64();
         }
      }
      init_psi_inverse(s->R[jwk]);
      assert(check_inverse_matrix(s->R[jwk]));     /* v will be wrong if ... */
      s->E[jwk] = get_local_energy(s->R[jwk], s->no_dof);
   }
   s->sum_El = 0.0;                                   /* sum of local energy */
   s->sum_El2 = 0.0;                                /* sum of energy squared */
   s->sum_cnt = 0.0;                                      /* how many summed */
   s->F2 = 0.0;                        /* "quantum force" squared, <0.5*v^2> */
   s->K = 0.0;                           /* kinetic energy <(Del^2 psi)/psi> */
   s->Im = 0.0;
   s->Y0 = 0.0;                              /* population control variables */
   s->Y1 = 0.0;
   s->Yn = 0.0;
}

void save_walkers(State *s, FILE *fp)
{
   int jwk, i;

   fprintf(fp, "%d  %d\n", s->no_walkers, s->no_dof);
   fprintf(fp, "%g\n", (double) s->Et);
   for(jwk = 0; jwk < s->no_walkers; ++jwk) {
      for(i = 0; i < s->no_dof; ++i) {
         fprintf(fp, "%g ", (double) (s->R[jwk][i]) );
      }
      fprintf(fp, "\n");
   }
}

/*-----------------------------------------------------------------------------
               R A N D O M   N U M B E R   G E N E R A T O R S
  ---------------------------------------------------------------------------*/
/* 64-bit linear congruential random number generator, and Gaussian 
   random number using Box-Mueller method */

static unsigned long long x = 1;
int Myid = 1;                   /* this will later used for parallel program */

double drand64(void) 
{
   x = 6364136223846793005ll * x + (long long int) Myid;
   return (double) x * 5.4210108624275218e-20; 
}


void srand64(long seed)
{
   assert(sizeof(long long int) == 8);
   x = seed;
   printf("initial seed x = %d\n", (int) x);
}


double drand_gaussian(void)
{
   double x1, x2, y;

   x1 = drand64();
   x2 = drand64();
   y = sqrt( - 2.0*log(x1) ) * sin(2.0*M_PI*x2);    /* what to do if x1 ==0? */
   return y;
}
