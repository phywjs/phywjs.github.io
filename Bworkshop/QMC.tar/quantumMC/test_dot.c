/* we test if theta is consistent with d theta/dx, and Del^2 theta.
   as well as the version for J, dJ/dx, and Del J.
   For model_dot.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include "datatype.h"
#include "complex.h"

void read_model_parameters(FILE *fin, FILE *fecho);
void occupation(int n, FILE *fin, FILE *fecho);
complex orbital(real *r, int j);                               /* theta_j(r) */
complex d_orbital(real *r, int j, int i);               /* d theta_j(r) dx_i */
complex laplacian_orbital(real *r, int j);               /* Del^2 theta_j(r) */
real jastrow_fac_ratio(real R[], real R_i, int i);        /* exp(J(R')-J(R)) */
real d_jastrow(real R[], int i);                               /* d/x_i J(R) */
real laplacian_jastrow(real R[], int no_dof);                  /* Del^2 J(R) */
real potential(real R[], int no_dof);                                /* V(R) */

State St;

int main()
{
   int i, j, k;
   real h;
   real *r, *r1, *r2;
   complex f, z, psi, psi1, psi2;

   read_model_parameters(stdin, stdout);

   printf("enter dimension D:\n");
   scanf("%d", &St.D);
   printf("enter number of electrons N:\n");
   scanf("%d", &St.N);
   St.no_dof = St.D * St.N;
   r = (real *) malloc( St.D*sizeof(real));
   r1 = (real *) malloc( St.D*sizeof(real));
   r2 = (real *) malloc( St.D*sizeof(real));
   assert(r != NULL);
   assert(r1 != NULL);
   assert(r2 != NULL);
   occupation(St.N, stdin, stdout);

   printf("wave function at special points\n (0,0)\n");
   for(j = 0; j < St.N; ++j) {
      r[0] = 0.0;
      r[1] = 0.0;
      z = orbital(r,j);
      printf("(%f %f) ", (double) z.Re, (double) z.Im);
      assert(r[0] == 0.0 && r[1] == 0.0);
   }
   printf("\n(1,0)");
   for(j = 0; j < St.N; ++j) {
      r[0] = 1.0;
      r[1] = 0.0;
      z = orbital(r,j);
      printf("(%f %f) ", (double) z.Re, (double) z.Im);
      assert(r[0] == 1.0 && r[1] == 0.0);
   }
   printf("\n(0,1)");
   for(j = 0; j < St.N; ++j) {
      r[0] = 0.0;
      r[1] = 1.0;
      z = orbital(r,j);
      printf("(%f %f) ", (double) z.Re, (double) z.Im);
      assert(r[0] == 0.0 && r[1] == 1.0);
   }
   printf("\n");
   
   for(i = 0; i < St.D; ++i) {                            /* random position */
      r[i] = 0.5 - drand48();
   }

   printf("Compare analytic and numerical d theta_j(r)/dr\n");
   printf("\tanalytic ");
   for(j = 0; j < St.N; ++j) {
      printf("(");
      for(i = 0; i < St.D; ++i) {
         z = d_orbital(r,j,i);
         printf("(%f %f)", (double) z.Re, (double) z.Im);
      }
      printf("), ");
   }
   printf("\n\tnumeric  ");

   for(h = 0.01; h >= 0.0001; h *= 0.1) {
      for(j = 0; j < St.N; ++j) {
         printf("(");
         for(i = 0; i < St.D; ++i) {
            for(k = 0; k < St.D; ++k) {
               r1[k] = r[k];
               r2[k] = r[k];
            }
            r1[i] -= 0.5*h;
            r2[i] += 0.5*h;
            psi2 = orbital(r2,j);
            psi1 = orbital(r1,j);
            z.Re = ( psi2.Re - psi1.Re )/h;            /* central difference */
            z.Im = ( psi2.Im - psi1.Im )/h;   
            printf("(%f %f) ", (double) z.Re, (double) z.Im);
         }
         printf("), ");
      }
      printf("\n\t         ");
   }

   printf("\nCompare analytic and numerical del^2 theta_j(r)\n");
   printf("\tanalytic ");
   for(j = 0; j < St.N; ++j) {
      z = laplacian_orbital(r,j);
      printf("(%f %f) ", (double) z.Re, (double) z.Im);
   }
   printf("\n\tnumeric  ");

   for(h = 0.01; h >= 0.0001; h *= 0.1) {
      for(j = 0; j < St.N; ++j) {
         f.Re = 0.0;
         f.Im = 0.0;
         for(i = 0; i < St.D; ++i) {
            for(k = 0; k < St.D; ++k) {
               r1[k] = r[k];
               r2[k] = r[k];
            }
            r1[i] -= h;
            r2[i] += h;
            psi2 = orbital(r2,j);
            psi1 = orbital(r1,j);
            psi = orbital(r,j);
            f = c_add(f, psi2);             /* f = psi(r+h)+psi(r-h)-2psi(h) */
            f = c_add(f, psi1);
            f = c_sub(f, psi);
            f = c_sub(f, psi);
         }
         f.Re /= (h*h);
         f.Im /= (h*h);
         printf("(%f %f) ", (double) f.Re, (double) f.Im);
      }
      printf("\n\t         ");
   }

   return 0;
}
