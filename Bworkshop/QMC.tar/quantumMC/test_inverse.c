/* test the inverse and sherman-morrison routine.
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

#include "datatype.h"

int get_index(int i, int j, int n);
void inverseSM(const real a[], int n, real inv[]);
void inverse(real a[], int n, real inv[]);
void sherman_morrison(real C[], int n, real v[], real u[], int l);
real determinant(real a[], int n);
void print_matrix(const real a[], int n);

main()
{
   real *a, *inv, *c, *d, det, delta, dot, dot2;
   double dummy;
   int i, j, k, n, cnt, ind, LP;

   printf("enter size n of a square matrix\n");
   scanf("%d", &n);

   a = (real *) malloc(sizeof(real)*n*n);
   inv = (real *) malloc(sizeof(real)*n*n);
   c = (real *) malloc(sizeof(real)*n*n);
   d = (real *) malloc(sizeof(real)*n*n);

   printf("enter elements, one row in a line\n");
   for(i = 0; i < n; ++i) {
      for(j = 0; j < n; ++j) {
         scanf("%lf", &dummy);
         a[get_index(i,j,n)] = dummy;
      }
   }

   for(i = 0; i < n*n; ++i) {
      d[i] = a[i];
   }
   det = determinant(d, n);
   printf("det(A) = %g\n", (double) det);

for(LP = 0; LP < 2; ++LP) {

   for(i = 0; i < n*n; ++i) {
      d[i] = a[i];
   }
   if(LP == 0) {
      printf("inverse by repeated application of Sherman-Morrison formula\n");
      inverseSM(d, n, inv);
   } else {
      printf("inverse by LU decomposition\n");
      inverse(d, n, inv);
   }

   printf("inverse of a\n");
   print_matrix(a, n);
   printf("is\n");
   print_matrix(inv, n);

  cnt = 0;
Loop:

   printf("loop %d, ", cnt);
   delta = 0.0;
   for(i = 0; i < n; ++i) {
      for(j = 0; j < n; ++j) {
         dot = 0.0;
         for(k = 0; k < n; ++k) {
            dot += a[get_index(i,k,n)]*inv[get_index(k,j,n)];
         }
         c[get_index(i,j,n)] = dot;                           /* c = a * inv */
         if (i==j) {
            dot -= 1.0;
         }
         delta += fabs(dot);
      }
   }
   delta /= (n*n);

   printf("a*inv = I, average different to identity per element is\n");
   printf("delta = %.15g\n", (double) delta);

   delta = 0.0;
   for(i = 0; i < n; ++i) {
      for(j = 0; j < n; ++j) {
         dot = 0.0;
         dot2 = 0.0;
         for(k = 0; k < n; ++k) {
            dot += inv[get_index(i,k,n)]*a[get_index(k,j,n)];
            dot2 += inv[get_index(i,k,n)]*c[get_index(k,j,n)];  /* inv*a*inv */
         }
         d[get_index(i,j,n)] = dot2;
         if (i==j) {
            dot -= 1.0;
         }
         delta += fabs(dot);
      }
   }
   delta /= (n*n);

   printf("inv*a = I, reserve order\n");
   printf("delta = %.15g\n", (double) delta);

   for(ind = 0; ind < n*n; ++ind){
      inv[ind] += (inv[ind]-d[ind]);
   }

   ++cnt;
   printf("corrected inverse\n");

   if(cnt < 3) goto Loop;

} /* end LP */

}
