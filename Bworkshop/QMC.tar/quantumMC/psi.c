/* ----------------------------------------------------------------------------
      P S I ,  T R I A L   W A V E F U N C T I O N   C O M P U T A T I O N
   --------------------------------------------------------------------------*/
/* The generic aspect of the trial wavefunction should be handled in this file
   only. Information is exported by get_Psi_T(), get_velocity(), etc.
   The specific problem-dependent orbitals and Jastrow factors are defined 
   in model_*.c.
*/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

#include "datatype.h"

extern State St;                    /* state is declared in main() as global */
                                                     /* globals to this file */
static real *theta;      /* Slater determinant matrix theta(i,j)= phi_j(r_i) */
static real *C;                  /* C = theta^(-1), no_elec x no_elec matrix */
static real *u, *v;                               /* (temporary) row vectors */
static int no_elec;                                   /* number of electrons */

                                   /* external functions used from inverse.c */
int get_index(int i, int j, int n);              /* matrix (i,j) -> 1d index */
void inverse(real a[], int n, real inv[]);                   /* inv = a^(-1) */
void sherman_morrison(real C[], int n, real v[], real u[], int l);
real determinant(real a[], int n);                           /* det(a) = |a| */
void print_matrix(const real a[], int n);                           /* print */

                                  /* external functions defined in model_*.c */
real orbital(real *r, int j);                                  /* theta_j(r) */
real d_orbital(real *r, int j, int i);                  /* d theta_j(r) dx_i */
real laplacian_orbital(real *r, int j);                  /* Del^2 theta_j(r) */
real jastrow(real R[]);                                    /* Jastrow factor */
real jastrow_fac_ratio(real R[], real R_i, int i);        /* exp(J(R')-J(R)) */
real d_jastrow(real R[], int i);                               /* d/x_i J(R) */
real laplacian_jastrow(real R[], int no_dof);                  /* Del^2 J(R) */
real potential(real R[], int no_dof);                                /* V(R) */

                                            /* function defined in this file */
void init_psi(void);                           /* allocate memory for C, etc */
void init_psi_inverse(real R[]);                           /* C = theta^(-1) */
void update_psi(real R[]);                                  /* compute theta */
void update_psi_inv(real R[], real r_new, int i);            /* C <= C + ... */
int check_inverse_matrix(real R[]);                    /* check theta C == 1 */
real get_psi_ratio(real R[], real R_i, int i);             /* Psi(R')/Psi(R) */
real get_Psi_T(real R[]);                                        /* Psi_T(R) */
real get_velocity(real R[], int i);                   /* v_i = d/x_i J + ... */
real get_velocity_0(real R[], int i);                 /* v0_i = Tr(theta' C) */
real get_mag_velocity(real R[], int no_dof);                          /* |v| */
real get_local_energy(real R[], int no_dof);      /* E_L(R) = Psi^(-1) H Psi */


/* Initialize and allocate memory, must be called before using any other
   functions.  We do not use 2D array; so the matrix is a 1D array,
   using get_index(i,j,size) to map from 2D index (i,j) to the 1D array.
   This makes it easier to call Fortran subroutine if needed.
*/
void init_psi(void)
{
   no_elec = St.N;
   theta = (real *) malloc( no_elec*no_elec*sizeof(real) );
   assert(theta != NULL);
   C = (real *) malloc( no_elec*no_elec*sizeof(real) );
   assert(C != NULL);
   u = (real *) malloc( no_elec*sizeof(real) );
   assert(u != NULL);
   v = (real *) malloc( no_elec*sizeof(real) );
   assert(v != NULL);
}
   

/* Global value for matrix theta is set.
   Each row corresponds to the same electrons (same coordinates), but
   different orbitals, i.e.,
           | theta_1(x1)   theta_2(x1)  ...  theta_n(x1) |
   theta = | theta_1(x2)   ...                           |
           | ...                                         |
           | theta_1(xn)                     theta_n(xn) |
 */
void update_psi(real R[])
{
   int i, j, offset; 
                                               /* theta_{i,j} = theta_j(r_i) */
   for(i = 0; i < no_elec; ++i) {                          /* over electrons */
      offset = (St.D)*i;
      for(j = 0; j < no_elec; ++j) {                        /* over orbitals */
         theta[get_index(i,j,no_elec)] = orbital(R+offset, j);
      }
   }
}


/* Initialize C by theta inverse
 */
void init_psi_inverse(real R[])
{
   update_psi(R);
   inverse(theta, no_elec, C);                                /* theta -> LU */
}


/* We assume R[] contains R old, i.e., R before move! 
   It changes C when R[i] is changed to r_new.
 */
void update_psi_inv(real R[], real r_new, int i)
{
   int k, i_elec, offset;
   real r_old, psi_old, psi_new;

   i_elec = i/(St.D);                        /* this row in theta is changed */
   offset = i_elec * St.D;
   assert(offset <= i && i < offset + St.D);
   r_old = R[i];

   for(k = 0; k < no_elec; ++k) {           /* compute nonzero row v of C'-C */
      psi_old = orbital(R+offset, k);
      R[i] = r_new;
      psi_new = orbital(R+offset, k);
      R[i] = r_old;
      v[k] = psi_new - psi_old;
   }

   sherman_morrison(C, no_elec, v, u, i_elec);

   assert(fabs(R[i]-r_old)< EPSILON);                /* should not change R! */
}


/* check that C is consistent with theta.
 */
int check_inverse_matrix(real R[])
{
   real delta, dot;
   int i, j, k;

   update_psi(R);
  
/*
   printf("theta = \n");
   print_matrix(theta, no_elec);
   printf("C = \n");
   print_matrix(C, no_elec);
*/

   delta = 0.0;
   for(i = 0; i < no_elec; ++i) {
      for(j = 0; j < no_elec; ++j) {
         dot = 0.0;
         for(k = 0; k < no_elec; ++k) {
            dot += theta[get_index(i,k,no_elec)]*C[get_index(k,j,no_elec)];
         }
         if (i==j) {
            dot -= 1.0;
         }
         if(dot < 0.0) dot = -dot;
         delta += dot;
      }
   }
   delta /= (no_elec*no_elec);

/*
   printf("theta*C = I, average different to identity per element is\n");
   printf("delta = %.15g\n", (double) delta);
*/

   return (delta < EPSILON);
}


                     /* Evaluate trial wavefunction Psi_T(R), for debug only */
real get_Psi_T(real R[])
{
   real d, j;

   update_psi(R);
   d = determinant(theta, no_elec);               /* value theta[] destroyed */
   j = jastrow(R);                           
   return d*j;
}


/* Compute ratio Psi(R')/Psi(R), assuming only the ith degree of freedom
   is moved. (NOT the i-th electron!)/  See Eq. (40) of Ceperley notes 1996.
   NB: there are two sets of indices, in function walk(), we run over 
   components of all electrons from 0 to no_dof.  However, for orbitals,
   and matrices, we count over electrons.  Thus conversion is needed.
   i -> j = i/St.D.
 */
real get_psi_ratio(real R[], real R_i, int i)
{
   int k, j, offset;
   real det_ratio, rold;

   j = i/St.D;                                /* component to electron index */
   offset = j*St.D;                    /* start of j-th electron coordinates */
   det_ratio = 0.0;
   rold = R[i];
   R[i] = R_i;                                               /* R set to new */
   for(k = 0; k < no_elec; ++k) {
      det_ratio += orbital(R+offset, k) * C[get_index(k,j,no_elec)];
   }
   R[i] = rold;                                                /* R restored */
   return jastrow_fac_ratio(R, R_i, i) * det_ratio;
}


/* Compute velocity component v_i = dPsi/dx_i / Psi
   The velocity is given by
   v = Delta J + Tr { (Delta theta) C}
   where v is a D*N dimensional vector, Delta is gradient operator,
   C = theta(^-1) are matrices.  

   The velocity_0 version does not include the Jastrow factor term.
*/
real get_velocity(real R[], int i)
{
   real v0, dj;

   v0 = get_velocity_0(R, i);
   dj = d_jastrow(R, i);
   return dj + v0;
}


real get_velocity_0(real R[], int i)
{
   real v_i;
   int k, j, offset, compon;

   j = i/St.D;            /* from D*N-vector component i to electron index j */
   offset = j* St.D;    /* starting address of R of jth electron coordinates */
   compon = i - offset;                   /* which component of jth electron */
   assert(compon >= 0 && compon < St.D);
   
   v_i = 0.0;
   for(k = 0; k < no_elec; ++k) {
      v_i += d_orbital(R+offset, k, compon) * C[get_index(k,j,no_elec)];
   }
   return v_i;
}


/* |v|^2, magnitude of velocity 
 */
real get_mag_velocity(real R[], int no_dof)
{
   real v2, v_i;
   int i;
 
   assert(no_dof == St.no_dof);
   v2 = 0.0;
   for(i = 0; i < no_dof; ++i) {
      v_i = get_velocity(R, i);
      v2 += (v_i*v_i);
   }
   return sqrt(v2);
}


/* Local energy E_L(R) = Psi^(-1) H^ Psi
                       = -(1/2) Psi^(-1) Del^2 Psi + V(R);
   Psi^(-1) Del^2 Psi = Del^2 J(R) + Trace{(Del^2 theta) C} +v^2 -v0^2,
   where Del^2 is the Laplacian operator, C = theta^(-1) is no_elec by
   no_elec matrix, v is velocity magnitude squared, and v0 is v
   when J(R) sets to 0. 
 */
real get_local_energy(real R[], int no_dof)
{
   real lapj, dd, v2, vv, v0, dj, K, V, EL;
   int i, j, k, offset; 

   lapj = laplacian_jastrow(R, no_dof);                           /* Del^2 J */
   
   dd = 0.0;
   for(j = 0; j < no_elec; ++j) {                     /* Tr{(Del^2 theta) C} */
      offset = j*(St.D);
      for(k = 0; k < no_elec; ++k) {
         dd += laplacian_orbital(R+offset, k) * C[get_index(k,j,no_elec)];
      }
   }

   vv = 0.0;                                                   /* v^2 - v0^2 */
   v2 = 0.0;                                                          /* v^2 */
   for(i = 0; i < no_dof; ++i) {               /* used a^2-b^2 = (a+b)*(a-b) */
      dj = d_jastrow(R,i);
      v0 = get_velocity_0(R, i);
      vv += (dj + 2.0*v0)*dj;
      v2 += (dj + v0)*(dj + v0);
   } 

   V = potential(R, no_dof);                        /* potential energy V(R) */
   
   K = -0.5*(lapj + dd + vv);                              /* kinetic energy */
   EL = K + V;
                                   /* this is for check that <F^2>=<0.5*v^2> */
   St.F2 += 0.5*v2;                                  /* global variables set */
   St.K += K;
 
   return EL;
}
