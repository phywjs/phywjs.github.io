#ifndef COMPLEX_H
#define COMPLEX_H

#ifndef _MATH_H
#include <math.h>
#endif
#ifndef DATATYPE_H
#include "datatype.h"
#endif

complex c_add(complex x, complex y);
complex c_sub(complex x, complex y);
complex c_mul(complex x, complex y);
complex c_div(complex x, complex y);
complex c_conj(complex z);
real c_abs(complex z);

#endif
