#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <time.h>

#include "datatype.h"
#include "complex.h"

void read_model_parameters(FILE *fin, FILE *fecho);
void occupation(int n, FILE *fin, FILE *fecho);
void init_psi(void);
void init_psi_inverse(real R[]);
int check_inverse_matrix(real R[]);
void update_psi_inv(real R[], real r_new, int i);
real get_psi_ratio(real R[], real R_i, int i);
complex get_Psi_T(real R[]);
real get_velocity(real R[], int i);
complex get_velocity_0(real R[], int i);
real get_local_energy(real R[], int i);
real potential(real R[], int i);

State St;

int main()
{
   real *R, r_new, r_old, R_i;
   double r, r2, h, eng;
   complex z, psi, psip, psi0, v_i, v_i_ana, lap;
   int i, j, j1, j2;

   srand48(time(NULL));

   read_model_parameters(stdin, stdout);
   printf("enter dimension D:\n");
   scanf("%d", &St.D);
   printf("enter number of electrons N:\n");
   scanf("%d", &St.N);
   St.no_dof = St.D * St.N;

   R = malloc( St.no_dof * sizeof(real));
   init_psi();
   occupation(St.N, stdin, stdout);

   for(i = 0; i < St.no_dof; ++i) {
      R[i] = drand48();
   }

   R[0] = 0,
   R[1] = 1;
   R[2] = 1;
   R[3] = 0;
   R[4] = -1;
   R[5] = 0;
   init_psi_inverse(R);
   check_inverse_matrix(R);
   printf("Compute local energy E_L(R)=%f\n", 
           (double) get_local_energy(R, St.no_dof) );

   printf("Test anti-symmetry of wavefunction\n\t");
   for(i = 0; i < 10; ++i) {       /* will not work with two det (i.e. spin) */
      j1 = St.N*drand48();
      j2 = St.N*drand48();
      if(j1 == j2) continue;
      j1 *= St.D;
      j2 *= St.D;
      psi = get_Psi_T(R);
      for(j = 0; j < St.D; ++j) {                /* swap electron j1 with j2 */
         R_i = R[j1+j];
         R[j1+j] = R[j2+j];
         R[j2+j] = R_i;
      }
      psip = get_Psi_T(R);
      z = c_add(psi, psip);
      printf("(%g %g) ", (double) z.Re, (double) z.Im);
      assert(c_abs(z) < EPSILON);
   }
   printf("\n\tanti-symmetry test passed!\n");

   init_psi_inverse(R);
   if(check_inverse_matrix(R)) {
     printf("calculation of inverse OK!\n");
   } else {
     printf("calculation of inverse wrong!\n");
     exit(1);
   }

   for(i = 0; i < St.no_dof; ++i) {
      r_new = drand48();
      update_psi_inv(R, r_new, i); 
      R[i] = r_new;
   }

   printf("Changed R, recheck C\n");
   if(check_inverse_matrix(R)) {
     printf("\tcalculation of inverse OK!\n");
   } else {
     printf("\tcalculation of inverse wrong!\n");
     exit(1);
   }

   printf("Test value of Psi(R')/Psi(R)\n");
   i = St.no_dof * drand48();
   R_i = R[i] + 0.1*drand48();
   r = get_psi_ratio(R, R_i, i);
   printf("\ti=%d, the ratio is %f\n", i, r);
   psi = get_Psi_T(R);
   R[i] = R_i;
   psip = get_Psi_T(R);
   r2 = c_abs( c_div(psip,psi) );
   
   printf("\tthe slow det computing is %f = |(%f+i%f)/(%f+i%f)|\n", 
           r2, (double) psip.Re, (double) psip.Im, 
           (double) psi.Re, (double) psi.Im);
   assert(fabs( (double) (r2-r)) < EPSILON);

   init_psi_inverse(R);  
   /* if we forget to have an up-to-date C,
      we get wrong results
   */
   printf("Compute velocity v\n\tv_i=(");
   for(i = 0; i < St.no_dof; ++i) {
      v_i = get_velocity_0(R, i);
      printf("(%f %f) ", (double) v_i.Re, (double) v_i.Im);
   }
   printf(")\n");
   printf("\tby finite differences\n");
   for(h = 0.01; h >= 0.0001; h *= 0.01) {
      printf("h=%f, ", h);
      for(i = 0; i < St.no_dof; ++i) {
        v_i_ana = get_velocity_0(R, i);
        r_old = R[i];
        R[i] = r_old - 0.5*h;
        psi = get_Psi_T(R);
        R[i] = r_old + 0.5*h;
        psip = get_Psi_T(R);
        R[i] = r_old;
        v_i = c_sub(psip, psi);
        v_i.Re /= h;
        v_i.Im /= h;
        psi = get_Psi_T(R);
        v_i = c_div(v_i, psi);
        printf("(%f %f) ", (double) v_i.Re, (double) v_i.Im);
        z = c_sub(v_i_ana, v_i);
        if(c_abs(z)/c_abs(v_i_ana) > 0.001) {
           printf("\nWarning!! seems disgree, analytic is (%g, %g)\n",
           (double) v_i_ana.Re, (double) v_i_ana.Im );
        }
      }
      printf(")\n");
   }
   printf("Compute local energy E_L(R)=%f\n", 
           (double) get_local_energy(R, St.no_dof) );
   printf("\tby finite differences\n");
   for(h = 0.1; h >= 0.0001; h *= 0.1) {
      lap.Re = 0.0;
      lap.Im = 0.0;
      for(i = 0; i < St.no_dof; ++i) {
        r_old = R[i];
        R[i] = r_old - h;
        psi = get_Psi_T(R);
        R[i] = r_old + h;
        psip = get_Psi_T(R);
        R[i] = r_old;
        psi0 = get_Psi_T(R);
        lap.Re = 0.0;
        lap.Im = 0.0;
        lap = c_add(lap, psip);
        lap = c_add(lap, psi);
        lap = c_sub(lap, psi0);
        lap = c_sub(lap, psi0);
        lap.Re /= (h*h);
        lap.Im /= (h*h);                      /* [f(x+h)+f(x-h)-2f(x)]/(h*h) */
      }
      lap = c_div(lap, psi0);
      eng = -0.5*lap.Re + potential(R, St.no_dof);
      printf("h=%f, E_L = %f\n", h, eng);
      printf("Psi^(-1) del^2 Psi = (%f %f)\n", 
              (double) lap.Re, (double) lap.Im);
   }

   free(R);

   return 0;
}
