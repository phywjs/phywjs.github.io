#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <time.h>

#include "datatype.h"

void init_psi(void);
void init_psi_inverse(real R[]);
int check_inverse_matrix(real R[]);
void update_psi_inv(real R[], real r_new, int i);
real get_psi_ratio(real R[], real R_i, int i);
real get_Psi_T(real R[]);
real get_velocity(real R[], int i);
real get_local_energy(real R[], int i);
real potential(real R[], int i);

State St;

int main()
{
   real *R, r_new, r_old, R_i;
   double r, r2, v_i, psi, psip, psi0, h, lap, eng;
   int i, j, j1, j2;

   srand48(time(NULL));

   printf("enter dimension D:\n");
   scanf("%d", &St.D);
   printf("enter number of electrons N:\n");
   scanf("%d", &St.N);
   St.no_dof = St.D * St.N;

   R = malloc( St.no_dof * sizeof(real));
   init_psi();

   for(i = 0; i < St.no_dof; ++i) {
      R[i] = drand48();
   }

   printf("Test anti-symmetry of wavefunction\n\t");
   for(i = 0; i < 10; ++i) {       /* will not work with two det (i.e. spin) */
      j1 = St.N*drand48();
      j2 = St.N*drand48();
      if(j1 == j2) continue;
      j1 *= St.D;
      j2 *= St.D;
      psi = get_Psi_T(R);
      for(j = 0; j < St.D; ++j) {                /* swap electron j1 with j2 */
         R_i = R[j1+j];
         R[j1+j] = R[j2+j];
         R[j2+j] = R_i;
      }
      psip = get_Psi_T(R);
      printf("%g ", psi+psip);
      assert(fabs(psi+psip) < EPSILON);
   }
   printf("\n");

   init_psi_inverse(R);
   if(check_inverse_matrix(R)) {
     printf("calculation of inverse OK!\n");
   } else {
     printf("calculation of inverse wrong!\n");
     exit(1);
   }

   for(i = 0; i < St.no_dof; ++i) {
      r_new = drand48();
      update_psi_inv(R, r_new, i); 
      R[i] = r_new;
   }

   printf("Changed R, recheck C\n");
   if(check_inverse_matrix(R)) {
     printf("\tcalculation of inverse OK!\n");
   } else {
     printf("\tcalculation of inverse wrong!\n");
     exit(1);
   }

   printf("Test value of Psi(R')/Psi(R)\n");
   i = St.no_dof * drand48();
   R_i = R[i] + 0.1*drand48();
   r = get_psi_ratio(R, R_i, i);
   printf("\ti=%d, the ratio is %f\n", i, r);
   psi = get_Psi_T(R);
   R[i] = R_i;
   psip = get_Psi_T(R);
   r2 = psip/psi;
   
   printf("\tthe slow det computing is %f = %f/%f\n", r2, psip, psi);
   assert(fabs( (double) (r2-r)) < EPSILON);

   init_psi_inverse(R);  
   /* if we forget to have an up-to-date C,
      we get wrong results
   */
   printf("Compute velocity v\n\tv_i=(");
   for(i = 0; i < St.no_dof; ++i) {
      v_i = get_velocity(R, i);
      printf("%f ", v_i);
   }
   printf(")\n");
   printf("\tby finite differences\n");
   for(h = 0.1; h >= 0.0001; h *= 0.1) {
      printf("h=%f, ", h);
      for(i = 0; i < St.no_dof; ++i) {
        r_old = R[i];
        R[i] = r_old - 0.5*h;
        psi = get_Psi_T(R);
        R[i] = r_old + 0.5*h;
        psip = get_Psi_T(R);
        R[i] = r_old;
        v_i = (psip - psi)/h;                          /* central difference */ 
        v_i = v_i/get_Psi_T(R);                      /* Psi^(-1) d Psi /dx_i */
        printf("%f ", v_i);
      }
      printf(")\n");
   }
   printf("Compute local energy E_L(R)=%f\n", 
           (double) get_local_energy(R, St.no_dof) );
   printf("\tby finite differences\n");
   for(h = 0.1; h >= 0.0001; h *= 0.1) {
      lap = 0.0;
      for(i = 0; i < St.no_dof; ++i) {
        r_old = R[i];
        R[i] = r_old - h;
        psi = get_Psi_T(R);
        R[i] = r_old + h;
        psip = get_Psi_T(R);
        R[i] = r_old;
        psi0 = get_Psi_T(R);
        lap += (psip + psi - 2.0*psi0)/(h*h); /* [f(x+h)+f(x-h)-2f(x)]/(h*h) */
      }
      eng = -0.5*lap/psi0 + potential(R, St.no_dof);
      printf("h=%f, E_L = %f\n", h, eng);
   }

   free(R);

   return 0;
}
