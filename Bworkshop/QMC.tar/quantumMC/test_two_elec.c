/* test the two electron case */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <time.h>

#include "datatype.h"

real psisq(real x, real y)                                        /* |Psi|^2 */
{
   return 4.0*exp(-x*x-y*y)*(x-y)*(x-y);
}

real energy(real x, real y)
{
   return 2.0 + 1.0/fabs(x-y);
}

real velo(real x, real y, int j)
{
   if(j == 0) {
      return (x*x-x*y-1.0)/(y-x);
   } else {
      return (-y*y +x*y+1.0)/(y-x);
   }
}

State St;

void init(State *s);
void init_psi(void);
void init_psi_inverse(real R[]);
real get_Psi_T(real R[]);
real get_psi_ratio(real R[], real R_i, int j);
real get_local_energy(real R[], int dof);
real get_velocity(real R[], int j);
double drand_gaussian(void);
double drand64(void);
double srand64(long);

main()
{
   real x, y, R[2], ps, ps2, R_i;
   real x1, y1, R1[2], ps1, ps21;
   real ratio, r, del;
   real e, eloc, etot, etot2;
   real v, v1, vg, dR, dR1;
   real A;
   int mc, j, MCTOT, MCDIS;
   real tau, sqrt_tau;
   double dum;
   
   printf("enter MCTOT, MCDIS, and tau\n");
   scanf("%d%d%lf", &MCTOT, &MCDIS, &dum);
   tau = dum;
   St.D = 1;
   St.N = 2;
   St.no_dof = 2;
   St.no_walkers = 1;
   St.max_walkers = 1;

   srand48(time(NULL));

   init_psi();
   init(&St);

   sqrt_tau = sqrt(tau);

   etot = 0.0;
   etot2 = 0.0;

   x = 1.0;
   y = 0.0;

   srand64(1);

   for(mc = 0; mc < MCTOT; ++mc) {

      R[0] = x;
      R[1] = y;

      e = energy(x,y);
      init_psi_inverse(R);
      eloc = get_local_energy(R,2);
      assert(fabs(e-eloc) < EPSILON);

      if(mc >= MCDIS) {
         etot += e;
         etot2 += eloc;
      }

      ps2 = psisq(x,y);
      ps = get_Psi_T(R);
      ps = ps*ps; 
      assert(fabs(ps2-ps) < EPSILON);
      j = mc % 2;
     
      v = velo(x,y,j);
      vg = get_velocity(R,j);
  
      del = sqrt_tau*drand_gaussian() + tau*v;
      if(j == 0) {
         x1 = x + del;
         y1 = y;
         R_i = x1;
      } else {
         x1 = x;
         y1 = y + del;
         R_i = y1;
      }
      ps21 = psisq(x1,y1);
      R1[0] = x1; R1[1] = y1;
      ps1 = get_Psi_T(R1);
      ps1 = ps1*ps1; 
      printf("ps21, ps1=%g, %g\n", (double) ps21, (double) ps1);
      assert(fabs(ps21-ps1) < EPSILON);
      ratio = ps21/ps2;
      r = get_psi_ratio(R,R_i,j);
      assert(fabs(r*r-ratio) < EPSILON);

      v1 = velo(x1,y1,j);
/*
      vg = get_velocity(R1,j);
      assert(fabs(vg-v1) < EPSILON);
*/
      dR = R1[j] - R[j] - tau*v;
      dR1 = R[j] - R1[j] - tau*v1;
      A = exp(0.5*(-dR1*dR1 + dR*dR)/tau);
      A *= ratio;
      if(drand64() < A) {
         x = x1;
         y = y1;
      }
      printf("mc = %d, rold, rnew = [%g %g], [%g %g]\n", mc/2,
             (double) R[0], (double) R[1], (double) R1[0], (double) R1[1]);
      printf("(x,y)=(%g, %g), (v,v1) = (%g,%g), j=%d, A=%g, ratio=%g\n", 
              (double) x, (double) y, (double) v, (double) v1, j, 
              (double) A, (double) ratio);
   }
   
   printf("mc steps = %d, tau = %g\n", (MCTOT-MCDIS), (double) tau);
   printf("<e> = %g\n", (double) etot/(MCTOT-MCDIS));
   printf("Use local eng <e> = %g\n", (double) etot2/(MCTOT-MCDIS));

}
