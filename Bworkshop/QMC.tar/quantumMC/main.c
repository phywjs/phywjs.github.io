/* ----------------------------------------------------------------------------
       V A R I A T I O N A L  /  D I F F U S I O N   M O N T E   C A R L O

                      T H E   M A I N   P R O G R A M
   --------------------------------------------------------------------------
   23 October 2001, by Wang Jian-Sheng

   The main program controls I/O, the flow of execution, and statistics.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include <assert.h>

#include "datatype.h"
            /* see the above file for definition of new type: State and real */

                                                       /* external functions */
void read_model_parameters(FILE *fin, FILE *fecho);          /* in model_*.c */
void occupation(int no_elec, FILE *fin, FILE *fecho);                /* same */
real get_B_field(void);                                              /* same */
int get_angular_L(void);
int get_spin_S(void);
void init_psi(void);                                             /* in psi.c */
void init(State *s, FILE *fp);                                      /* qmc.c */
void save_walkers(State *s, FILE *fp);                              /* qmc.c */
real evolve(int mcstep, State *s, int DMC);                      /* as above */
void srand64(long seed);                                         /* as above */
void print_state(FILE *fp, State *s);      /* functions defined in this file */
void do_p_control(State *s);                      /* walk population control */ 

State St;                    /* the state, one and only global (a structure) */

/* --------------------------------------------------------------------------  
                           M A I N   P R O G R A M  
   --------------------------------------------------------------------------*/
int main(int argc, char **argv)
{
   int DMC;
   int n, mc, MCtot, MCdis, MCint0, MCinterval;
   FILE *fin, *fout, *fecho, *fsave;
   double rate, dummy;
   real av_E, av_E2, av_cnt;
   char savefile[200];                       /* filename for save(d) walkers */
                                                /* get inputs, case of a.out */
   fin = stdin;                  /* if no argument is given, the program ... */
   fout = stdout;         /* read from standard in/write to standard out ... */
   fecho = stderr;                      /* and echo message to standard err. */
   strncpy(savefile, "tmp_R_walkers.cfg", 20);

   if(argc > 1) {                                /* case of a.out input_file */
      fin = fopen(argv[1], "r");
      assert(fin != NULL);
      n = 0;
      while(argv[1][n] != '.' && argv[1][n] != '\0') {
         ++n;
      }
      assert(n>0 && n < 199);
      strncpy(savefile, argv[1], n);            /* cp but drop the extension */
      savefile[n] = '\0';
      strncat(savefile, ".cfg", 4);
   }
   if(argc > 2) {                              /* case of a.out input result */
      fout = fopen(argv[2], "a");
      assert(fout != NULL);
   }
      
   read_model_parameters(fin, fecho);

   fprintf(fecho, "enter dimension of the system D:\n");
   fscanf(fin, "%d", &St.D);
   fprintf(fecho, "enter number of electrons N:\n");
   fscanf(fin, "%d", &St.N);
   St.no_dof = St.D*St.N;
   fprintf(fecho, "enter number of walkers:\n");
   fscanf(fin, "%d", &St.no_walkers);
   fprintf(fecho, "enter time step tau:\n");
   fscanf(fin, "%lf", &dummy);
   St.tau = dummy;
   St.R = NULL;
   St.Rnew = NULL;
   St.sum_cnt = 0.0;
   rate = 0.0;

   fprintf(fecho, "DMC=1 (true) for Diffusion MC, 0 for Variational MC, enter DMC:\n");
   fscanf(fin, "%d", &DMC); 
   fprintf(fecho, "enter total MC steps and MC discarded (separated with space):\n");
   fscanf(fin, "%d%d", &MCtot, &MCdis); 
   MCdis = MCdis/2;
   fprintf(fecho, "enter intervals for walker number control (two numbers, initial and final):\n");
   fscanf(fin, "%d%d", &MCint0, &MCinterval); 
   
   if(DMC) {
      printf("\nDiffusion quantum Monte Carlo information:\n");
      St.max_walkers = 10*St.no_walkers;                    /* 10 times OK ? */
   } else {
      printf("\nVariational quantum Monte Carlo information:\n");
      St.max_walkers = St.no_walkers;
   }
   printf("%d dimensions, %d electrons, %d walkers, tau=%g,\n",
           St.D, St.N, St.no_walkers, (double) St.tau);
   printf("%d degrees of freedom, %d maximum walkers allowed,\n",
           St.no_dof, St.max_walkers);
   printf("run %d steps with first %d steps discarded.\n",
           MCtot, 2*MCdis);
   if(DMC) {
      printf("Et is adjusted every (%d, %d) steps\n", MCint0, MCinterval);
   }
   printf("compute in %d-byte real\n", sizeof(real));

   occupation(St.N, fin, fecho);                    /* which orbitals to use */
   srand64(time(NULL));                           /* init random number seed */
   init_psi();                          /* allocate memory for theta, C, etc */

   fsave = fopen(savefile, "r");
   if(fsave == NULL) {
      printf("saved walker file does not exist!\n");
   }
   init(&St, fsave);                    /* allocate memory associated with s */

   if( !(fsave != NULL && DMC) ) {            /* we did not read R from file */
      (void) evolve(MCdis, &St, 0);                  /* equilibrate with VMC */
      print_state(fecho, &St);
      St.Et = St.sum_El/St.sum_cnt;            /* initialize Et by VMC value */
   }
   if(fsave != NULL) {
      fclose(fsave);
   }

   St.sum_El = 0.0;                               /* set statistics to zeros */
   St.sum_El2 = 0.0;        
   St.sum_cnt = 0.0;

   for(mc = 0; mc < MCdis; mc += MCint0) {
      (void) evolve(MCint0, &St, DMC);               /* equilibrate with DMC */
      if(DMC) do_p_control(&St);
   }
   fprintf(fecho, "after algo %d equilibration\n", DMC);
   print_state(fecho, &St);

   av_E = St.sum_El;                           /* remember to subtract later */
   av_E2 = St.sum_El2;               /* set to 0 is bad, since Est need them */
   av_cnt = St.sum_cnt;

   for(mc = 0; mc < (MCtot-2*MCdis); mc += MCinterval) {
      rate = evolve(MCinterval, &St, DMC);           /* equilibrate with DMC */
      if(DMC) do_p_control(&St);
   }

   fprintf(fecho, "Metropolis acceptance rate = %g\n", rate);
   St.sum_El -= av_E;
   St.sum_El2 -= av_E2;
   St.sum_cnt -= av_cnt;
   print_state(fecho, &St);
                                                                   /* output */
   if(argc > 2) {
      fprintf(fout, "%g  %g  %d  %d  %g\n", (double) get_B_field(), 
              (double) (St.sum_El/St.sum_cnt),
              get_angular_L(), get_spin_S(),
              (double) St.sum_cnt );
   }

   fsave = fopen(savefile, "w");
   assert(fsave != NULL);
   save_walkers(&St, fsave);
   fclose(fsave);

   return 0;
}

/* ------------------ end of main program -----------------------------------*/


#define MAX_ITEMS  3                         /* max number of items to print */
void print_state(FILE *fp, State *s)
{
   int i, jwk, imin, jmin;
   real e, e2, n;

   fprintf(fp, "\ndimension D = %d, electron number N = %d\n", s->D, s->N);
   fprintf(fp, "no_dof = %d, no_walkers = %d, max_walkers = %d\n",
                s->no_dof, s->no_walkers, s->max_walkers);
   fprintf(fp, "tau = %g, E_t = %g\n", (double) s->tau, (double) s->Et);

   n = s->sum_cnt;
   if(n>0.0) {
      e = (s->sum_El)/n;
      e2 = (s->sum_El2)/n;
      fprintf(fp, "number of samples = %g, <El> = %g, <El^2>-<El>^2 = %g\n",
                  (double) n, (double) e, (double) (e2-e*e) );
   } else {
      fprintf(fp, "no samples, sum_cnt = %g\n", (double) n);
   }
   
   jmin = (s->no_walkers <= MAX_ITEMS) ? s->no_walkers : MAX_ITEMS;
   imin = (s->no_dof <= MAX_ITEMS) ? s->no_dof : MAX_ITEMS;

   if(s->R != NULL) {
      for(jwk = 0; jwk < jmin; ++jwk) {
         fprintf(fp, "walker %d: E(R)=%g, R=(", jwk, (double) s->E[jwk]);
         if(s->R[jwk] != NULL) { 
            for(i = 0; i < imin; ++i) {
               fprintf(fp, "%f ", (double) s->R[jwk][i]);
            }
            if(s->no_dof > MAX_ITEMS) {
               fprintf(fp, "...");               /* rest of the info omitted */
            }
            fprintf(fp, ")\n");
         } else {
            fprintf(fp, "memory for R[%d] not allocated!\n", jwk);
         }
      }
      if(s->no_walkers > MAX_ITEMS) {
         fprintf(fp, "   ...\n");
      }
   } else {
      fprintf(fp, "memory for R not allocated!\n");
   }
   if(s->F2 != 0.0) {
      fprintf(fp, "<K> = %g, <K>/<F^2> - 1 = %g, <Im> = %g\n", 
              (double)(s->K/n), (double)(s->K/s->F2-1.0), (double) (s->Im/n) );
   }
   s->K = 0.0;
   s->F2 = 0.0;
   s->Im = 0.0;

}


/* this way of control does not seem to have a target? 
 */
void do_p_control(State *s) 
{
   real b, d, n;

   if(s->no_walkers == 0) {
      return;
   }
   n = s->Yn;

   if ( s->no_walkers < 0.049*(s->max_walkers) ||  
        s->no_walkers > 0.81*(s->max_walkers) ||
        n < 1.5 ) {                                       /* two large/small */
      if(n>=0.9) {
         d = 0.3 * (s->max_walkers);
         b = log( s->no_walkers/d );
         printf("too large/small, %d walkers, Et is changed from %g ", 
                 s-> no_walkers, (double) s->Et);
         s->Et = s->Et - b;
         printf("to %g\n", (double) s->Et);
      }
   } else if(n>=1.5) {                                        /* find tuning */
      d = n;           /* do least-squares fit, y = a + b t, but need b only */
      d = (d-1.0)*d*(d+1.0);              /* simplified due to t = 1,2,...,n */
      b = 6.0*( 2.0*(s->Y1) - (1+n)*(s->Y0) )/d;
#ifdef PRINT_A_LOT  
      printf("%d walkers, Et is changed from %g ", 
              s-> no_walkers, (double) s->Et);
#endif 
      s->Et = s->Et - b/(s->tau);
#ifdef PRINT_A_LOT
      printf("to %g\n", (double) s->Et);
#endif 
   }

   s->Y0 = 0.0;                           /* reset the sum Y_i and sum i*Y_i */
   s->Y1 = 0.0;
   s->Yn = 0.0;
}
