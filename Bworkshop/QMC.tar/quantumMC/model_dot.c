/* ----------------------------------------------------------------------------
            W A V E   F U N C T I O N S  -  Q U A N T U M   D O T
   --------------------------------------------------------------------------*/
/* 2D harmonic oscillator in a magnetic field, normalization ignored.
   The Hamiltonian of the problem is

   H^ = Sum_j[ 1/2(p_j+A_j)^2 + V(r_j) + gB/2s^j_z] + Sum_{i<j} 1/|r_i - r_j|
      = Sum_j h_j(omega) + B/2( L^j_z + g s^j_z) + coulomb
   where A = B/2(-y,x,0), V(r) = 1/2 omega_0 r^2 + dV(r), h_j is a 2D 
   oscillator at frequency omega^2 = omega_0^2 + B^2/4.  s_^j_z is 
   z-component of spin (with eigenvalue +/-(1/2)).

   The effective Hamiltonian for the amplitude A is
   H_eff = Sum_j h_j(omega) + 1/2(Del a)^2 + (B/2)( (da/d angle_j) + s^j_z)
           + coulomb.
   where Psi = A exp(ia), and H_eff = Re{ exp(-ia) H^ exp(ia) }
   Note that Re { Psi^(-1) H Psi } = A^(-1) H_eff A.

   Modified to read Hartree-Fock wavefunction.
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

#include "datatype.h"
#include "complex.h"

extern State St;                                  /* defined im main program */

                                           /* functions defined in this file */
void read_model_parameters(FILE *fin, FILE *fecho);             /* set param */
void occupation(int no_elec, FILE *fin, FILE *fecho);      /* orbital to use */
complex orbital(real *r, int j);                               /* theta_j(r) */
complex d_orbital(real *r, int j, int i);               /* d theta_j(r) dx_i */
complex laplacian_orbital(real *r, int j);               /* Del^2 theta_j(r) */
real jastrow(real R[]);                                         /* exp(J(R)) */
real jastrow_fac_ratio(real R[], real R_i, int i);        /* exp(J(R')-J(R)) */
real d_jastrow(real R[], int i);                               /* d/x_i J(R) */
real laplacian_jastrow(real R[], int no_dof);                  /* Del^2 J(R) */
real potential(real R[], int no_dof);                                /* V(R) */
real get_B_field(void);                                    /* return model.B */
int get_angular_L(void);                           /* total angular momentum */
int get_spin_S(void);                                          /* total spin */

                           /* static data/function are internal to this file */
/* A structure to hold the model parameters
 */
typedef struct {
   real omega;                                /* omega =sqrt(omega0^2+B^2/4) */
   real r0, r1;                                        /* perturbation range */
   real sigma2;                                      /* variance of gaussian */
   real V0;                                        /* perturbation amplitude */
   real B;                                                 /* magnetic field */
   real g;                                                   /* Lande factor */
               } Model_type;

/* Single particle basis energy and state labels.  This gives a term in the
   Hartree-Fock wavefunction. c is coefficient, such that 
   theta_j(r) = sum_k c_k basis_k(r)
   where basis_k(r) is Fock-Darwin solution.  Wavefunc[j] contains such
   a wavefunction for each electron j.
 */
typedef struct {
   real c;
   real eng;
   int n, m, s;
               } Occ_type;

typedef struct {
   int nterm;
   Occ_type *occ;
               } Wave_type;


static Model_type model;                   /* model parameters omega, B, etc */
static Wave_type *Wavefunc;        /* array of list of Occ for each electron */
                                                      /* this is made global */
int n_Spin_Up;                       /* number of spins that are in up state */


/* We handle two models, the ring-bump model of cos perturbation studied by
   Guclud Devrim and double-peak/valley gaussian at (r0,0) and (-r0,0)
   of standard deviation sigma.  The default is gaussian.  #define 
   MODEL_RING_BUMP will get the ring model.
*/
void read_model_parameters(FILE *fin, FILE *fecho)
{
   double dum, dum1;
   real omega0;

   fprintf(fecho, "Model parameters -- all in (effective) atomic units\n");
   fprintf(fecho, "enter parameter omega0\n");
   fscanf(fin, "%lf", &dum);
   omega0 = dum;
#ifdef MODEL_RING_BUMP
   fprintf(fecho, "enter perturbation range r0 r1\n");
   fscanf(fin, "%lf%lf", &dum, &dum1); 
   model.r0 = dum;
   model.r1 = dum1;
   model.sigma2 = 0.0;
   assert(model.r0 <= model.r1);
#else
   fprintf(fecho, "enter gaussian center r0 and standard deviation sigma\n");
   fscanf(fin, "%lf%lf", &dum, &dum1); 
   model.r0 = dum;
   model.r1 = 0.0;
   model.sigma2 = dum1*dum1;                     /* this is variance simga^2 */
#endif
   fprintf(fecho, "enter height of perturbation V0\n");
   fscanf(fin, "%lf", &dum); 
   model.V0 = dum;
   fprintf(fecho, "enter magnetic field B\n");
   fscanf(fin, "%lf", &dum); 
   model.B = dum;
   model.omega = sqrt( omega0*omega0 + 0.25*model.B*model.B );
   fprintf(fecho, "enter Lande factor g\n");
   fscanf(fin, "%lf", &dum); 
   model.g = dum;

   fprintf(fecho, 
        "initial model parameters: omega=%g, [r0,r1,simga^2]=[%g,%g,%g], V0=%g, B=%g, g=%g\n",
            (double) model.omega, (double) model.r0, 
            (double) model.r1, (double) model.sigma2, (double) model.V0, 
            (double) model.B, (double) model.g );
}
   
   
real get_B_field(void)                /* we use object-oriented concept here */
{
   return model.B;
}

static real single_particle_eng(int n, int m, int s)
{
   return (2*n + 1 + abs(m))*model.omega + 0.5*model.B*(m + 0.5*model.g*s);
}

/* Which orbital to occupy with n electrons?  If not from the input,
   we occupy the first n states according to non-interacting
   energies.  The energy is 
   E_{n,m,s} = (2n + 1 + |m|)*omega + 0.5B(m+ g*s/2).
 */

static int compare(Occ_type *a, Occ_type *b)
{
  if((*a).eng < (*b).eng) {
    return -1;
  } else if ((*a).eng == (*b).eng) {
    return 0;
  } else {
    return 1;
  }
}
   
void occupation(int no_elec, FILE *fin, FILE *fecho)
{
   Occ_type *temp_occ;
   Wave_type wt;
   int i, j, jmax, k, n, m, s, nterm;
   int find, yes, up, m0;
   double d;
   
#define N_MAX 100
#define M_MIN (-100)
#define M_MAX 100

/* we should try to compute the limit above based on no_elec
 */
              /* each element wavefunc[i] is a pointer to Occ_type and nterm */
   Wavefunc  = (Wave_type *) malloc( no_elec*sizeof(Wave_type) );
   assert(Wavefunc != NULL);

   fprintf(fecho, "Number of terms by hand, one for each electron, enter 1/0 for yes/no:\n");
   fscanf(fin, "%d", &yes);
   if(yes) {
      fprintf(fecho, 
         "enter %d orbitals in the form of term and list of c n m s:\n", 
          no_elec);
      n_Spin_Up = 0;
      for(j = 0; j < no_elec; ++j) {
         fscanf(fin, "%d", &nterm);
         assert(nterm > 0);
         Wavefunc[j].nterm = nterm;
         Wavefunc[j].occ = (Occ_type *) malloc(nterm*sizeof(Occ_type));
         assert(Wavefunc[j].occ != NULL);
         for(k = 0; k < nterm; ++k) {
            fscanf(fin, "%lf%d%d%d", &d, &n, &m, &s);
            assert(n>=0 && n < 127);
            assert(abs(m) < 127);
            assert(abs(s) == 1);
            Wavefunc[j].occ[k].c = d;            /* coefficient of expansion */
            Wavefunc[j].occ[k].eng = single_particle_eng(n,m,s);
            Wavefunc[j].occ[k].n = n;
            Wavefunc[j].occ[k].m = m;
            Wavefunc[j].occ[k].s = s;
            if(k == 0) {
              up = s;
              m0 = m;
            } else {                        /* all s values must be the same */
              assert(up == s);             /* for s is a good quantum number */
            } 
         }
         if(up>0) { ++n_Spin_Up; }
      }
      goto End; 
   }

   jmax = N_MAX*(M_MAX-M_MIN)*2;      /* generate automatic, but only 1 term */
   assert(jmax > no_elec);
   temp_occ = (Occ_type *) malloc( jmax*sizeof(Occ_type) );
   assert(temp_occ != NULL);
                                  /* run over all states (not very efficient */
   j = 0;
   for(n = 0; n < N_MAX; ++n) {
      for(m = M_MIN; m < M_MAX; ++m) {
         for(s = -1; s <= 1; s += 2) {
            temp_occ[j].c = 1.0;
            temp_occ[j].eng = single_particle_eng(n,m,s);
            temp_occ[j].n = n;
            temp_occ[j].m = m;
            temp_occ[j].s = s;
            ++j;
         }
      }
   }
   assert(j == jmax);

   qsort(temp_occ, jmax, sizeof(Occ_type), compare);

   n_Spin_Up = 0;
   for(j = 0; j < no_elec; ++j) {
      Wavefunc[j].nterm = 1;
      Wavefunc[j].occ = (Occ_type *) malloc(sizeof(Occ_type));
      assert(Wavefunc[j].occ != NULL);
      Wavefunc[j].occ[0] = temp_occ[j];
      if(temp_occ[j].s == 1) {
         ++n_Spin_Up;
      }
   }

   free(temp_occ);

End:
   /* permute the + state to the front, needed for constructing theta matrix */
   for(j = 0; j < no_elec; ++j) {
      if(Wavefunc[j].occ[0].s < 0) {        /* find a + behind it to permute */
         find = 0;
         for(i = j+1; i < no_elec; ++i) {
            if(Wavefunc[i].occ[0].s > 0) {
               find = 1;
               break;
            }
         }
         if(find) {                        /* swap the contents of structure */
            wt = Wavefunc[j];
            Wavefunc[j] = Wavefunc[i];
            Wavefunc[i] = wt;
         } else {                   /* cannot find, then it is in good order */
            break;
         }
      }
   }
        
         
   fprintf(fecho, "The following wavefunctions [seq (c, eng, n m s)] are occupied\n");
   for(j = 0; j < no_elec; ++j) {
      fprintf(fecho, "elec %d", j);
      for(k = 0; k < Wavefunc[j].nterm; ++k) {
         fprintf(fecho, ", %g (%g %d %d %d)", 
            (double) Wavefunc[j].occ[k].c, 
            (double) Wavefunc[j].occ[k].eng, 
                     Wavefunc[j].occ[k].n,
                     Wavefunc[j].occ[k].m,
                     Wavefunc[j].occ[k].s );
      }
      fprintf(fecho, "\n");
   }
}

/* return the total angular momentum z component and total spin 
   of occupied states
 */
int get_angular_L(void)
{
   int j, L;

   L = 0;
   for(j = 0; j < St.N; ++j) {
      L += Wavefunc[j].occ[0].m;
   }
   return L;
}
 
int get_spin_S(void)
{
   int j, S;

   S = 0;
   for(j = 0; j < St.N; ++j) {
      S += Wavefunc[j].occ[0].s;
   }
   return S;
}
 

/* Generalized Laguerre polynomials Laguerre(n, m, x) are related to hydrogen
   atom as well as 2D oscillator wave functions in quantum mechanics. They 
   satisfy the differential equation , 
        x y'' + (1+m-x) y' + n y = 0,
   and the orthogonality relation 
        int_0^inf L(n,m,x) L(n', m, x) x^m exp(-x) dx = 0 when n != n'
   and (n+m)!/n! when n = n'.

   The definition here follow mathematica.
*/

static real laguerre(int n, int m, real x)
{
   real p1, p2, p3;
   int j;
   
   assert(n >= 0 && m >= 0);
   p2 = 0.0;
   p1 = 1.0;
   for(j = 0; j < n; ++j) {        /* Laguerre polynomial recursion relation */
      p3 = p2;                              /* see Arfken p.620, or NR p.153 */
      p2 = p1;
      p1 = ( (2*j+m+1-x)*p2 - (j+m)*p3 )/(j+1);
   };

   return p1;
}


/* When expanding in basis, the basis must be properly normalization,
   otherwise in the sum c_j basis_j, c_j because arbitrary.
 */
static real norm_factor(int n, int abs_m)
{
   int i;
   real fac, cnl;

   assert(n>=0 && abs_m >=0);

   fac = 1.0;
   for(i = 1; i <= abs_m; ++i) {                              /* (n+|m|)!/n! */
      fac *= (n+i);
   }
   cnl = sqrt( pow(model.omega, (double) (abs_m+1) )/(M_PI*fac) );

   return cnl;
   
}

/* Compute the jth orbital of single electron wavefunction theta_j(r) 
   at point r = (r[0], r[1]) = (x,y).  The orbitals are sum of basis
   Psi_{n,m,s}(x,y,a) = (normalization) *
      r^|m| L_n^|m|(Omega r^2) exp(-0.5Omega*r^2) exp(i m*angle) chi_s(a)
   where n = 0, 1, 2, ..., m = ..., -1, 0, +1, +2, ..., and s = + or -.
   (r,angle) are the polar coordinates of (x,y), a is the spin variable
   a=+1 or -1,  and spin eigen states chi_{+} = (1,0), chi_{-} = (0,1).

   The spin part is not handled here, but in cpsi.c.

   It would be more efficient to combine orbital, d_orbital and
   laplacian_orbital into one function.
 */
complex orbital(real *r, int j)
{
   real r2, angle, rho, a;
   int k, n, m, abs_m;
   complex z, res;

   assert(j >=0 && j < St.N);
   assert(2 == St.D);

   r2 = r[0]*r[0] + r[1]*r[1];                          /* vector r = (x, y) */
   angle = atan2(r[1],r[0]);              /* atan2(y,x), such that tan = y/x */
   rho = r2 * model.omega;

   res.Re = 0.0;
   res.Im = 0.0;
   for(k = 0; k < Wavefunc[j].nterm; ++k) {            /* do sum c_k basis_k */
      n = Wavefunc[j].occ[k].n;
      m = Wavefunc[j].occ[k].m;
      abs_m = abs(m);
   
      if(abs_m > 0) {
         a = pow(r2, 0.5*abs_m) * laguerre(n, abs_m, rho) * exp(-0.5*rho);
      } else {
         a = laguerre(n, abs_m, rho) * exp(-0.5*rho);
      }
      a *= norm_factor(n,abs_m);
      z.Re = a * cos(m*angle);                        /* z is value of basis */
      z.Im = a * sin(m*angle);

      res.Re += (Wavefunc[j].occ[k].c)*(z.Re);
      res.Im += (Wavefunc[j].occ[k].c)*(z.Im);
   }

   return res;
}


/* Compute partial derivative of jth orbital with respect to the i-th
   coordinate component. d theta_j(r) dx_i, where r = (x_0, x_1, ...).

   Use the relation between partial derivatives in (x,y) and in (r,theta):
   df/dx = d angle/dx df/d angle + dr/dx df/dr
   df/dy = d angle/dy df/d angle + dr/dy df/dr
   where d angle/dx = - y/r^2, d angle/dy = x/r^2,
   and dr/dx = x/r, dr/dy = y/r.
 */
complex d_orbital(real *r, int j, int i)
{ 
   int n, m, abs_m, s, k;
   real x, y, r2, angle, rho, mag, a;
   complex z, res, psi, dangle;

   assert(j >= 0 && j < St.N);
   assert(i >= 0 && i < St.D);
   assert(2 == St.D);                             /* dimension of the system */

   x = r[0];
   y = r[1];
   r2 = x*x + y*y;                     /* there will be problem when r2 == 0 */
   angle = atan2(y,x);
   rho = r2 * model.omega;                         /* |(1/r) d psi/dr| = mag */

   res.Re = 0.0;
   res.Im = 0.0;
   for(k = 0; k < Wavefunc[j].nterm; ++k) {            /* do sum c_k basis_k */
      n = Wavefunc[j].occ[k].n;
      m = Wavefunc[j].occ[k].m;
      s = Wavefunc[j].occ[k].s;

      assert((j < n_Spin_Up && s==1) || (j >= n_Spin_Up && s==-1) );

      abs_m = abs(m);

      if(abs_m > 0) {
         a = pow(r2, 0.5*abs_m) * laguerre(n, abs_m, rho) * exp(-0.5*rho);
      } else {
         a = laguerre(n, abs_m, rho) * exp(-0.5*rho);
      }
      psi.Re = a * cos(m*angle);
      psi.Im = a * sin(m*angle);
      dangle.Re = -m*psi.Im;                      /* d psi/d angle = i m psi */
      dangle.Im = m*psi.Re;

      mag = (abs_m - rho) * laguerre(n, abs_m, rho); 
      if(n>0) {
         mag -= 2.0*rho * laguerre(n-1, abs_m+1, rho);
      }
      mag *= exp(-0.5*rho)* pow(r2, 0.5*(abs_m-2));

      if(i == 0) {                                              /* partial x */
         z.Re = - dangle.Re * y/r2 + cos(m*angle)*x*mag;
         z.Im = - dangle.Im * y/r2 + sin(m*angle)*x*mag;
      } else if (i == 1) {                                      /* partial y */
         z.Re = dangle.Re * x/r2 + cos(m*angle)*y*mag;
         z.Im = dangle.Im * x/r2 + sin(m*angle)*y*mag;
      } else {
         assert(0);
      }
      z.Re *= norm_factor(n, abs_m);
      z.Im *= norm_factor(n, abs_m);

      res.Re += (Wavefunc[j].occ[k].c)*(z.Re);
      res.Im += (Wavefunc[j].occ[k].c)*(z.Im);
   }
   
   return res;
}


/* Compute laplacian on psi_orbital, delta^2_j theta(r_j)
   Use one-partial schrodinger Eq can avoid take derivatives.
   We use the fact that 
   [ - (1/2) del^2 + 1/2 omega^2 r^2 ] theta(r) = E theta(r)
 */
complex laplacian_orbital(real *r, int j)
{
   int n, m, k, abs_m;
   real fac, a, r2, angle, rho;
   complex psi, z, res;

   r2 = r[0]*r[0] + r[1]*r[1];                          /* vector r = (x, y) */
   angle = atan2(r[1],r[0]);              /* atan2(y,x), such that tan = y/x */
   rho = r2 * model.omega;

   res.Re = 0.0;
   res.Im = 0.0;
   for(k = 0; k < Wavefunc[j].nterm; ++k) {            /* do sum c_k basis_k */
      n = Wavefunc[j].occ[k].n;
      m = Wavefunc[j].occ[k].m;

      abs_m = abs(m);
      if(abs_m > 0) {
         a = pow(r2, 0.5*abs_m) * laguerre(n, abs_m, rho) * exp(-0.5*rho);
      } else {
         a = laguerre(n, abs_m, rho) * exp(-0.5*rho);
      }
      a *= norm_factor(n, abs_m);
      psi.Re = a * cos(m*angle);
      psi.Im = a * sin(m*angle);
      fac = model.omega * rho - 2*(2*n + 1 + abs_m)*model.omega;
      z.Re = fac * psi.Re;
      z.Im = fac * psi.Im;

      res.Re += (Wavefunc[j].occ[k].c)*(z.Re);
      res.Im += (Wavefunc[j].occ[k].c)*(z.Im);
   }
   return res;
}

real jastrow(real R[])
{
   return 1.0;
}

/* Compute exp(J(R')-J(R))
 */
real jastrow_fac_ratio(real R[], real R_i, int i) 
{
   assert(i >= 0 && i < St.no_dof);
   return 1.0; 
}


/* Compute d J(R)/dx_i
   where i runs for all degrees of freedom.
 */
real d_jastrow(real R[], int i)
{
   assert(i >= 0 && i < St.no_dof);
   return 0.0;
}


/* Compute full D*N dimensional laplacian Delta^2 on J(R).
 */
real laplacian_jastrow(real R[], int no_dof)
{
   assert(no_dof == St.no_dof);
   return 0.0;
}


/* The bump perturbation to the parabolic potential
 */
static real V_perturb(real *r)
{
   real res, rabs, arg, dV, xm, xp, y;

   if(model.V0 == 0.0) {
      return 0.0;
   }
#ifdef MODEL_RING_BUMP 
   rabs = sqrt(r[0]*r[0] + r[1]*r[1]);
   if( rabs <= model.r0 || rabs >= model.r1) {
      return 0.0;
   } else {
      arg = 2.0*M_PI*(rabs-model.r0)/(model.r1-model.r0);
      dV = model.V0 * ( 1.0 - cos(arg));
      return dV;
   }
#else
   xm = r[0] - model.r0;
   xp = r[0] + model.r0;
   y = r[1];
   res = model.V0*(exp(-0.5*( xm*xm + y*y)/model.sigma2)
                 + exp(-0.5*( xp*xp + y*y)/model.sigma2) );
   return res;
#endif
  
}

/* The potential contains the single particle part, Sum (1/2)omega x^2
   and electron-electron interaction.  This is the model-dependent part of
   effective potential.
 */
real potential(real R[], int no_dof)
{
   real pot1, pot2, pot3, pot4, d, d2;
   int i, j, k, n_elec, i_offset, j_offset;

   pot1 = 0.0;                                      /* omega^2 r^2 potential */
   for(i = 0; i < no_dof; ++i) {
      pot1 += R[i]*R[i];
   }
   pot1 *= 0.5*model.omega*model.omega;

   n_elec = St.N;
   pot2 = 0.0;
   pot3 = 0.0;
   for(i = 0; i < n_elec; ++i) {
      i_offset = i * St.D;
      for(j = i+1; j < n_elec; ++j) {
         j_offset = j * St.D;
         d2 = 0.0;                                    /* compute |r_i - r_j| */
         for(k = 0; k < St.D; ++k) {
            d = R[i_offset+k] - R[j_offset+k];
            d2 += d*d;
         }
         d = sqrt(d2);
         pot2 += 1.0/d;                             /* Coulomb 1/|r_i - r_j| */
      }
      pot3 += V_perturb(R+i_offset);
   }
  
                             /* (1/4) g B Sum (sigma), g=2 for free electron */
   pot4 = 0.25*model.B*model.g*(2*n_Spin_Up - n_elec);          /* spin part */

#ifdef PRINT_A_LOT
   printf("1/2 w^2 r^ = %g, 1/r1-r2|=%g, perturb v = %g, spin =%g\n",
           pot1, pot2, pot3, pot4);
#endif
   return pot1 + pot2 + pot3 + pot4;
}
