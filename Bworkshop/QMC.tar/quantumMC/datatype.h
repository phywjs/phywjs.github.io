#ifndef DATATYPE_H
#define DATATYPE_H
/* ----------------------------------------------------------------------------
                        N E W   D A T A   T Y P E S
   --------------------------------------------------------------------------*/

/* real can be redefined to mean float, double, or long double 
 */
typedef double real;


/* complex number, each component is of type real
 */
typedef struct {
   real Re;
   real Im;
} complex;


/* The struct State contains a complete state of the current simulation
 */
typedef struct {
                  int D;                          /* dimension of the system */
                  int N;                              /* number of electrons */
                  int no_dof;          /* number of degrees of freedom = D*N */
                  int no_walkers;                       /* number of walkers */
                  int max_walkers;          /* max number of walkers allowed */
                  real **R;                 /* (pointer to) array of walkers */
                  real **Rnew;                    /* newly generated walkers */
                  real *E;                    /* local energy of each walker */
                  real *E_curr;                      /* new E of each walker */
                  real tau;                      /* imaginary time step size */
                  real Et;                                   /* trial energy */
                  real sum_El;                        /* sum of local energy */
                  real sum_El2;                     /* sum of energy squared */
                  real sum_cnt; /* how many summed, real to prevent overflow */
                  real Yn, Y0, Y1; /*sum1,sumY_iand iY_i,Y_i=log(no_walkers) */
                  real F2, K;                  /* use for checking <F^2>=<K> */
                  real Im;         /* imaginary part of local Psi^(-1) H Psi */
               } State;


#define EPSILON 1.0e-6

#ifndef M_PI
#define M_PI 3.141592653589793238462
#endif

#undef PRINT_A_LOT

#endif
