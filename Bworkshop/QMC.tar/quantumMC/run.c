/** run the QMC program, scanning for values of B **/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int main(int argc, char **argv)
{
   FILE *fin, *fout;
   char infile[200], resfile[200], logfile[200];
   char commd[200], s[200];
   double B, B0, B1, dB;
   int line;
   time_t tm;

   if(argc != 6) {
      printf("use: %s exec_file input_file B0 B1 dB\n", argv[0]);
      exit(0);
   }

   B0 = atof(argv[3]);
   B1 = atof(argv[4]);
   dB = atof(argv[5]);

   strncpy(infile, argv[2], 100);
   strncat(infile, ".in", 3);
   strncpy(resfile, argv[2], 100);
   strncat(resfile, ".res", 4);
   strncpy(logfile, argv[2], 100);
   strncat(logfile, ".log", 4);
   
   sprintf(commd, "%s %s %s 1>>%s 2>>%s\n", 
           argv[1], infile, resfile, logfile, logfile);
   printf("Run %s", commd);
   printf("For input file %s, B from %g to %g in step %g\n",
           argv[2], B0, B1, dB);

   for(B = B0; B <= B1; B += dB) {
                                      /* generate an input data file for qmc */
      fin = fopen(argv[2], "r");
      fout = fopen(infile, "w");
      line = 0;
      while( fgets(s, 100, fin) != NULL ) {
         ++line;
         if(line == 4) {
            fprintf(fout, "%.15g\n", B);
         } else {
            fputs(s, fout);
         }
      }
      fclose(fin);
      fclose(fout);

      tm = time(NULL);
      printf("B=%g, %s", B, ctime(&tm));
      system(commd);
   }
   printf("finished!\n");
   return 0;
}
