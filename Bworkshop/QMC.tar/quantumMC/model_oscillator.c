/* ----------------------------------------------------------------------------
                     M O D E L   W A V E   F U N C T I O N S

   --------------------------------------------------------------------------*/
/* D dimensional harmonic oscillator, wavefunction

   Prod_k phi(x_k),  phi(x) = H_n(x) exp(-x^2/2), 
 
   normalization ignored.
*/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

#include "datatype.h"

extern State St;                                  /* defined im main program */

                                           /* functions defined in this file */
real orbital(real *r, int j);                                  /* theta_j(r) */
real d_orbital(real *r, int j, int i);                  /* d theta_j(r) dx_i */
real laplacian_orbital(real *r, int j);                  /* Del^2 theta_j(r) */
real jastrow(real R[]);                                         /* exp(J(R)) */
real jastrow_fac_ratio(real R[], real R_i, int i);        /* exp(J(R')-J(R)) */
real d_jastrow(real R[], int i);                               /* d/x_i J(R) */
real laplacian_jastrow(real R[], int no_dof);                  /* Del^2 J(R) */
real potential(real R[], int no_dof);                                /* V(R) */

/* we'll do a better job later */
static void  occupation(int j, int *n_occ, int d)
{
   if(d == 1) {
      n_occ[0] = j;
   } else if (d == 2) {
      if(j == 0) {
         n_occ[0] = 0; n_occ[1] = 0;
      } else if (j == 1) {
         n_occ[0] = 0; n_occ[1] = 1;
      } else if (j == 2) {
         n_occ[0] = 1; n_occ[1] = 0;
      } else if (j == 3) {
         n_occ[0] = 0; n_occ[1] = 2;
      } else if (j == 4) {
         n_occ[0] = 1; n_occ[1] = 1;
      } else if (j == 5) {
         n_occ[0] = 2; n_occ[1] = 0;
      } else {
         assert(j <= 5);
      }
   } else if (d == 3) {
      if(j == 0) {
         n_occ[0] = 0; n_occ[1] = 0; n_occ[2] = 0;
      } else if (j == 1) {
         n_occ[0] = 0; n_occ[1] = 0; n_occ[2] = 1;
      } else if (j == 2) {
         n_occ[0] = 0; n_occ[1] = 1; n_occ[2] = 0;
      } else if (j == 3) {
         n_occ[0] = 1; n_occ[1] = 0; n_occ[2] = 0;
      } else {
         assert(j <= 3);
      }
   } else {
      assert(d >= 1 && d <= 3);                             /* cannot handle */
   }
}

static real hermite(real x, int n)
{
   if(n == 0) {
      return 1.0;
   } else if (n == 1) {
      return 2.0*x;
   } else if(n>1){
      return 2.0*x*hermite(x, n-1) - 2.0*(n-1)*hermite(x,n-2);
   }
   return 0.0;
}


/* Compute the jth orbital of single electron wavefunction theta_j(r) 
   at point r = (x,y,...).  This is problem dependent.
 */
real orbital(real *r, int j)
{
   real fac, sum, res;
   int d, k;
   int *n_occ;

   assert(j >=0 && j < St.N);
   d = St.D;                                      /* dimension of the system */
   n_occ = (int *) malloc( d * sizeof(int));
   assert(n_occ != NULL);

   sum = 0.0;
   for(k = 0; k < d; ++k) {
      sum += r[k]*r[k];
   }
   fac = exp(-0.5*sum); 

   occupation(j, n_occ, d);     /* return in n_occ which sub-state to occupy */

   res = 1.0;
   for(k = 0; k < d; ++k) {
      res *= hermite(r[k], n_occ[k]);
   }

   free(n_occ);

   return fac*res;
}


/* Compute partial derivative of jth orbital with respect to the i-th
   coordinate component. d theta_j(r) dx_i, where r = (x_1, x_2, ...).
 */
real d_orbital(real *r, int j, int i)
{ 
   real fac, sum, res;
   int d, k, *n_occ;

   assert(j >= 0 && j < St.N);
   assert(i >= 0 && i < St.D);
   d = St.D;                                      /* dimension of the system */
   n_occ = (int *) malloc( d * sizeof(int));
   assert(n_occ != NULL);

   sum = 0.0;
   for(k = 0; k < d; ++k) {
      sum += r[k]*r[k];
   }
   fac = exp(-0.5*sum); 

   occupation(j, n_occ, d);      /* return in n_occ which substate to occupy */

   res = 2.0*n_occ[i]*hermite(r[i],n_occ[i]-1) - r[i]*hermite(r[i],n_occ[i]);
   for(k = 0; k < d; ++k) {
      if (k == i) continue;                                /* skip i-th term */
      res *= hermite(r[k], n_occ[k]);
   }

   free(n_occ);

   return fac*res;
}


/* Compute laplacian on psi_orbital, delta^2_j theta(r_j)
   Use one-partial schrodinger Eq can avoid take derivatives.
 */
real laplacian_orbital(real *r, int j)
{
   int d, k, *n_occ;
   real fac;

   d = St.D;                                      /* dimension of the system */
   n_occ = (int *) malloc( d * sizeof(int));
   assert(n_occ != NULL);
   
   occupation(j, n_occ, d);
   fac = 0.0;
   for(k = 0; k < d; ++k) {
      fac += r[k]*r[k] - 2.0*n_occ[k] - 1.0;
   }

   free(n_occ);
  
   return fac * orbital(r, j);

}

real jastrow(real R[])
{
   return 1.0;
}

/* Compute exp(J(R')-J(R))
 */
real jastrow_fac_ratio(real R[], real R_i, int i) 
{
   assert(i >= 0 && i < St.no_dof);
   return 1.0; 
}


/* Compute d J(R)/dx_i
   where i runs for all degrees of freedom.
 */
real d_jastrow(real R[], int i)
{
   assert(i >= 0 && i < St.no_dof);
   return 0.0;
}


/* Compute full D*N dimensional laplacian Delta^2 on J(R).
 */
real laplacian_jastrow(real R[], int no_dof)
{
   assert(no_dof == St.no_dof);
   return 0.0;
}


/* The potential contains the single particle part, Sum (1/2) x^2
   and electron-electron interaction
 */
real potential(real R[], int no_dof)
{
   real pot1, pot2, d, d2;
   int i, j, k, n_elec, i_offset, j_offset;

   pot1 = 0.0;
   for(i = 0; i < no_dof; ++i) {
      pot1 += R[i]*R[i];
   }
   pot1 = 0.5*pot1;

   n_elec = St.N;
   pot2 = 0.0;
   for(i = 0; i < n_elec; ++i) {
      i_offset = i * St.D;
      for(j = i+1; j < n_elec; ++j) {
         j_offset = j * St.D;
         d2 = 0.0;                                    /* compute |r_1 - r_2| */
         for(k = 0; k < St.D; ++k) {
            d = R[i_offset+k] - R[j_offset+k];
            d2 += d*d;
         }
         d = sqrt(d2);
         pot2 += 1.0/d;                             /* Coulomb 1/|r_i - r_j| */
      }
   }
 
   return pot1 + pot2;
}

