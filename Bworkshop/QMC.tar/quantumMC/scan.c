/** Run the QMC program, scanning for values of the occupations,
    with trial states ordered in sequence of total energy, and scan the
    value of magnetic field B.
 **/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <assert.h>

#define N_MAX 50
#define M_MIN (-100)
#define M_MAX 100
/** seems good for N < 6
#define modelK  0.27
#define modelJ  0.80
try this for N approx 10 **/
#define modelK  0.19
#define modelJ  0.75

#define MAX_SCAN_LS  1000           /* scan at most 1000 E levels for each B */


typedef struct {            /* Single particle basis energy and state labels */
   double eng;
   int n, m, s;
} Occ_type;

typedef struct {                                   /* many-body wavefunction */
   double Eng;              /* total energy, orbital angular moment and spin */
   int L;
   int S;
   int *ind;                                  /* index to array of spsGlobal */
} State_type;

static int compare(Occ_type *a, Occ_type *b)
{
  if((*a).eng < (*b).eng) {
    return -1;
  } else if ((*a).eng == (*b).eng) {
    return 0;
  } else {
    return 1;
  }
}

static int compare_state(State_type *a, State_type *b)
{
  if((*a).Eng < (*b).Eng) {
    return -1;
  } else if ((*a).Eng == (*b).Eng) {
    return 0;
  } else {
    return 1;
  }
}

static double binomial(int n, int m)
{
   int k, i;
   double prod;

   k = (m < (n-m)) ? m : (n-m);                      /* take the smaller one */
   prod = 1.0;
   for(i = 1; i <= k; ++i) {                       /* compute  n!/(m!(n-m)!) */
      prod *= (double) (n-i+1)/ (double) i;
   };
   return prod;
}


int main(int argc, char **argv)
{
   FILE *fin, *fout, *fp;
   char infile[200], resfile[200], logfile[200];
   char commd[200], delete[200], str[200];
   double omega0, omega, g, etot;
   double dum, dum1, B, B0, B1, dB, Bin, Ein;
   Occ_type *temp_occ, *occ, ***biglist;
   State_type *state, **reslist;
   int *remove, *has;
   int Lin, Sin;
   int i, j, jmax, k, kmax, n, m, s, L, S, lp, lp_max;
   int line, nex, no_elec, cnt, seq, state_length, save_length;
   time_t tm;

   if(argc != 5 && argc !=7) {
      printf("use: %s exec_file input_file nex B0 [B1 dB]\n", argv[0]);
      exit(0);
   }

/* Use all information provided in input_file except the occupation
   and B.  We use nex >= 0 more states to scan the occupations.
   All possible states with no_elec+nex single particle occupation
   binomial combinations are tried in order of increasing energy.
 */
   nex = atoi(argv[3]);
   assert(nex < M_MAX && nex >=0);
   B0 = atof(argv[4]);
   if(argc == 7) {                              /* do B0, B0+dB, B0+2dB, etc */
      B1 = atof(argv[5]);
      dB = atof(argv[6]);
   } else {                                                /* do B = B0 only */
      assert(argc == 5);
      B1 = B0 + 0.01;
      dB = 1.0;
   }

   strncpy(infile, argv[2], 100);
   strncat(infile, ".sin", 4);                /* input file name for qmc.exe */
   strncpy(resfile, argv[2], 100);
   strncat(resfile, ".sres", 5);               /* results written by qmc.exe */
   strncpy(logfile, argv[2], 100);
   strncat(logfile, ".slog", 5);                     /* log file for qmc.exe */
   
   sprintf(commd, "%s %s %s 1>>%s 2>>%s\n",
           argv[1], infile, resfile, logfile, logfile);
   sprintf(delete, "rm -f %s\n", resfile);
   printf("Run %s", commd);
   printf("For input file %s\n", argv[2]);

   fin = fopen(argv[2], "r");
   assert(fin != NULL);
   fscanf(fin, "%lf", &omega0);
   fscanf(fin, "%lf%lf", &dum, &dum1);                         /* skip r0 r1 */
   fscanf(fin, "%lf", &dum);                                      /* skip V0 */
   fscanf(fin, "%lf", &B);
   fscanf(fin, "%lf", &g);
   fscanf(fin, "%lf", &dum);                                            /* D */
   fscanf(fin, "%d", &no_elec);
   fclose(fin);
   printf("Scan for omega0=%g, g=%g, elec N=%d, extra %d states\n",
           omega0, g, no_elec, nex);


   jmax = N_MAX*(M_MAX-M_MIN)*2;
   temp_occ = (Occ_type *) malloc( jmax*sizeof(Occ_type) );
   assert(jmax > no_elec && no_elec < M_MAX);
   assert(temp_occ != NULL);
                                   /* memory for generating many-body states */
   remove = (int *) malloc( (nex+1)*sizeof(int));
   has = (int *) malloc( (no_elec+nex)*sizeof(int) );
   assert(remove != NULL);
   assert(has != NULL);

   state_length = (int) (binomial( no_elec+nex, nex ) + 0.001);
   state = (State_type *) malloc(state_length*sizeof(State_type));
   assert(state != NULL);
   for(seq = 0; seq < state_length; ++seq) {
      state[seq].ind = (int *) malloc( no_elec*sizeof(int) );
      assert(state[seq].ind != NULL);
   }
   save_length = (state_length < MAX_SCAN_LS)? state_length : MAX_SCAN_LS;

   lp = 0;
   for(B = B0; B <= B1; B += dB) {                         /* count B points */
      ++lp;
   }
   lp_max = lp;
   biglist = (Occ_type ***) malloc(lp_max*sizeof(Occ_type **));    /* each B */
   reslist = (State_type **) malloc(lp_max*sizeof(State_type *));  
   assert(biglist != NULL);
   assert(reslist != NULL);
                                                 
   lp = 0;
   for(B = B0; B <= B1; B += dB) {                      /** big B loop begin */

      omega = sqrt(omega0*omega0+0.25*B*B);
      j = 0;
      for(n = 0; n < N_MAX; ++n) {
         for(m = M_MIN; m < M_MAX; ++m) {
            for(s = -1; s <= 1; s += 2) {
               temp_occ[j].eng = (2*n+1+abs(m))*omega + 0.5*B*(m + 0.5*g*s);
               temp_occ[j].n = n;
               temp_occ[j].m = m;
               temp_occ[j].s = s;
               ++j;
            }
         }
      }
      assert(j == jmax);

      /* Find possible candidates by sorting from single particle
         energy.  May be improved by taking into account of interactions?
      */
      qsort(temp_occ, jmax, sizeof(Occ_type), compare);

      printf("at B=%g, First %d single particle states are (n,m,s,eng):\n", 
              B, no_elec+nex);
      for(j = 0; j < no_elec + nex; ++j) {
         printf("state[%d] = {%d, %d, %d,  %g};\n", j, 
                 temp_occ[j].n, temp_occ[j].m,
                 temp_occ[j].s, temp_occ[j].eng);
      }
       
      /* We need to do a combinatorial choice of no_elec from nex + no_elec.
         We remove nex orbitals from total nex+no_elec.  remove[i] is the
         index to orbital temp_occ that is removed.  We maintain 
         remove[i] < remove[i+1].  The outer while loop runs exactly 
         (no_elec+nex)!/(nex! * no_elec!) times.  We generate all the states 
         and sort them according to total energy.
       */

      assert(nex+no_elec <= jmax);
      for(i = 0; i < nex; ++i) {         /* initially, last nex are not used */
        remove[i] = no_elec + i;
      }
      remove[nex] = 0;            /* extra counter for terminating condition */

      seq = 0;
      while(remove[nex] == 0) {             /* loop over all possible states */
         for(j = 0; j < nex+no_elec; ++j) {
            has[j] = 1;
         }
         for(i = 0; i < nex; ++i) {
            assert(remove[i]>=0 && remove[i] < no_elec+nex);
            assert(remove[i] < remove[i+1] || i == (nex-1));
            has[remove[i]] = 0; 
         }
   
         etot = 0.0;
         L = 0;
         S = 0;
         cnt = 0;
         for(j = 0; j < nex+no_elec; ++j) {
            if(has[j]) {
               state[seq].ind[cnt] = j;
               etot += temp_occ[j].eng;
               L += temp_occ[j].m;
               S += temp_occ[j].s;
               ++cnt;
            }
         }
         assert(cnt == no_elec);
                                  /* energy use a constant interaction model */
         state[seq].Eng = etot + sqrt(omega)*( - 0.25*modelK*S*S   
                       + 0.5*no_elec*(no_elec-1)*modelJ 
                       - 0.25*no_elec*(no_elec-2)*modelK );
         state[seq].L = L;
         state[seq].S = S;
      
         --remove[0]; 
         if(remove[0] < 0) {           /* trick, move but keep the less than */
            k = 0;
            while( remove[k] < k && k < nex) {
               --remove[k+1];
               for(j = k; j >= 0; --j) {
                  remove[j] = remove[j+1]-1;
               }
               ++k;
            }
         }

        ++seq;
      }

      assert(seq == state_length);
   
      qsort(state, state_length, sizeof(State_type), compare_state);

      biglist[lp] = (Occ_type **) malloc(save_length*sizeof(Occ_type *));
      reslist[lp] = (State_type *) malloc(save_length*sizeof(State_type));
      assert(biglist[lp] != NULL);
      assert(reslist[lp] != NULL);
                                    /* new we save the states in an big list */
      for(i = 0; i < save_length; ++i) {

         biglist[lp][i] = (Occ_type *) malloc(no_elec*sizeof(Occ_type));
         assert(biglist[lp][i] != NULL);

         for(j = 0; j < no_elec; ++j) {
            k = state[i].ind[j];
            assert(k>=0 && k < no_elec+nex);
            biglist[lp][i][j] = temp_occ[k];
                 /* lp - each B, i -  each many-body state, j- each electron */
         }
      }
      ++lp;                                                        /* next B */
   }                                               /* end of big loop over B */

 
                                 /* Now we run qmc.exe over each trial state */
   for(i = 0; i < save_length; ++i) {
      lp = 0;
      for(B = B0; B <= B1; B += dB) {
         occ = biglist[lp][i];
         etot = 0.0;
         L = 0;
         S = 0;
         for(j = 0; j < no_elec; ++j) {
            etot += occ[j].eng;
            L += occ[j].m;
            S += occ[j].s;
         }
         omega = sqrt(omega0*omega0+0.25*B*B);
         etot +=  sqrt(omega)*( - 0.25*modelK*S*S   
                       + 0.5*no_elec*(no_elec-1)*modelJ 
                       - 0.25*no_elec*(no_elec-2)*modelK );
         printf("B=%g, Eng=%g, L=%d, S=%d, occ=(", B, etot, L, S);
         for(k = 0; k < no_elec; ++k) {
            printf("%d %d %d", occ[k].n, occ[k].m, occ[k].s);
            if(k < no_elec-1) {
               printf(", ");
            }
         }

         fin = fopen(argv[2], "r");
         fout = fopen(infile, "w");
         assert(fin != NULL);
         assert(fout != NULL);

         line = 0;   
         while( fgets(str, 100, fin) != NULL && line < 13) {
            ++line;
            if(line == 4) {
               fprintf(fout, "%.15g\n", B);
            } else {
               fputs(str, fout);
            }
         }
         for(j = 0; j < no_elec; ++j) {
            fprintf(fout, "1 1.0 %d %d %d\n", occ[j].n, occ[j].m, occ[j].s);
         }
         fclose(fin);
         fclose(fout);

         tm = time(NULL);
         printf(") : at %s", ctime(&tm) );
         fflush(stdout);
         system(commd);
                            /* open file read in info */
         fp = fopen(resfile, "r");                      /* read the res file */
         assert(fp != NULL); 
         fscanf(fp, "%lf%lf%d%d", &Bin, &Ein, &Lin, &Sin);
         fclose(fp);
         assert(fabs(B-Bin) < 1.0e-6); /* make sure we read the correct file */
         assert(Lin == L);
         assert(Sin == S);

         system(delete);                                 /* delete res file */
      
         reslist[lp][i].Eng = Ein;
         reslist[lp][i].L = Lin;
         reslist[lp][i].S = Sin;

         ++lp;
      }
      assert(lp == lp_max);
                                   /* sorting reslist of same lp, and print */
      for(lp = 0; lp < lp_max; ++lp) {
         qsort(reslist[lp], i+1, sizeof(State_type), compare_state);
      }
      lp = 0;
      printf("seq=%d\n", i);
      printf("B        1st candidate        2nd candidate  ... \n");
      for(B = B0; B <= B1; B += dB) {
         printf("%-6g ", B);
         kmax = ((i+1)<=3)? (i+1) : 3;
         for(k = 0; k < kmax; ++k) {
            printf("%4d %4d %10g ", reslist[lp][k].L, reslist[lp][k].S,
                                    reslist[lp][k].Eng);
         }
         printf("\n");
         ++lp;
      }
      printf("\n");
      fflush(stdout);
      assert(lp == lp_max);
   }

   printf("Total %d many-body wavefunctions, finished!\n", seq);
   
   return 0;
}
