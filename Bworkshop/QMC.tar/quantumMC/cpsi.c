/* ----------------------------------------------------------------------------
      P S I ,  T R I A L   W A V E F U N C T I O N   C O M P U T A T I O N
   --------------------------------------------------------------------------*/
/* The generic aspect of the trial wavefunction should be handled in this file
   only. Information is exported by get_Psi_T(), get_velocity(), etc.
   The specific problem-dependent orbitals and Jastrow factors are defined 
   in model_*.c. This version cpsi handle the case when wavefuntion is complex.
*/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

#include "datatype.h"
#include "complex.h"

extern State St;                    /* state is declared in main() as global */
extern int n_Spin_Up;                              /* defined in model_dot.c */
                                                     /* globals to this file */
static complex *theta;   /* Slater determinant matrix theta(i,j)= phi_j(r_i) */
static complex *C;               /* C = theta^(-1), no_elec x no_elec matrix */
static int no_elec;                                   /* number of electrons */

                                   /* external functions used from inverse.c */
void lubksb(real a[], int n, int indx[], real b[]);
int LU_decomp(real a[], int n, int indx[]);
int get_index(int i, int j, int n);              /* matrix (i,j) -> 1d index */
void c_sherman_morrison(complex C[], int n, complex v[], complex u[], int l);
complex c_determinant(complex a[], int n);                   /* det(a) = |a| */
void print_c_matrix(const complex a[], int n);             /* complex matrix */

                                  /* external functions defined in model_*.c */
complex orbital(real *r, int j);                               /* theta_j(r) */
complex d_orbital(real *r, int j, int i);               /* d theta_j(r) dx_i */
complex laplacian_orbital(real *r, int j);               /* Del^2 theta_j(r) */
real jastrow(real R[]);                                    /* Jastrow factor */
real jastrow_fac_ratio(real R[], real R_i, int i);        /* exp(J(R')-J(R)) */
real d_jastrow(real R[], int i);                               /* d/x_i J(R) */
real laplacian_jastrow(real R[], int no_dof);                  /* Del^2 J(R) */
real potential(real R[], int no_dof);                                /* V(R) */
real get_B_field(void);                           /* export magnetic field B */

                                            /* function defined in this file */
void init_psi(void);                           /* allocate memory for C, etc */
void init_psi_inverse(real R[]);                           /* C = theta^(-1) */
void update_psi(real R[]);                                  /* compute theta */
void update_psi_inv(real R[], real r_new, int i);            /* C <= C + ... */
int check_inverse_matrix(real R[]);                    /* check theta C == 1 */
real get_psi_ratio(real R[], real R_i, int i);             /* Psi(R')/Psi(R) */
complex get_Psi_T(real R[]);                                     /* Psi_T(R) */
real get_velocity(real R[], int i);                   /* v_i = d/x_i J + ... */
complex get_velocity_0(real R[], int i);              /* v0_i = Tr(theta' C) */
real get_local_energy(real R[], int no_dof);      /* E_L(R) = Psi^(-1) H Psi */


/* Initialize and allocate memory, must be called before using any other
   functions.  We do not use 2D array; so the matrix is a 1D array,
   using get_index(i,j,size) to map from 2D index (i,j) to the 1D array.
   This makes it easier to call Fortran subroutine if needed.
*/
void init_psi(void)
{
   no_elec = St.N;
   theta = (complex *) malloc( no_elec*no_elec*sizeof(complex) );
   assert(theta != NULL);
   C = (complex *) malloc( no_elec*no_elec*sizeof(complex) );
   assert(C != NULL);
}
   

/* Global value for matrix theta is set.
   Each row corresponds to the same electrons (same coordinates), but
   different orbitals, i.e.,
           | theta_1(x1)   theta_2(x1)  ...  theta_n(x1) |
   theta = | theta_1(x2)   ...                           |
           | ...                                         |
           | theta_1(xn)                     theta_n(xn) |
   where xi = (x_j, y_j, a_j), but a_j is assumed 1 for j < n_Spin_Up,
   and -1 for j >= n_Spin_Up.

   The matrix is block diagonal consists of n_Spin_Up x n_Spin_Up
   and (no_elec-n_Spin_Up) x (no_elec-n_Spin_Up). Separate into
   two matrices theta_up, and theta_down will be more efficient.
 */
void update_psi(real R[])
{
   int i, j, offset; 
   complex zero;

   zero.Re = 0.0;
   zero.Im = 0.0;
                                               /* theta_{i,j} = theta_j(r_i) */
   for(i = 0; i < n_Spin_Up; ++i) {                        /* over electrons */
      offset = (St.D)*i;
      for(j = 0; j < n_Spin_Up; ++j) {                       /* over obitals */
         theta[get_index(i,j,no_elec)] = orbital(R+offset, j);
      }
      for(j = n_Spin_Up; j < no_elec; ++j) {
         theta[get_index(i,j,no_elec)] = zero;
      }
   }
   for(i = n_Spin_Up; i < no_elec; ++i) {    
      for(j = 0; j < n_Spin_Up; ++j) {   
         theta[get_index(i,j,no_elec)] = zero;
      }
      offset = (St.D)*i;
      for(j = n_Spin_Up; j < no_elec; ++j) {   
         theta[get_index(i,j,no_elec)] = orbital(R+offset, j);
      }
   }
   
}


/* Initialize C by theta inverse
   Since d = theta is complex, d*C = 1, is (in real component)
   [ d^R -d^I ] [C^R] = [1]
   [ d^I  d^R ] [C^I] = [0]
 */
void init_psi_inverse(real R[])
{
   real *mat;
   real *col;
   int *indx;
   int i, j, k, n2;

   update_psi(R);

   n2 = 2*no_elec;
   mat = (real *) malloc(n2*n2*sizeof(real));
   assert(mat != NULL);

   for(j = 0; j < no_elec; ++j) {
      for(i = 0; i < no_elec; ++i) {
         k = get_index(i,j,no_elec);
         mat[get_index(i,j,n2)] = theta[k].Re;
         mat[get_index(i+no_elec,j+no_elec,n2)] = theta[k].Re;
         mat[get_index(i,j+no_elec,n2)] = -theta[k].Im;
         mat[get_index(i+no_elec,j,n2)] = theta[k].Im;
      }
   }


   indx = (int *) malloc(n2*sizeof(int));
   assert(indx != NULL);
   col = (real *) malloc(n2*sizeof(real));
   assert(col != NULL);

   (void) LU_decomp(mat, n2, indx);                       /* parity not used */

   for(j = 0; j < no_elec; ++j) {                   /* solve Eq. A c_j = e_j */
      for(i = 0; i < n2; ++i) {
         col[i] = 0.0;
      }
      col[j] = 1.0;
      lubksb(mat, n2, indx, col);
      for(i = 0; i < no_elec; ++i) {
         k = get_index(i,j,no_elec);
         C[k].Re = col[i];
         C[k].Im = col[i+no_elec];
      }
   }

   free(col);
   free(indx);
   free(mat);
}


/* We assume R[] contains R old, i.e., R before move! 
   It changes C when R[i] is changed to r_new.
   We also maintain theta and C to be consistent (at all times).
 */
void update_psi_inv(real R[], real r_new, int i)
{
   int k, i_elec, offset;
   int kstart, kstop, zstart, zstop;
   real r_old;
   complex psi_old, psi_new;
   complex *u, *v, zero;

   zero.Re = 0.0;
   zero.Im = 0.0;

   i_elec = i/(St.D);                        /* this row in theta is changed */
   offset = i_elec * St.D;
   assert(offset <= i && i < offset + St.D);
   r_old = R[i];                                        /* remember original */
   R[i] = r_new;                                                /* R changed */

   u = (complex *) malloc( no_elec*sizeof(complex) );
   assert(u != NULL);
   v = (complex *) malloc( no_elec*sizeof(complex) );
   assert(v != NULL);

   if( i_elec < n_Spin_Up ) {
     kstart = 0;
     kstop = n_Spin_Up;
     zstart = n_Spin_Up;
     zstop = no_elec;
   } else {
     zstart = 0;
     zstop = n_Spin_Up;
     kstart = n_Spin_Up;
     kstop = no_elec;
   }
     
   for(k = kstart; k < kstop; ++k) {            /* split, because block diag */
      psi_old = theta[get_index(i_elec, k, no_elec)];
      psi_new = orbital(R+offset, k);
      theta[get_index(i_elec, k, no_elec)] = psi_new;
      v[k] = c_sub(psi_new, psi_old);
   }
   for(k = zstart; k < zstop; ++k) {
      v[k] = zero;
   }

   c_sherman_morrison(C, no_elec, v, u, i_elec);

   free(v);
   free(u);
   R[i] = r_old;                                               /* R restored */
   assert(fabs(R[i]-r_old)< EPSILON);                /* should not change R! */
}


/* Check that C is consistent with theta;
   that is theta C = 1 (complex matrices).
 */
int check_inverse_matrix(real R[])
{
   complex dot, z;
   real delta;
   int i, j, k;

#ifdef PRINT_A_LOT
   printf("R[]=");
   for(i = 0; i < St.no_dof; ++i) {
      printf("%g ", R[i]);
   }
   printf("\ntheta = \n");
   print_c_matrix(theta, no_elec);
   printf("C = \n");
   print_c_matrix(C, no_elec);
#endif

   delta = 0.0;
   for(i = 0; i < no_elec; ++i) {
      for(j = 0; j < no_elec; ++j) {
         dot.Re = 0.0;
         dot.Im = 0.0;
         for(k = 0; k < no_elec; ++k) {
            z = c_mul(theta[get_index(i,k,no_elec)], C[get_index(k,j,no_elec)]);
            dot = c_add(dot, z);
         }
         if (i==j) {
            dot.Re -= 1.0;
         }
         delta += c_abs(dot);
      }
   }
   delta /= (no_elec*no_elec);

#ifdef PRINT_A_LOT
   printf("theta*C = I, average different to identity per element is\n");
   printf("delta = %.15g\n", (double) delta);
#endif

   if(delta > EPSILON) {
      fprintf(stderr, "Warning: delta = %g, bigger than tolerance EPSILON\n",
                      (double) delta);
   }
   return (delta < EPSILON);
}


                     /* Evaluate trial wavefunction Psi_T(R), for debug only */
complex get_Psi_T(real R[])
{
   real j;
   complex d;

   update_psi(R);
   d = c_determinant(theta, no_elec);             /* value theta[] destroyed */
   j = jastrow(R);                           
   d.Re *= j;
   d.Im *= j;
   return d;
}


/* Compute ratio Psi(R')/Psi(R), assuming only the ith degree of freedom
   is moved. (NOT the i-th electron!)/  See Eq. (40) of Ceperley notes 1996.
   NB: there are two sets of indices, in function walk(), we run over 
   components of all electrons from 0 to no_dof.  However, for orbitals,
   and matrices, we count over electrons.  Thus conversion is needed.
   i -> j = i/St.D.
 */
real get_psi_ratio(real R[], real R_i, int i)
{
   int k, j, offset;
   int kstart, kstop;
   real rold;
   complex det_ratio, z, z1, z2;

   j = i/St.D;                                /* component to electron index */
   offset = j*St.D;                    /* start of j-th electron coordinates */
   det_ratio.Re = 0.0;
   det_ratio.Im = 0.0;
   rold = R[i];
   R[i] = R_i;                                               /* R set to new */
   if( j < n_Spin_Up ) {            /* because block diagonal in theta and C */
     kstart = 0;
     kstop = n_Spin_Up;
   } else {
     kstart = n_Spin_Up;
     kstop = no_elec;
   }
   for(k = kstart; k < kstop; ++k) {
      z1 = orbital(R+offset, k);
      z2 = C[get_index(k,j,no_elec)];
      z = c_mul(z1, z2);
      det_ratio = c_add(det_ratio, z);
   }
   R[i] = rold;                                                /* R restored */
   return jastrow_fac_ratio(R, R_i, i) * c_abs(det_ratio);
}


/* Compute velocity component v_i = dPsi/dx_i / Psi
   The velocity is given by
   v = Delta J + Tr { (Delta theta) C}
   where v is a D*N dimensional vector, Delta is gradient operator,
   C = theta(^-1) are matrices.  

   The velocity_0 version does not include the Jastrow factor term.
*/
real get_velocity(real R[], int i)
{
   real dj;
   complex z;

   z = get_velocity_0(R, i);
   dj = d_jastrow(R, i);
   return dj + z.Re;
}


complex get_velocity_0(real R[], int i)
{
   complex v_i, z1, z2, z;
   int k, j, offset, compon;
   int kstart, kstop;

   j = i/St.D;            /* from D*N-vector component i to electron index j */
   offset = j* St.D;    /* starting address of R of jth electron coordinates */
   compon = i - offset;                   /* which component of jth electron */
   assert(compon >= 0 && compon < St.D);
   
   v_i.Re = 0.0;
   v_i.Im = 0.0;
   if( j < n_Spin_Up ) {            /* because block diagonal in theta and C */
     kstart = 0;
     kstop = n_Spin_Up;
   } else {
     kstart = n_Spin_Up;
     kstop = no_elec;
   }
   for(k = kstart; k < kstop; ++k) {
      z1 = d_orbital(R+offset, k, compon);
      z2 = C[get_index(k,j,no_elec)];
      z = c_mul(z1, z2);
      v_i = c_add(v_i, z);
   }
   return v_i;
}


/* Local energy E_L(R) = Psi^(-1) H^ Psi
                       = -(1/2) Psi^(-1) Del^2 Psi + V(R);
   Psi^(-1) Del^2 Psi = Del^2 J(R) + Trace{(Del^2 theta) C} +v^2 -v0^2,
   where Del^2 is the Laplacian operator, C = theta^(-1) is no_elec by
   no_elec matrix, v is velocity magnitude squared, and v0 is v
   when J(R) sets to 0. 

   If Psi is complex, we take real part of the expression.  However, 
   for the problem in uniform magnetic field, there is a piece due to
   angular momentum.
 */
real get_local_energy(real R[], int no_dof)
{
   real lapj, v, v2, v0, dj, K, V, L, EL, B;
   real dA_x, dA_y, LA, dA_angle, Aa_dot;
   real x, y, da_x, da_y, da_angle, da2;
   int i, j, k, offset; 
   complex z, z1, z2, dd, vv;

   lapj = laplacian_jastrow(R, no_dof);                           /* Del^2 J */
   
   dd.Re = 0.0;
   dd.Im = 0.0;
   for(j = 0; j < no_elec; ++j) {                     /* Tr{(Del^2 theta) C} */
      offset = j*(St.D);
      for(k = 0; k < no_elec; ++k) {
         z1 = laplacian_orbital(R+offset, k);
         z2 = C[get_index(k,j,no_elec)];
         z = c_mul(z1,z2);
         dd = c_add(dd, z);
      }
   }

   vv.Re = 0.0;                                                /* v^2 - v0^2 */
   vv.Im = 0.0;
   L = 0.0;                                      /* -B/2 Sum_j d a/d angle_j */
   v2 = 0.0;                                                          /* v^2 */
   da2 = 0.0;                                                  /* | Del a|^2 */
   Aa_dot = 0.0;                                              /* v.Re . v.Im */
   LA = 0.0;                                   /* sum of (1/A) d A/d angla_j */
   for(i = 0; i < no_dof; ++i) {               /* used a^2-b^2 = (a+b)*(a-b) */
      dj = d_jastrow(R,i);
      z = get_velocity_0(R, i);
      v0 = z.Re;
      vv.Re += (dj + 2.0*v0)*dj;
      vv.Im += 2.0*dj*z.Im;
      v = dj + v0;
      v2 += v*v;
      da2 += z.Im * z.Im;
      Aa_dot += v*z.Im;
         
      if(i % 2 == 0 ) {          /* just to remember the imaginary part of v */
        da_x = z.Im;
        dA_x = v;
        x = R[i];
      } else {
        da_y = z.Im;
        dA_y = v;
        y = R[i];
        da_angle = -y*da_x + x*da_y;                      /* used chain rule */
        dA_angle = -y*dA_x + x*dA_y;                  /* A^(-1) d A /d angle */
        L += da_angle;                          /* sum of d phase /d angle_j */
        LA += dA_angle;
      }
   } 

   B = get_B_field();
   L *= 0.5*B;                                /* coefficient of sum da_angle */
   LA *= -0.5*B;                              /* coefficient of sum dA_angle */

   V = potential(R, no_dof);                        /* potential energy V(R) */
   
   K = -0.5*(lapj + dd.Re + vv.Re);                        /* kinetic energy */
   EL = K + V + L;
                   /* this is for check that <F^2>=<0.5*v^2>, for A, not Psi */
   St.F2 += 0.5*v2;                                  /* global variables set */
   St.K += K - 0.5*da2;           /* because (D^2 psi)/psi=(D^2 A)/A-(d a)^2 */
   St.Im += -0.5*dd.Im + LA;               /* imaginary part of local energy */
 
#ifdef PRINT_A_LOT
   printf("local energy EL is %g, K=%g, V=%g, L=%g, Aa_dot=%g, LA=%g, Im(dd)=%g\n", 
            EL, K, V, L, Aa_dot, LA, dd.Im);
#endif

   return EL;
}
