/* test the complex determinate
 */
#include <stdio.h>

#include "datatype.h"
#include "complex.h"

complex c_determinant(complex *a, int n);
int get_index(int i, int j, int n);

main()
{
   complex *a, det;
   double x, y;
   int i, j, n;

   printf("enter size n\n");
   scanf("%d", &n);

   a = (complex *) malloc(n*n*sizeof(complex));

   printf("enter pair as complex numbers for a n by n matrix\n");
   for(i = 0; i < n; ++i) {
      for(j = 0; j < n; ++j) {
         scanf("%lf%lf", &x, &y);
         a[get_index(i,j,n)].Re = x;
         a[get_index(i,j,n)].Im = y;
      }
   }

   det = c_determinant(a, n);

   printf("det(a) = (%g, %g)\n", det.Re, det.Im);
  
}
