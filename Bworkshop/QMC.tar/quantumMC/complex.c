#include "complex.h"

complex c_add(complex x, complex y)
{
   complex z;

   z.Re = x.Re + y.Re;
   z.Im = x.Im + y.Im;

   return z;
}


complex c_sub(complex x, complex y)
{
   complex z;

   z.Re = x.Re - y.Re;
   z.Im = x.Im - y.Im;

   return z;
}

complex c_mul(complex x, complex y)
{
   complex z;

   z.Re = x.Re * y.Re - x.Im * y.Im;
   z.Im = x.Im * y.Re + x.Re * y.Im;

   return z;
}

complex c_div(complex x, complex y)
{
   complex z;
   real mag;

   mag = y.Re*y.Re + y.Im*y.Im;
   z.Re = (x.Re * y.Re + x.Im * y.Im)/mag;
   z.Im = (x.Im * y.Re - x.Re * y.Im)/mag;

   return z;
}

complex c_conj(complex z)
{
   z.Im = - z.Im;

   return z;
}

real c_abs(complex z)
{
   real mag;
   mag = z.Re*z.Re + z.Im * z.Im;

   return sqrt(mag);
}
