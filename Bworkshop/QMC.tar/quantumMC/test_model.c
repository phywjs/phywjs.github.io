/* we test if theta is consistent with d theta/dx, and Del^2 theta.
   as well as the version for J, dJ/dx, and Del J.
   real wavefunction version.
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include "datatype.h"


real orbital(real *r, int j);                                  /* theta_j(r) */
real d_orbital(real *r, int j, int i);                  /* d theta_j(r) dx_i */
real laplacian_orbital(real *r, int j);                  /* Del^2 theta_j(r) */
real jastrow_fac_ratio(real R[], real R_i, int i);        /* exp(J(R')-J(R)) */
real d_jastrow(real R[], int i);                               /* d/x_i J(R) */
real laplacian_jastrow(real R[], int no_dof);                  /* Del^2 J(R) */
real potential(real R[], int no_dof);                                /* V(R) */

State St;

int main()
{
   int i, j, k;
   real h, f;
   real *r, *r1, *r2;

   printf("enter dimension D:\n");
   scanf("%d", &St.D);
   printf("enter number of electrons N:\n");
   scanf("%d", &St.N);
   St.no_dof = St.D * St.N;
   r = (real *) malloc( St.D*sizeof(real));
   r1 = (real *) malloc( St.D*sizeof(real));
   r2 = (real *) malloc( St.D*sizeof(real));
   assert(r != NULL);
   assert(r1 != NULL);
   assert(r2 != NULL);

   for(i = 0; i < St.D; ++i) {                            /* random position */
      r[i] = 0.5 - drand48();
   }

   printf("Compare analytic and numerical d theta_j(r)/dr\n");
   printf("\tanalytic ");
   for(j = 0; j < St.N; ++j) {
      printf("(");
      for(i = 0; i < St.D; ++i) {
         printf("%f ", (double) d_orbital(r,j,i));
      }
      printf("), ");
   }
   printf("\n\tnumeric  ");

   for(h = 0.01; h >= 0.0001; h *= 0.1) {
      for(j = 0; j < St.N; ++j) {
         printf("(");
         for(i = 0; i < St.D; ++i) {
            for(k = 0; k < St.D; ++k) {
               r1[k] = r[k];
               r2[k] = r[k];
            }
            r1[i] -= 0.5*h;
            r2[i] += 0.5*h;
            f = ( orbital(r2,j) - orbital(r1,j) )/h;   /* central difference */
            printf("%f ", (double) f);
         }
         printf("), ");
      }
      printf("\n\t         ");
   }

   printf("\nCompare analytic and numerical del^2 theta_j(r)\n");
   printf("\tanalytic ");
   for(j = 0; j < St.N; ++j) {
      printf("%f ", (double) laplacian_orbital(r,j));
   }
   printf("\n\tnumeric  ");

   for(h = 0.01; h >= 0.0001; h *= 0.1) {
      for(j = 0; j < St.N; ++j) {
         f = 0.0;
         for(i = 0; i < St.D; ++i) {
            for(k = 0; k < St.D; ++k) {
               r1[k] = r[k];
               r2[k] = r[k];
            }
            r1[i] -= h;
            r2[i] += h;
            f +=  orbital(r2,j) + orbital(r1,j) - 2.0*orbital(r,j);
         }
         f /= (h*h);
         printf("%f ", (double) f);
      }
      printf("\n\t         ");
   }

   return 0;
}
