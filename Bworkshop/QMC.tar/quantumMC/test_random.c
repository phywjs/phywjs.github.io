#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "datatype.h"

State St;

double drand_gaussian(void);
void srand64(long int seed);

main()
{
   double sum, sum2, x;
   int i, n;

   printf("enter n\n");
   scanf("%d", &n);

   srand64(time(NULL));
   sum = 0.0;
   sum2 = 0.0;
   for(i = 0; i < n; ++i) {
       x = drand_gaussian();
       sum += x;
       sum2 += x*x;
   }
   printf("mean = %f, var = %f\n", sum/n, sum2/n - (sum/n)*(sum/n));
   printf("expect mean 0, variance 1\n");
}
