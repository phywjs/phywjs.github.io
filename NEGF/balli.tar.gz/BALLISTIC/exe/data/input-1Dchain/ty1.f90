 program main
   use non_data_list
   implicit none
   integer::  i, j, k
   character*50::  tmpchar

   double precision::  k_left, k_center, k_right, t_non
   integer:: num_atom_center
   double precision::  vLC, vRC
   double precision:: onsite_R, onsite_L
   integer:: tn, tm
   double precision, allocatable::  center_k(:,:)
   integer::  num_length

   open(110, file='input.dat', status ='old')
    read(110, *) tmpchar
	read(110, *) k_left
    read(110, *) tmpchar
	read(110, *) k_right
	read(110, *) tmpchar
	read(110, *) k_center
	read(110, *) tmpchar
	read(110, *) t_non
   close(110)
   
   print*, k_left, k_center, k_right, t_non
   print*,  'Please input the number of the center part'
   read(*,*)  num_atom_center
   
   
   tn = 1;  onsite_L = 0.01d0
   onsite_R = 0.02d0
   ! left part
   open(120, file='lead_left.dat', status='unknown')
   tmpchar = '# left lead dynamic matrix'
   write(120,*) tmpchar

   tmpchar = '# H00 for the left lead'
   write(120,*) tmpchar
   write(120, *) tn, tn
   write(120,'(5f15.6)')  k_left * 2.0d0 + onsite_L

   tmpchar = '# H11 for the left lead'
   write(120,*) tmpchar
   write(120, *) tn, tn
   write(120,'(5f15.6)')  k_left * 2.0d0 + onsite_L

   tmpchar = '# H01 for the left lead'
   write(120,*) tmpchar
   write(120, *) tn, tn
   write(120,'(5f15.6)')  -1.0d0 * k_left 

   close(120)
   
  ! Right lead 

  open(120, file='lead_right.dat', status='unknown')
   tmpchar = '# right lead dynamic matrix'
   write(120,*) tmpchar

   tmpchar = '# H00 for the right lead'
   write(120,*) tmpchar
   write(120, *) tn, tn
   write(120,'(5f15.6)')  k_right * 2.0d0 + onsite_R

   tmpchar = '# H11 for the right lead'
   write(120,*) tmpchar
   write(120, *) tn, tn
   write(120,'(5f15.6)')  k_right * 2.0d0 + onsite_R

   tmpchar = '# # H01 for the right lead'
   write(120,*) tmpchar
   write(120, *) tn, tn
   write(120,'(5f15.6)')  -1.0d0 * k_right

   close(120)

   ! the center part
   
   allocate(center_k(1:num_atom_center, 1:num_atom_center))
   
   center_k(:,:) = 0.0d0
   do i = 1, num_atom_center
      if(i==1)then
        center_k(i,i) =    k_left + k_center
		center_k(i,i+1) =  -k_center
	  elseif(i==num_atom_center)then
        center_k(i,i) =    k_right + k_center
		center_k(i,i-1) =  -k_center
      else
	    center_k(i,i) = 2.0d0 * k_center
	    center_k(i,i-1) = -k_center
	    center_k(i,i+1) = -k_center
	  end if
   end do

   open(120, file='center.dat', status='unknown')
    tmpchar = '# the file gives the central dynamic matrix'
    write(120, *) tmpchar
	write(120, *) num_atom_center, num_atom_center
	do i=1, num_atom_center
      write(120, '(1000f15.6)') center_k(i, 1:num_atom_center)
 	end do ! i
   close(120)

   open(120, file='vlcr.dat', status='unknown')
   tmpchar = '# the interaction matrix   V_LC'
   write(120,*) tmpchar
   write(120,*) tn, tn
   write(120,'(5f15.6)') -k_left

   tmpchar = '# the interaction matrix   V_RC'
   write(120,*) tmpchar
   write(120,*) tn, tn
   write(120,'(5f15.6)') -k_right
   close(120)
   deallocate(center_k)

   ! gen nonlinear
   call gen_non_list( num_atom_center, num_length, t_non )
    open(112, file='non_center.dat', status='unknown')
	write(112,'(I10)')  num_length
    do i=1, num_length
	  write(112, '(3I6, 5f15.6)') non_t_list(i)%ti(1:3), non_t_list(i)%xforce
    end do ! i
	close(112)


   deallocate(non_t_list)

 end program main
