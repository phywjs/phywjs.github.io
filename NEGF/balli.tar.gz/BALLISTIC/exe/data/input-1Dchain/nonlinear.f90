!������������
! �����µ�����, �����������������ڵ�����
! t_(i,j,k) �±�ָ��, �������ά��,��ָ����
! �໥���õľ���Ԫ��ָ��
!---------------------------- 1 #
module newtype
!----------------------------
   type non_kmatrix      
      integer:: ti(1:3)  
      double precision::  xforce  ! ������  
   end type non_kmatrix
   
   type k_node
      integer:: i_j(1:2)
    ! double precision::  k(1:3,1:3)
	  double precision::  k
   end type k_node

   type mass_node
      integer::  i
	  double precision::  mass
   end type mass_node

end module newtype
!-----------------------------------------




!---- <<< nonlinear common list >>>>>  2 #
! ע�����ɼ�����ֻ�� non_t_list�� ������װ�ķ���
! �ȽϺá�
! �ó���������ǲ������������������С�
!------------------------------------------------
module  non_data_list
!------------------------------------------------
    use newtype
	implicit none
    type(non_kmatrix), allocatable:: non_t_list(:)
	double precision, private:: cof = 0.5d0
 
 !================   
  contains
 !================

  subroutine  gen_non_list( num_list, num_length, t_value )
    implicit none
    integer, intent(in)::  num_list
    double precision, intent(in)::   t_value
    integer, intent(out)::  num_length
  
! Local variables
    integer::  i, j, k,  ipcount
    double precision, allocatable:: tmp_array(:,:,:)
	integer::  error_id
    

! Body part
    
  allocate( tmp_array(1:num_list,1:num_list,1:num_list), stat =  error_id )
  if(error_id /= 0 )then
    print*,  'allocation error in nonlist'
	pause
  end if
  tmp_array(:,:,:) = 0.0d0

  !  calculate the coefficient
  do i=1, num_list-1
      j = i + 1

       tmp_array(i,i,i) = tmp_array(i,i,i) + cof * t_value
      
       tmp_array(i,i,j) = - cof * t_value
       tmp_array(i,j,i) = - cof * t_value
       tmp_array(j,i,i) = - cof * t_value

       tmp_array(i,j,j) =   cof * t_value
       tmp_array(j,i,j) =   cof * t_value
       tmp_array(j,j,i) =   cof * t_value

       tmp_array(j,j,j) = tmp_array(j,j,j) - cof * t_value
     
  end do  ! i
  

  ipcount = 0
  do i=1, num_list
     do j=1, num_list
	   do k=1, num_list
        if(abs(tmp_array(i,j,k))>1.0d-3)then
          ipcount = ipcount + 1
		end if
	   end do !k
	 end do ! j
  end do ! i
  
  num_length = ipcount
  
  allocate( non_t_list(1:ipcount), stat = error_id )
  if(error_id /= 0 )then
    print*,  'allocation error in nonlist'
	pause
  end if

  non_t_list(:)%ti(1) = -1
  non_t_list(:)%ti(2) = -1
  non_t_list(:)%ti(3) = -1
  non_t_list(:)%xforce  = 0.0d0
  
  ipcount = 1
  do i=1, num_list
     do j=1, num_list
	   do k=1, num_list
        if(abs(tmp_array(i,j,k))>1.0d-3)then
          non_t_list(ipcount)%ti(1) = i
		  non_t_list(ipcount)%ti(2) = j
		  non_t_list(ipcount)%ti(3) = k
          non_t_list(ipcount)%xforce  = tmp_array(i,j,k)
		  ipcount = ipcount + 1
		 end if
	   end do !k
	 end do ! j
  end do ! i
  deallocate(tmp_array)
 end subroutine gen_non_list

end module 
!---- common list -----