! generate 1D general alpha/beta FPU model and onsite
! center part potential energy = sum_{j} [V(u_j - u_{j+1}) + V_onsite(u_j)]
! where V(x) = 1/3 t x^3 + 1/4 t4 x^4, similarly for V_onsite
! 
! 16 Sep 2006, Jian-Sheng Wang
!
program main
   implicit none
   integer::  i, j
   character*70::  tmpchar

   double precision::  k_left, k_center, k_right, k_LC, k_RC
   double precision::  onsite_left, onsite_center, onsite_right
   double precision::  t, t_non, t4_non, onsite_t_non, onsite_t4_non
   integer:: num_atom_center
   integer:: tn, zero
   double precision, allocatable::  center_k(:,:)

   open(110, file='input.dat', status ='old')

   ! linear translation invariant part of constant (1/2)k(u_1 - u_2)^2
   read(110, *) tmpchar
   read(110, *) tmpchar
   read(110, *) k_left
   read(110, *) tmpchar
   read(110, *) k_right
   read(110, *) tmpchar
   read(110, *) k_center
   read(110, *) tmpchar
   read(110, *) k_LC
   read(110, *) tmpchar
   read(110, *) k_RC
   ! one-body on site terms of the form (1/2) k_onsite u_j^2
   read(110, *) tmpchar
   read(110, *) tmpchar
   read(110, *) onsite_left
   read(110, *) tmpchar
   read(110, *) onsite_right
   read(110, *) tmpchar
   read(110, *) onsite_center
   ! nonlinear translation invariant coupling, two-body terms 
   read(110, *) tmpchar
   read(110, *) tmpchar
   read(110, *) t_non
   read(110, *) tmpchar
   read(110, *) t4_non
   ! onsite nonlinear coupling, two-body terms 
   read(110, *) tmpchar
   read(110, *) tmpchar
   read(110, *) onsite_t_non
   read(110, *) tmpchar
   read(110, *) onsite_t4_non

   close(110)
   
   print *, 'k_left=', k_left, ' k_right=', k_right, 'k_center=', k_center
   print *, 'k_LC=', k_LC, ' k_RC=', k_RC
   print *, 'onsite_left=', onsite_left, ' onsite_right=', onsite_right, &
            'onsite_center=', onsite_center
   print *, 't_non=', t_non, 't4_non=', t4_non
   print *, 'onsite_t_non=', onsite_t_non, ' nonsite_t4_non=', onsite_t4_non

   print*,  'enter the number of atoms of the center part'
   read(*,*)  num_atom_center
   
   
   tn = 1
   ! left part
   open(120, file='lead_left.dat', status='unknown')
   tmpchar = '# left lead dynamic matrix'
   write(120,*) tmpchar

   tmpchar = '# H00 for the left lead'
   write(120,*) tmpchar
   write(120, *) tn, tn
   write(120,'(5f15.6)')  k_left * 2.0d0 + onsite_left

   tmpchar = '# H11 for the left lead'
   write(120,*) tmpchar
   write(120, *) tn, tn
   write(120,'(5f15.6)')  k_left + k_LC + onsite_left

   tmpchar = '# H01 for the left lead'
   write(120,*) tmpchar
   write(120, *) tn, tn
   write(120,'(5f15.6)')  -1.0d0 * k_left 

   close(120)
   
  ! Right lead 

  open(120, file='lead_right.dat', status='unknown')
   tmpchar = '# right lead dynamic matrix'
   write(120,*) tmpchar

   tmpchar = '# H00 for the right lead'
   write(120,*) tmpchar
   write(120, *) tn, tn
   write(120,'(5f15.6)')  k_right + k_RC + onsite_right

   tmpchar = '# H11 for the right lead'
   write(120,*) tmpchar
   write(120, *) tn, tn
   write(120,'(5f15.6)')  k_right * 2.0d0 + onsite_right

   tmpchar = '# # H01 for the right lead'
   write(120,*) tmpchar
   write(120, *) tn, tn
   write(120,'(5f15.6)')  -1.0d0 * k_right

   close(120)

   ! the center part
   
   allocate(center_k(1:num_atom_center, 1:num_atom_center))
   
   center_k(:,:) = 0.0d0
   center_k(1,1) = k_LC
   ! this works even we have 1 atom in the center
   center_k(num_atom_center, num_atom_center) = &
      center_k(num_atom_center, num_atom_center) + k_RC
   ! each bond contribute one to the left site, one to right site
   do i = 1, num_atom_center-1
      center_k(i,i) = center_k(i,i) + k_center
      center_k(i+1,i+1) = center_k(i+1,i+1) + k_center
      center_k(i,i+1) = - k_center
      center_k(i+1,i) = - k_center
   end do
   ! add onsite
   do i = 1, num_atom_center
      center_k(i,i) = center_k(i,i) + onsite_center
   end do

   open(120, file='center.dat', status='unknown')
   tmpchar = '# the file gives the central dynamic matrix'
   write(120, *) tmpchar
   write(120, *) num_atom_center, num_atom_center
   do i=1, num_atom_center
      write(120, '(1000f15.6)') center_k(i, 1:num_atom_center)
   end do ! i
   close(120)
   deallocate(center_k)

   open(120, file='vlcr.dat', status='unknown')
   tmpchar = '# the interaction matrix   V_LC'
   write(120,*) tmpchar
   write(120,*) tn, tn
   write(120,'(5f15.6)') -k_LC

   tmpchar = '# the interaction matrix   V_RC'
   write(120,*) tmpchar
   write(120,*) tn, tn
   write(120,'(5f15.6)') -k_RC
   close(120)

   ! gen nonlinear cubic terms

    open(121, file='non_center.dat', status='unknown')

    if( (t_non+onsite_t_non) .EQ. 0.0d0) then
       write(121, '(I6)') 0
    else
    t = t_non
    if(num_atom_center == 1) t = 0.0d0
    if(t_non == 0.0d0) then
      zero = 0
    else 
      zero = 1
    end if

    write(121, '(I6)') zero*(num_atom_center-1)*6+num_atom_center
    do i = 1, num_atom_center
       j = i + 1
       if(i == 1) then
          write(121, '(3I6, f15.6)') i, i, i, t + onsite_t_non
       end if
       if (i < num_atom_center .AND. zero == 1) then

          write(121, '(3I6, f15.6)') i, i, j, -t
          write(121, '(3I6, f15.6)') i, j, i, -t
          write(121, '(3I6, f15.6)') j, i, i, -t

          write(121, '(3I6, f15.6)') j, j, i, t
          write(121, '(3I6, f15.6)') j, i, j, t
          write(121, '(3I6, f15.6)') i, j, j, t
       end if

       if(j < num_atom_center) then  ! diagonal term
          write(121, '(3I6, f15.6)') j, j, j, onsite_t_non
       else if(j == num_atom_center) then 
          write(121, '(3I6, f15.6)') j, j, j, -t + onsite_t_non
       end if
    end do

    end if

   close(121)


   ! T_{ijkl} terms
   open(113, file='non_center_T4.dat', status='unknown')

    if( (t4_non + onsite_t4_non) .EQ. 0.0d0) then
       write(113, '(I6)') 0
    else
    t = t4_non
    if(num_atom_center == 1) t = 0.0d0
    if(t4_non == 0.0d0) then
      zero = 0
    else 
      zero = 1
    end if

    write(113, '(I6)') zero*(num_atom_center-1)*14+num_atom_center
    do i = 1, num_atom_center
       j = i + 1
       if(i == 1) then
          write(113, '(4I6, f15.6)') i, i, i, i, t + onsite_t4_non
       end if
       if (i < num_atom_center .AND. zero == 1) then

          write(113, '(4I6, f15.6)') i, i, i, j, -t
          write(113, '(4I6, f15.6)') i, i, j, i, -t
          write(113, '(4I6, f15.6)') i, j, i, i, -t
          write(113, '(4I6, f15.6)') j, i, i, i, -t

          write(113, '(4I6, f15.6)') i, i, j, j, t
          write(113, '(4I6, f15.6)') j, j, i, i, t
          write(113, '(4I6, f15.6)') i, j, j, i, t
          write(113, '(4I6, f15.6)') j, i, i, j, t
          write(113, '(4I6, f15.6)') j, i, j, i, t
          write(113, '(4I6, f15.6)') i, j, i, j, t

          write(113, '(4I6, f15.6)') j, j, j, i, -t
          write(113, '(4I6, f15.6)') j, j, i, j, -t
          write(113, '(4I6, f15.6)') j, i, j, j, -t
          write(113, '(4I6, f15.6)') i, j, j, j, -t
       end if

       if(j < num_atom_center) then
          write(113, '(4I6, f15.6)') j, j, j, j, 2.0d0*t + onsite_t4_non
       else if(j == num_atom_center) then 
          write(113, '(4I6, f15.6)') j, j, j, j, t + onsite_t4_non
       end if
    end do

   end if

   close(113)

 end program main
