!*****************************************************************************
! (ballistic thermal conductance by nonequilibrium Green's function method)
! ���ļ����������ļ�
!*****************************************************************************
! Wang Jian, phcwj@hotmail.com
! revised for ballistic only by Wang Jian-Sheng, phywjs@nus.edu.sg
! generalized eigenvalue routines by Lu Jingtao, phyljt@nus.edu.sg
!
! 24 November 2007

program main

! �ӳ���ӿ�˵�� (interf.f90 gives the interfaces)
   use  interface_commn
   use  sub2_interface   ! for reverse_green
   use  distribution_interface
!----------------------------------------------
! ���� Model �������� (all defined in module.f90)
   use  comm_dynamic  ! k00, k11, k01 (left/right), k0_center
   use  comm_vlcr     ! V^{LC}, V^{RC}
   use  comm_general  ! delta and other control parameters
                         
   use  array_in_main ! matrices, gLR, gRR, left_sen, right_sen 
                      ! g0r_center
   use  data_array    ! trans_list, length_array and omega_interval
   use  green_shape   ! shape of gr and self energy

   use  mpi           ! MPI library
   use  MPI_data      ! myid, etc, i_begin/i_end
!-----------------------------------------------

   implicit none
   double precision, parameter:: cof3 = 635.5d0 ! in units nano Watts/Kelvin
   double precision, parameter:: M_PI = 3.141592653589793d0

   !***************** һЩ������������� (except array_in_main)**************
   double precision::  T, T_increment         ! varying T loop
   double precision::  kappa, kappa_tot       ! conductance
   double precision:: cpu_time_0, cpu_time
   double complex::  omega, tz
   integer:: i, n
  
! ***************** �����������ļ��� *********************
   character*12:: filename
  
   
   call MPI_INIT(ierr)
   call MPI_COMM_RANK(MPI_COMM_WORLD, myid, ierr)
   call MPI_COMM_SIZE(MPI_COMM_WORLD, numprocs, ierr)
   
   print *, 'run at process ', myid

   if(myid .EQ. 0) then
      cpu_time_0 = MPI_WTIME()
   end if

! MPI: process 0 will read and broadcast to others
! this is done inside the subroutines

! ************  �����ʼ���� *********************************
   call  input_run_parameter
   
!  <<<<<<<<<  �������ļ�������صĲ��� >>>>>>>>>>>>
   ! input the force constant for the lead k00,11,01
   call  input_lead
   
   ! input the force constant for the center Kc
   call  input_center
   
   ! input the cross-terms for the dynamic matrix 
   call  input_vlcr
   
   call jobrange(myid, length_array, i_begin, i_end)  ! i_begin/end in MPI_data

   ! Transfer the shape of green function for the future use
   call  tran_green_shape

   allocate(trans_list(i_begin:i_end))


   ! each process do an interval of frequencies of its share
   do i = i_begin, i_end

      omega = cmplx(i*omega_interval, delta)

      call sfg_solve(gLR, omega, k00_left, k11_left, k01_left)
      call reverse_green(gLR)  ! ��� surface green function ���뵹һ��
                               ! ��� surface Green function left lead
      call sfg_solve(gRR, omega, k00_right, k11_right, k01_right)
                            ! ���surface Green function right lead
      ! ���� Lead ���� Retarded ���� -------------------------------
      ! ע�����ܵĽ������ left_sen �� right_sen
      ! �ر�ע�⣺ left_sen �� right_sen ������Ȳ��� g0_center ��
      ! ����Ĺ�ʽΪ self_L = V_CL * g_L * V_LC
      !              self_R = V_CR * g_R * V_RC
      call selengy(gLR, vlc, left_sen )  ! ���� self-energy for the lead left
      call selengy(gRR, vrc, right_sen ) ! ���� self-energy for the lead right

      ! solve Dyson equation by
      ! Gn^r = (w^2 - k_c - Sig^r_L - Sig^r_R)^{-1}
      call cal_g0_center(left_sen, right_sen, omega, g0r_center)

      ! T[w] by Caroli formula
      call cal_tranmission(left_sen, right_sen, g0r_center, tz)
      trans_list(i) = tz
   end do ! i

   
   filename ='caroli_trans'
   call output_green(140, filename, trans_list, 1, 1)

   ! output the thermal conductance value
   n = size(k0_center, 1)
   if(myid == 0) then   ! write header for kappa file
      open(13, file='data/output/kappa.dat', status='unknown')
      write(13, '(A, I4)') '# conductance, L=', n
      write(13, '(A, I6)') '# length_array=', length_array
      write(13, '(A,F8.2,A,F8.6)') '# omega_max=', omega_max, ' delta=', delta
      write(13, '(A)') '# temperature (Kelvin)   kappa (nWatts/K)   caroli_kappa '
   end if  ! myid==0

   T = T_begin
   if (tpts == 1) then
      T_increment = T_end + 10.0
   else 
      T_increment = (T_end - T_begin)/(tpts-1)
   end if

99 continue

   kappa = 0.0
   kappa_tot = 0.0
   do i = i_begin, i_end
      omega = cmplx(i*omega_interval, delta)
      tz = trans_list(i)
      kappa = kappa + real(tz)* omega_dfB_distribution(omega, T)
   end do ! i for kappa

   call MPI_ALLREDUCE(kappa, kappa_tot, 1, MPI_DOUBLE_PRECISION, MPI_SUM, MPI_COMM_WORLD, ierr)

   if(myid == 0) then
      ! change units to nW and other factor
      kappa_tot = cof3*kappa_tot*omega_interval/(2.0*M_PI)
      write(13, '(F10.4, F12.7)' ) T, kappa_tot
   end if

   T = T + T_increment
   ! being able to go forward as well as backward
   if ((T <= T_end) .AND. (T_begin <T_end) .OR. & 
       (T >= T_end) .AND. (T_begin > T_end) ) goto 99

   if(myid == 0) then
      close(13)
      cpu_time = MPI_WTIME()
      cpu_time = cpu_time - cpu_time_0
      write(*, '(A, G12.6, A)') '    cpu_time= ', cpu_time, ' sec'
   end if


! <<<<  �ͷ���������� >>>>>
   deallocate(gLR, gRR, left_sen, right_sen, g0r_center,trans_list)
   deallocate(k00_left, k00_right, k11_left, k11_right)
   deallocate(k01_left, k01_right, k0_center, vlc, vrc)


   call MPI_FINALIZE(ierr)


   contains
   ! internal functions

   subroutine print_matrix(A)
      double complex A(:,:)
      integer :: i
       
      do i = 1, size(A,1)
         write(*, '(100(G11.3))') A(i, :)
      end do

   end subroutine print_matrix


   ! parallelized output, be careful about variables used from main 
   subroutine output_green(channel, filename, list_data, stride, index)
      implicit none

      ! the units without cof5 multiplying omega is 0.776 x 10^{14} sec^{-1}
      ! omega*cof5 will give frequency in units of (cm)^{-1}.
      ! double precision, parameter:: cof5 = 412.01d0
      double precision, parameter:: cof5 = 1.0d0

      integer, intent(in):: channel, stride, index
      character(*), intent(in):: filename
      double complex, intent(in):: list_data(:)
     
      integer:: i, p, dis, i_beg, i_en, count
      integer, allocatable:: rev_counts(:), displs(:)
      double complex:: z 
      double complex, allocatable:: send_buf(:), recv_buf(:)
      double precision:: w
      ! mfloop, num(), length_array & omega_interval are globals from main.

      if(index <= 0) return   ! this turn off printing

      allocate(rev_counts(0:numprocs-1)) 
      allocate(displs(0:numprocs-1)) 
      allocate(send_buf(1:(i_end-i_begin+1)))
      if(myid .EQ. 0) then
         allocate(recv_buf(1:length_array))
      end if

      ! to figure out where to put the received data
      dis = 0
      do p = 0, numprocs-1
         call jobrange(p, length_array, i_beg, i_en)
         rev_counts(p) = i_en - i_beg + 1
         displs(p) = dis
         dis = dis + rev_counts(p)
      end do
      if(dis .NE. length_array) then
         print *, 'total received count is not length_array'
         stop
      end if

      do i = i_begin, i_end
         send_buf(i-i_begin+1) = list_data((i-i_begin)*stride + index)
      end do
      count = i_end - i_begin + 1
      call MPI_GATHERV(send_buf, count, MPI_DOUBLE_COMPLEX, &
              recv_buf, rev_counts, displs, MPI_DOUBLE_COMPLEX, 0, MPI_COMM_WORLD, ierr)

      if(myid .EQ. 0) then
         open(channel, file='data/output/'//trim(filename)//'.dat', status='unknown')
         do i = 1, length_array
            w  = i*omega_interval  * cof5
            z = recv_buf(i)
            ! write(channel, *) w, real(z), aimag(z)
            write(channel, *) w, real(z)
         end do
         close(channel)
      end if

      deallocate(rev_counts)
      deallocate(displs)
      deallocate(send_buf)
      if(myid .EQ. 0) then
         deallocate(recv_buf)
      end if

   end subroutine output_green

end program main
