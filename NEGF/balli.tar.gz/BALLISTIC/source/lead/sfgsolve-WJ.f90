!*******************************************************
! this subroutine is to compute the surface green function
! ���� surface green function
! �ó������һά����Ѿ�������.���Ƕ�����ά������д�����
! ������ά�����Ҫ���Ե��ص����������棬�Լ��������һ���֡�
! �����ⲿ�ֵ��㷨���ɼ���صĲο����ס� (e.g., H. Kino 2005)
! �ӿڲ���˵����
!    gR(:,:)------- �������� Surface green function
!    omega -------- Ƶ�ʣ�ע�ⲻ��Ҫƽ����ƽ����Ϊ����ֵ
!                   �ڱ��ӳ����н��еġ�
!    k00(:,:) -----  ����� ����������������ʽ��
!    k11(:,:) -----  �����  | k00, k01, ... |
!    k01(:,:) -----  �����  | k10, k11, ... | 
!    
! See also M. P. Lopez Sancho, J. M. Lopez Sancho, and J. Rubio,
! J. Phys. F: Met. Phys. 15, 851 (1985) for the algorithm.
!********************************************************

!--------------------------------------------------------
subroutine  sfg_solve(gR, omega, h00, h11, h01)
!--------------------------------------------------------
   use sub_interface
   implicit none
   
   double complex, intent(out)::  gR(:,:)
   double complex, intent(in) ::  omega 
   double complex, intent(in)::  h00(:,:), h11(:,:), h01(:,:)
   
   double complex, allocatable:: identity(:,:)
   double complex, allocatable:: eis(:,:),  ei(:,:), alphai(:,:),   betai(:,:)
   double complex, allocatable:: eis1(:,:), ei1(:,:), alphai1(:,:), betai1(:,:)
   double complex, allocatable:: inv_ei(:,:),  inv2_ei(:,:), tmp1(:,:), tmp2(:,:)
   double precision::  x, y
   double complex::  tx
   double complex::  square_omega
      
   integer::  i
   integer::  Ldim_num(1:2)
   integer::  h0_dim(1:2), tn, tm
   integer::  nn
   integer::  max_times

   integer::  error_id

   double complex:: a, lambda_1, lambda_2, lambda, g00
         
   h0_dim = shape(h00)   
   tn = h0_dim(1)
   tm = h0_dim(2)

   square_omega = omega * omega

!  exact result in 1D
   if(tn == 1 .AND. tm == 1) then
      a = (square_omega - h11(1,1))/h01(1,1)
      lambda_1 = cmplx(0.5d0, 0.0d0) * ( a + sqrt(a*a-cmplx(4.0d0, 0.0d0)) )
      lambda_2 = cmplx(0.5d0, 0.0d0) * ( a - sqrt(a*a-cmplx(4.0d0, 0.0d0)) )
      if(abs(lambda_1) .LT. 1.0) then 
         lambda = lambda_1
      else
         lambda = lambda_2
      end if
      g00 = cmplx(1.0d0,0.0d0)/(h11(1,1)-h00(1,1)+h01(1,1)/lambda)
      ! chop the answer
      x = real(g00)
      if (abs(x) < 1.0e-5) x = 0.0d0
      y = aimag(g00)
      if (abs(y) < 1.0e-5) y = 0.0d0
      gR(1,1) = cmplx(x, y)
      return
   end if

   allocate(identity(1:tn, 1:tm))

   identity(:,:) = cmplx(0.0d0, 0.0d0)
   do i=1, tn
      identity(i,i) = square_omega
   end do

   allocate(eis(tn, tm),   ei(tn, tm), alphai(tn, tm),   betai(tn, tm))
   allocate(eis1(tn, tm),  ei1(tn, tm), alphai1(tn, tm),   betai1(tn, tm))
   allocate(inv_ei(tn, tm), inv2_ei(tn, tm), tmp1(tn, tm), tmp2(tn, tm))

   ! set initial values
   eis(:,:) = h00(:,:)
   ei(:,:)  = h11(:,:)
   alphai(:,:) = h01(:,:)
   betai(:,:) = conjg(transpose(h01(:,:)))

   nn = tn  

   inv_ei(:,:) = identity(:,:) - ei(:,:)

   if( nn==1 ) then
      tx = inv_ei(1,1)
      inv2_ei(1,1) = 1.0d0/tx ! ���������һά������Ҫ����, ֻ�ǵ�����
   else 
!-------------------------------------------------------------
      CALL  inverse_zmatrix(inv_ei, inv2_ei, error_id)
!                   if( abs(error_id) > 0 )then  ! �������ʾ����
!                         result_list(1) = real(omega)
!                         result_list(2) = error_id
!             call wr_file(file_name, result_list )
!                   end if
!-------------------------------------------------------------
   end if

   max_times = 200
   do i=1,  max_times
      
      tmp1(:,:) = matmul(alphai, inv2_ei)
      tmp2(:,:) = matmul(tmp1, betai)
      eis1(:,:) = eis(:,:) + tmp2(:,:)

      ! as soon as tmp2 is small enough, we consider iteration converged
      if(maxval(abs(tmp2(:,:))) < 1.0d-10) then
         ! print *,  'iteration converged, i=', i
         exit
      endif
      
      tmp1(:,:) = matmul(betai, inv2_ei)
      tmp1(:,:) = matmul(tmp1, alphai)
      ei1(:,:) = ei(:,:) + tmp1(:,:) + tmp2(:,:)

      tmp1(:,:) =  matmul(alphai, inv2_ei)
      alphai1(:,:) = matmul(tmp1, alphai)

      tmp1(:,:) = matmul(betai, inv2_ei)
      betai1(:,:) = matmul(tmp1, betai)

      eis(:,:) = eis1(:,:)
      ei(:,:)  = ei1(:,:)
      alphai(:,:) = alphai1(:,:)
      betai(:,:) = betai1(:,:)
          
      inv_ei(:,:) = identity(:,:) - ei(:,:)

! No real need to check this
!      if( nn==1 ) then
!         ty = abs(inv_ei(1,1))
!         if(ty<1.0d-6)then
!            exit
!         end if
!         inv2_ei(1,1) = 1.0d0/inv_ei(1,1)
!      else
!         cpm(:,:) = abs( inv_ei(:,:) ) 
!         ty = maxval(cpm)
!         if(abs(ty)<1.0d-4)then
!            ! print*, 'i=', i
!            exit
!         end if
!-------------------------------------------------------------
         CALL  inverse_zmatrix(inv_ei, inv2_ei, error_id)
!                 if( abs(error_id) > 0 )then  ! �������ʾ����
!                     result_list(1) = real(omega)
!                     result_list(2) = error_id
!             call wr_file(file_name, result_list )
!                 end if
!--------------------------------------------------------------
!      end if

   end do 

   inv_ei(:,:) =  identity(:,:) - eis(:,:)
   if( nn==1 ) then
      inv2_ei(1,1) = 1.0d0 / inv_ei(1,1)
   else if(nn>1) then
!-------------------------------------------------------------
      CALL  inverse_zmatrix(inv_ei, inv2_ei, error_id)
!         if( abs(error_id) > 0 )then  ! �������ʾ����
!             result_list(1) = real(omega)
!             result_list(2) = error_id
!         call wr_file(file_name, result_list )
!         end if
!--------------------------------------------------------------
   end if

   Ldim_num = shape(gR)
   tn = Ldim_num(1)
   tm = Ldim_num(2)

   gR(1:tn,1:tm) = inv2_ei(1:tn,1:tm)
   
   deallocate(identity)
   deallocate(eis,   ei,  alphai,  betai)
   deallocate(eis1,  ei1, alphai1, betai1, inv_ei, inv2_ei, tmp1, tmp2)

end subroutine sfg_solve


! double complex, allocatable::   k00_left(:,:),  k00_right(:,:)
! double complex, allocatable::   k11_left(:,:),  k11_right(:,:)
! double complex, allocatable::   k01_left(:,:),  k01_right(:,:)
! <<<<<  �������ߵ� surface green function ��Ҫ��תһ��    >>>>>>
subroutine  reverse_green(input_matrix)
   implicit none
   double complex, intent(inout):: input_matrix(:,:)

   ! Local variables
   double complex, dimension(:,:), allocatable::   tmp_matrix
   integer::  num_shape(1:2),  num_row,  num_col
   integer::  i, j, ii, jj, error_id

   num_shape(:) = shape(input_matrix)

   num_row = num_shape(1);  num_col = num_shape(2)
   if( num_row .ne. num_col) then
     print *, 'shape error in surface green function in reverse_green'
     print *, 'row=', num_row, ' col=', num_col
     stop
   end if

   allocate(tmp_matrix(1:num_row, 1:num_col), stat = error_id )
   if(error_id .ne. 0 )then
     print*, 'memory allocation error in reverse_green'
     stop
   end if

   do i=1, num_row
      do j=1, num_row
         ii = num_row - i + 1
	 jj = num_row - j + 1
	 tmp_matrix(ii,jj) = input_matrix(i,j)
      end do ! j
   end do ! i
 
   input_matrix(:,:) = tmp_matrix(:,:)

   deallocate(tmp_matrix)
    
end subroutine 
