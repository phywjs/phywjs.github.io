! ���� Lead ������
! that is, compute V^{CL} g^L V^{LC}
! The size of g^L and selfz are usually different, need special care here.
!
subroutine  selengy(g0, vlc, selfz )
!##################################
   implicit none
    
   double complex, intent(in)::  g0(:,:), vlc(:,:)
   double complex, intent(out):: selfz(:,:)

   integer::  tn, tm, tnn, tmm
   integer::  num_array(1:2)
   double complex, allocatable::  tmp_vcl(:,:), tmp_pro(:,:)
    
   ! �ҳ�transpose����
   num_array(1:2) = shape(vlc)
   tn = num_array(1)
   tm = num_array(2)
   allocate(tmp_vcl(1:tm,1:tn))

   allocate(tmp_pro(1:tm, 1:tn) )
       
   num_array(1:2) = shape(g0)
   tnn = num_array(1)
   tmm = num_array(2)
   if(tnn /= tmm .or. tnn /= tn )then
      print*, 'shape error in selfenergy '
   end if
    
   tmp_vcl(:,:) = transpose(vlc(:,:))
   tmp_pro(:,:) = matmul(tmp_vcl, g0)
   selfz(:,:)   = matmul(tmp_pro, vlc)

   deallocate(tmp_vcl, tmp_pro)

end subroutine selengy
