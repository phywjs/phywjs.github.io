!---------------------------------------------------------------------------
! f(w,T), Bose-Einstein distribution function
! Use a complex omega to avoid singularity at omega = 0.
double precision function  fb_distribution(omega, temperature)
   implicit none
   double complex, intent(in):: omega
   double precision, intent(in):: temperature
   double precision, parameter::  cof = 592.467d0

   ! Local variables
   double complex:: tz, one, f

   one = cmplx(1.0d0, 0.0d0)
   tz = cof * omega / temperature
   if( real(tz) < 12.0d0) then
      f = one/(exp(tz) - one)
   else
      f = exp(-tz)
   end if
   fb_distribution = real(f)

end function fb_distribution


! inverse of f, 1/f = exp(cof*w/T) - 1
! cut off smoothly the large argument divergence
double precision function  inv_distribution(omega, temperature)
   implicit none
   double complex, intent(in):: omega
   double precision, intent(in):: temperature
   double precision, parameter::  cof = 592.467d0

   ! Local variables
   double precision:: x, x0

   x = cof * real(omega) / temperature
   x0 = 12.0d0
   if(x < x0) then
      inv_distribution = exp(x) - 1.0d0
   else
      inv_distribution = exp(x - (x-x0)**2) - exp(-(x-x0)**2)
   end if

end function inv_distribution


! df/dT, derivative of Bose-Einstein distribution function
double precision function d_fb_distribution(omega, T)
   implicit none
   double complex, intent(in):: omega
   double precision, intent(in):: T
   double precision:: x, y
   double precision, parameter::  cof = 592.467d0

   x = cof*real(omega)/T

   if(abs(x) < 1.0d-7) then
      y = 0.0
   else if(abs(x) < 0.0001) then
      y = (1.0 + 0.5*x + x*x/6.0 + x*x*x/24.0)
      y = exp(x)/( x * y * y * T)
   else if (x < 15.0) then
      y = (x/T)*exp(x)/(exp(x)-1.0d0)**2
   else 
      y = (x/T)*exp(-x)
   end if

   d_fb_distribution = y

end function d_fb_distribution


! omega * df/dT, derivative of Bose-Einstein distribution function
! multiplied by omega
double precision function omega_dfb_distribution(omega, T)
   implicit none
   double complex, intent(in):: omega
   double precision, intent(in):: T
   double precision:: x, y
   double precision, parameter::  cof = 592.467d0

   x = cof*real(omega)/T

   if(abs(x) < 0.001) then
      y = (1.0 + 0.5*x + x*x/6.0 + x*x*x/24.0)
      y = exp(x)/(cof * y * y)
   else if (x < 15.0) then
      y = (x*x/cof)*exp(x)/(exp(x)-1.0d0)**2
   else
      y = exp(-x) * x**2/cof
   end if

   omega_dfb_distribution = y

end function omega_dfb_distribution


! this is f/(df/dT) = dT / d log f
! this function is not well-behaved at x -> -inf
! so we cut them off with a gaussian
double precision function  dlog_fb_distribution(omega, temperature)
   implicit none
   double complex, intent(in):: omega
   double precision, intent(in):: temperature
   double precision, parameter::  cof = 592.467d0

   ! Local variables
   double precision:: x, y, x0

   x = cof * real(omega)/temperature
   x0 = -8.0

   if(abs(x) < 0.001) then 
      y = (1.0 - 0.5*x + x*x/6.0 - x*x*x/24.0)*temperature
   else if (x > x0) then 
      y = temperature*(1-exp(-x))/x
   else 
      y = temperature*(exp(-(x-x0)**2)-exp(-x-(x-x0)**2))/x
   end if

   dlog_fb_distribution = y

end function dlog_fb_distribution


! this is 1/(df/dT) function
! this function is not well-behaved at x -> +/-inf
! we cut them off
double precision function  inv_dfb_distribution(omega, temperature)
   implicit none
   double complex, intent(in):: omega
   double precision, intent(in):: temperature
   double precision, parameter::  cof = 592.467d0

   ! Local variables
   double precision:: x, y, x0

   x = cof * real(omega)/temperature
   x0 = 8.0

   if(abs(x) < 0.001) then 
      y = (1.0 - 0.5*x + x*x/6.0 - x*x*x/24.0)
      y = temperature * x * exp(x) * y * y
   else if (abs(x) < x0) then
      y = temperature*((exp(x)-1.0)**2)/(x * exp(x))
   else if (x < -x0) then
      y = temperature*((exp(x)-1.0)**2)*exp(-x-(x+x0)**2)/x
   else 
      y = temperature*exp(+x-(x-x0)**2)/x
   end if

   inv_dfb_distribution = y

end function inv_dfb_distribution
