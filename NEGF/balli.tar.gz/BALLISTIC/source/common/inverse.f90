!********************************************************
! ���ӳ�������lapack ��������
!********************************************************
!-----------------------------------------------------
subroutine  inverse_zmatrix(a_in, a_out, error_id)
!-----------------------------------------------------
   implicit none
   double complex, intent(in)::   a_in(:,:)
   double complex, intent(out)::  a_out(:,:)
   integer, intent(out)::  error_id

   ! Local variables
   integer::  nn,  Lda,  Lwork
   integer::  num_dim(1:2), row_num, col_num
   integer, allocatable::         ipiv(:)
   double complex, allocatable::  work(:), temp_a(:,:)
   integer:: info_1, info_2
   
   error_id = 0

   num_dim(:) = shape(a_in)
   row_num = num_dim(1);    col_num = num_dim(2)

   if( row_num /= col_num ) then
      print*, 'error in matrix inversion, not a square matrix'
      stop
   end if

   if(row_num == 1) then
      a_out(1,1) = cmplx(1.0d0, 0.0d0)/a_in(1,1)
      return
   end if

   allocate(ipiv(1:row_num), work(1:row_num), temp_a(1:row_num, 1:col_num) )
   
   ! a_in(:,:) �������ı䣬������ô��������һ����ʱ���顣
   temp_a(:,:) = a_in(:,:) 

   ipiv(:) = 0
   nn = row_num;   Lda = row_num;    Lwork = row_num
   
   CALL zgetrf(nn, nn, temp_a, Lda,  ipiv, info_1 )
 
   a_out(:,:) = temp_a(:,:)
   CALL zgetri(nn, a_out, Lda, ipiv,  work,  Lwork,  info_2 )

   error_id = abs(info_1) + abs(info_2 )

   deallocate(ipiv, work, temp_a)

end subroutine  inverse_zmatrix
