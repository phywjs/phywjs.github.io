! Given job id and len items to do, what is the range [i_beg, i_en]?
! id counts from 0, job item counts from 1.
!
subroutine jobrange(id, len, i_beg, i_en)
   use MPI_data
   implicit none
   integer, intent(in):: id, len
   integer, intent(out):: i_beg, i_en
   integer:: r, k

   if(id .GE. numprocs) then
      print *, 'Error in jobrange(), id >= numprocs'
      stop
   end if

   k = len/numprocs          ! quotient
   r = len - k*numprocs      ! remainder
   if(id < r) then
      i_beg = (k+1)*id + 1
      i_en = i_beg + k
   else
      i_beg = (k+1)*r + k*(id-r) + 1
      i_en = i_beg + (k-1)
   endif
   
end subroutine jobrange
