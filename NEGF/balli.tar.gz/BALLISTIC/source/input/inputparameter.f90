!*************************** ������� **************************************** 
subroutine input_run_parameter
   use comm_general
   use data_array
   use mpi
   use MPI_data
   implicit none

   ! Local variables
   integer::  len_in
   character*80::   temp_char

   if(myid .EQ. 0) then
    
      open(200, file='data/runparameter/runparameter.dat', status='old')
	
      ! input delta from the file
      read(200, *)  temp_char
      read(200, *)  delta

      ! input omega_cut  omega_max
      read(200, *)   temp_char
      read(200, *)   omega_cut, omega_max
	 
      ! input length_array, stored in data_array.mod
      read(200, *)   temp_char
      read(200, *)   len_in
      length_array = len_in 
      omega_interval = omega_max / length_array

      ! input temperature scan range
      read(200, *)   temp_char
      read(200, *)   T_begin, T_end

      read(200, *)   temp_char
      read(200, *)   tpts         ! number of temperature samples

!      read(200, *)   temp_char
!      read(200, *)   mfloop_max, mfloop_max_d   ! number of mean-field iterations
!
!      read(200, *)   temp_char
!      read(200, *)   index_to_G   ! which to print
!
!      read(200, *)   temp_char
!      read(200, *)   mix_factor, sn_mix_factor   ! used in mean-field iteration
!      read(200, *)   temp_char
!      read(200, *)   mix_factor_g, mix_factor_n  ! for G< to G^r, and dG

      close(200)

   end if

   call MPI_BCAST(delta, 1, MPI_DOUBLE_PRECISION, 0, MPI_COMM_WORLD, ierr)
   call MPI_BCAST(omega_cut, 1, MPI_DOUBLE_PRECISION, 0, MPI_COMM_WORLD, ierr)
   call MPI_BCAST(omega_max, 1, MPI_DOUBLE_PRECISION, 0, MPI_COMM_WORLD, ierr)
   call MPI_BCAST(omega_interval, 1, MPI_DOUBLE_PRECISION, 0, MPI_COMM_WORLD, ierr)
   call MPI_BCAST(length_array, 1, MPI_INTEGER, 0, MPI_COMM_WORLD, ierr)
   call MPI_BCAST(T_begin, 1, MPI_DOUBLE_PRECISION, 0, MPI_COMM_WORLD, ierr)
   call MPI_BCAST(T_end, 1, MPI_DOUBLE_PRECISION, 0, MPI_COMM_WORLD, ierr)
   call MPI_BCAST(tpts, 1, MPI_INTEGER, 0, MPI_COMM_WORLD, ierr)
!   call MPI_BCAST(mfloop_max, 1, MPI_INTEGER, 0, MPI_COMM_WORLD, ierr)
!   call MPI_BCAST(mfloop_max_d, 1, MPI_INTEGER, 0, MPI_COMM_WORLD, ierr)
!   call MPI_BCAST(index_to_G, 1, MPI_INTEGER, 0, MPI_COMM_WORLD, ierr)
!   call MPI_BCAST(mix_factor, 1, MPI_DOUBLE_PRECISION, 0, MPI_COMM_WORLD, ierr)
!   call MPI_BCAST(sn_mix_factor, 1, MPI_DOUBLE_PRECISION, 0, MPI_COMM_WORLD, ierr)
!   call MPI_BCAST(mix_factor_g, 1, MPI_DOUBLE_PRECISION, 0, MPI_COMM_WORLD, ierr)
!   call MPI_BCAST(mix_factor_n, 1, MPI_DOUBLE_PRECISION, 0, MPI_COMM_WORLD, ierr)

end subroutine input_run_parameter
