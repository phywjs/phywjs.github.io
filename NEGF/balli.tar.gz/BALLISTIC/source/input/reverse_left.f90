!---------------------------------------
! ����ߵ�������з�תԤ����
!----------------------------------------
! left side spring constants k's are input with a consistent coordinates
! (left particles have smaller matrix indices, right particles bigger
! indices), but the sfgsolve() requires the reversed version.  
!
subroutine  reverse_left(h00, h11, h01)
   use sub2_interface
   implicit none 
   double complex, dimension(:,:)::  h00, h11, h01

   ! Local variables
   integer::  i, num_dim(1:3,1:2)
   integer::  tn, tm
   double complex, allocatable::  tmp_array(:,:), h10(:,:)

   ! body part
   num_dim(1,1:2) = shape(h00)
   num_dim(2,1:2) = shape(h11)
   num_dim(3,1:2) = shape(h01)
   do i=1, 3
      if(num_dim(i,1) .ne. num_dim(i,2) )then
        print*, 'error in reverse_left, k matrix must be square'
        stop
      end if
   end do
   if( (num_dim(1,1) .ne. num_dim(2,1) ) .or. &
       (num_dim(1,1) .ne. num_dim(3,1) ) ) then
      print*, 'error in reverse_left, size k00, k11, k01 must be the same'
      stop
   end if

   tn = num_dim(1,1)
   tm = num_dim(1,2)
   allocate(tmp_array(1:2*tn, 1:2*tm))
   allocate(h10(1:tn, 1:tm))

   h10(:,:) = transpose(h01)
   
   tmp_array(1:tn,1:tn) = h00(:,:)
   tmp_array(1:tn, tn+1:2*tn) = h01(:,:)
   tmp_array(tn+1:2*tn, 1:tn) = h10(:,:)
   tmp_array(tn+1:2*tn, tn+1:2*tn) = h11(:,:)

   call reverse_green(tmp_array)

   h00(:,:) = tmp_array(1:tn,1:tn)
   h01(:,:) = tmp_array(1:tn, tn+1:2*tn)
   h11(:,:) = tmp_array(tn+1:2*tn, tn+1:2*tn)

   deallocate(tmp_array, h10)

end subroutine reverse_left
!-------------------------------------------------
