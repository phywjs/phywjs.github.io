!**********************************************************
! ���ļ��ӳ�����Ҫ������صĵ��������������ļ���          *
! �Ķ��롣 ��Ҫ���������ӳ���                           *
!   input_lead --- ����Lead�ϵĵ�������                   *
!            ��صı����Ǵ� comm_dynamic ����ģ�鴫���   *
!            ��Ҫ���� k00, k11, k01 ���ҵ� Lead ����      *
!            �ֱ�ͨ�� _left �� _right ����ʾ��            *
! Very important and tricky: the left and right k's for user inputs are 
! in natural coordinates system. That is, the K submatrices are arranged 
! this way:
!--------------------
! k00_left | k01_left |
!--------------------------
!          | k11_left | vlc
!--------------------------------------
!          |          | k0_center |    
!          |          |           |
!------------------------------------------------
!                             vrc |  k00_right | k01_right
!                             ----------------------------
!                                 |            | k11_right
!                                 ------------------------
! That is, k00_right and k11_left are close to the center.  However,
! after reading in the user data, the program reverses the coordinates
! of the left lead so that k00_left and k11_left are interchanged
! and transposed, as required by sfgsolve.f90.
!
! units for the quadratic force constants k is 10 N/m/amu    *
! (will change to eV/(A^0)^2/amu)                            *
!*************************************************************

!����Lead �����������
!--------------------------------------------------
 subroutine input_lead
!-------------------------------------------------
   use  comm_dynamic
   use  sub_interface    ! for reverse_left()
   use  input_interface   
   use  mpi
   use  MPI_data
   implicit none

   integer::  ti, tj, channel, symm
   integer::  ti_in, tj_in
   character*80::  tmp_char
   double precision, dimension(:,:), pointer:: input_array
   
   if(myid .EQ. 0) then
      nullify(input_array)

!********************************
!  �������Lead�������������   *
!********************************   
      open(10, file="data/input/lead_left.dat", status='old') 
      !--------------------------------------------------

      read(10,*) tmp_char
      read(10,*) tmp_char
      read(10,*) ti, tj
      channel = 10
      symm = 1
      call read_matrix(input_array, ti, tj, channel, symm)
      allocate(k00_left(ti, tj))
      k00_left(:,:) = input_array(:,:)

      read(10,*) tmp_char
      read(10,*) ti, tj
      call read_matrix(input_array, ti, tj, channel, symm)
      allocate(k11_left(ti, tj))
      k11_left(:,:) = input_array(:,:)

      read(10,*) tmp_char
      read(10,*) ti, tj
      symm = 0
      call read_matrix(input_array, ti, tj, channel, symm)
      allocate(k01_left(ti, tj))
      k01_left(:,:) = input_array(:,:)

      ! ��ת��ߵ�Lead����Ĳ���
      ! ע�����˳��һ��Ҫ��������ĸ���
      !--------------------------------------
      call reverse_left(k00_left,k11_left, k01_left)
      !---------------------------------------------------

      close(10)

   end if

   ! sizes of matrices of the left must be the same
   call MPI_BCAST(ti, 1, MPI_INTEGER, 0, MPI_COMM_WORLD, ierr)
   call MPI_BCAST(tj, 1, MPI_INTEGER, 0, MPI_COMM_WORLD, ierr)
   if(myid .NE. 0) then
      allocate(k00_left(ti, tj))
      allocate(k11_left(ti, tj))
      allocate(k01_left(ti, tj))
   end if
   call MPI_BCAST(k00_left(:,:), ti*tj, MPI_DOUBLE_COMPLEX, 0, MPI_COMM_WORLD, ierr)
   call MPI_BCAST(k11_left(:,:), ti*tj, MPI_DOUBLE_COMPLEX, 0, MPI_COMM_WORLD, ierr)
   call MPI_BCAST(k01_left(:,:), ti*tj, MPI_DOUBLE_COMPLEX, 0, MPI_COMM_WORLD, ierr)



!********************************
!  �����ұ�Lead�������������   *
!********************************
   if(myid .EQ. 0) then
      open(11, file="data/input/lead_right.dat", status='old') 
      ! ---------------------------------------------------   

      read(11,*) tmp_char
      read(11,*) tmp_char
      read(11,*) ti, tj
      channel = 11
      symm = 1
      call read_matrix(input_array, ti, tj, channel, symm)
      allocate(k00_right(ti, tj))
      k00_right(:,:) = input_array(:,:)

      read(11,*) tmp_char
      read(11,*) ti_in, tj_in
      if(ti_in .NE. ti .OR. tj_in .NE. tj) then
        print *, 'matrix size k11_right must be the same as k00_right'
        stop
      end if
      call read_matrix(input_array, ti, tj, channel, symm)
      allocate(k11_right(ti, tj))
      k11_right(:,:) = input_array(:,:)

      read(11,*) tmp_char
      read(11,*) ti_in, tj_in
      if(ti_in .NE. ti .OR. tj_in .NE. tj) then
        print *, 'matrix size k01_right must be the same as k00_right'
        stop
      end if
      symm = 0
      call read_matrix(input_array, ti, tj, channel, symm)
      allocate(k01_right(ti, tj))
      k01_right(:,:) = input_array(:,:)

      close(11)

      deallocate(input_array)  ! release memory before return

   end if

   ! sizes of matrices of the right must be the same
   call MPI_BCAST(ti, 1, MPI_INTEGER, 0, MPI_COMM_WORLD, ierr)
   call MPI_BCAST(tj, 1, MPI_INTEGER, 0, MPI_COMM_WORLD, ierr)
   if(myid .NE. 0) then
      allocate(k00_right(ti, tj))
      allocate(k11_right(ti, tj))
      allocate(k01_right(ti, tj))
   end if
   call MPI_BCAST(k00_right(:,:), ti*tj, MPI_DOUBLE_COMPLEX, 0, MPI_COMM_WORLD, ierr)
   call MPI_BCAST(k11_right(:,:), ti*tj, MPI_DOUBLE_COMPLEX, 0, MPI_COMM_WORLD, ierr)
   call MPI_BCAST(k01_right(:,:), ti*tj, MPI_DOUBLE_COMPLEX, 0, MPI_COMM_WORLD, ierr)

end subroutine input_lead


!*******************************************
! �����м䲿�ֵ�����������                 * 
!*******************************************
! ����Ľ����ͨ�� g0r_center ���ݵ�

!-------------------------------------------
 subroutine input_center
!-------------------------------------------
   use  comm_dynamic
   use  input_interface
   use  array_in_main
   use  mpi
   use  MPI_data

   implicit none

   integer::  ti, tj, channel, symm
   character*80:: tmp_char
   double precision, dimension(:,:), pointer:: input_array

   if(myid .EQ. 0) then 

      nullify(input_array)

      open(12, file='data/input/center.dat', status='old')
      !-----------------------------------------------
      read(12,*) tmp_char
      read(12,*) ti, tj
      channel = 12
      symm = 1
      call read_matrix(input_array, ti, tj, channel, symm)
      allocate(k0_center(ti, tj))
      k0_center(:,:) = input_array(:,:)

      allocate(g0r_center(1:ti,1:tj))  ! should do this in green_allocate?

      deallocate(input_array)

      close(12)

   end if

   call MPI_BCAST(ti, 1, MPI_INTEGER, 0, MPI_COMM_WORLD, ierr)
   call MPI_BCAST(tj, 1, MPI_INTEGER, 0, MPI_COMM_WORLD, ierr)
   if(myid .NE. 0) then
      allocate(k0_center(ti, tj))
      allocate(g0r_center(ti, tj))
   end if
   call MPI_BCAST(k0_center(:,:), ti*tj, MPI_DOUBLE_COMPLEX, 0, MPI_COMM_WORLD, ierr)


end subroutine input_center
!------------------------------------------------

!**********************************************
! ���뽻����ֵ�������                      *
!**********************************************
! �������������ͨ�� comm_vlcr ģ�鴫�ݵ�
!                         vlc(:,:)------��ߵĽ�����
!                         vrc(:,:)------�ұߵĽ�����
! �ӿڲ��� gLR, gRR, left_sen, right_sen ��Ҫ��ͨ��
! �ӿڵķ�ʽ�����ݾ�������Լ�����ʼ����

!-----------------------------------------------------
subroutine  input_vlcr
!-----------------------------------------------------
   use  comm_vlcr
   use  array_in_main
   use  input_interface
   use  mpi
   use  MPI_data

   implicit none

   integer::   tn, tm, channel, symm
   character*80:: tmp_char
   double precision, dimension(:,:), pointer:: input_array

   if(myid .EQ. 0) then

      nullify(input_array)

      open(18, file='data/input/vlcr.dat', status='old')
   
      ! ������ߵĽ�����
      read(18, *)  tmp_char
      read(18, *)  tn, tm
      channel = 18
      symm = 0
      call read_matrix(input_array, tn, tm, channel, symm)
      allocate(vlc(1:tn, 1:tm))
      vlc(:,:) = input_array(:,:)
      allocate(gLR(1:tn,1:tn), left_sen(1:tm, 1:tm))
   end if

   call MPI_BCAST(tn, 1, MPI_INTEGER, 0, MPI_COMM_WORLD, ierr)
   call MPI_BCAST(tm, 1, MPI_INTEGER, 0, MPI_COMM_WORLD, ierr)
   if(myid .NE. 0) then
      allocate(vlc(1:tn, 1:tm))
      allocate(gLR(1:tn,1:tn), left_sen(1:tm, 1:tm))
   end if
   call MPI_BCAST(vlc(:,:), tn*tm, MPI_DOUBLE_COMPLEX, 0, MPI_COMM_WORLD, ierr)


  if(myid .EQ. 0) then
   
      ! �����ұߵĽ�����
      read(18, *)  tmp_char
      read(18, *)  tn, tm
      channel = 18
      symm = 0
      call read_matrix(input_array, tn, tm, channel, symm)
      allocate(vrc(1:tn, 1:tm))
      vrc(:,:) = input_array(:,:)
      allocate(gRR(1:tn,1:tn), right_sen(1:tm, 1:tm))
   
      close(18)
   
      deallocate(input_array)
   end if

   call MPI_BCAST(tn, 1, MPI_INTEGER, 0, MPI_COMM_WORLD, ierr)
   call MPI_BCAST(tm, 1, MPI_INTEGER, 0, MPI_COMM_WORLD, ierr)
   if(myid .NE. 0) then
      allocate(vrc(1:tn, 1:tm))
      allocate(gRR(1:tn,1:tn), right_sen(1:tm, 1:tm))
   end if
   call MPI_BCAST(vrc(:,:), tn*tm, MPI_DOUBLE_COMPLEX, 0, MPI_COMM_WORLD, ierr)


end subroutine input_vlcr
!---------------------------------------------

! A service routine (an interface module is defined as input_interface)
! to read a whole matrix at once.  Also check for symmetry if needed.
! A is a pointer, (tn, tm) matrix dimensions, and
! channel for read(channel, *).
!
subroutine read_matrix(A_pointer, tn, tm, channel, symm)
   implicit none
   double precision, dimension(:,:), pointer:: A_pointer
   integer, intent(in):: tn, tm, channel, symm
   integer:: i
   double precision:: d
   
   if(associated(A_pointer)) then
      deallocate(A_pointer)
   end if
   allocate(A_pointer(1:tn, 1:tm))

   do i = 1, tn
      read(channel, *) A_pointer(i, 1:tm)
   end do
   if (symm == 1) then
      if(tn .NE. tm) then 
         print *, 'read channel', channel, ' is not a square'
         stop
      end if
      d = maxval(abs(A_pointer(:,:) - transpose(A_pointer(:,:))))
      if (d > 1.0d-5) then
         print *, 'Warning, channel ', channel, ' matrix is not symmetric!'
      end if
   end if

end subroutine read_matrix
