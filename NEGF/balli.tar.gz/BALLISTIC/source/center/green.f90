! �����м�� G_retard Green function
! also compute nonlinear case if non_sen != 0
! g0r = 1/( omega^2 - k^C - left_sen - right_sen )
!
subroutine  cal_g0_center( left_sen, right_sen, omega, g0r_center )
   use comm_dynamic
   use sub_interface
   implicit none
   
   double complex, intent(in)::  left_sen(:,:), right_sen(:,:), omega
   double complex, intent(out)::  g0r_center(:,:)
    
   ! Local variables declaration 
   double complex::  square_omega  
   double complex, dimension(:,:), pointer::  identity, tmp_g0, tp1
   integer::  error_id

   square_omega = omega * omega

   nullify(identity, tmp_g0, tp1)  ! make sure pointing to NULL

   call duplicate_complex_2dmatrix(k0_center, identity)
   call duplicate_complex_2dmatrix(k0_center, tmp_g0)
   call duplicate_complex_2dmatrix(k0_center, tp1)

   call  set_identity_matrix( identity )
   identity(:,:) = square_omega * identity(:,:)

   ! ����ߵ����ܼ������Ͻ�
   call self_eng_augment(left_sen, tmp_g0, 1)

   ! ���ұߵ����ܼ������½�
   call self_eng_augment(right_sen, tp1, 2)
    
   tmp_g0(:,:) = tmp_g0(:,:) + tp1(:,:)

   ! �������
   tmp_g0(:,:) = identity(:,:) - k0_center(:,:) - tmp_g0(:,:)

   CALL  inverse_zmatrix(tmp_g0, g0r_center, error_id)

   deallocate(identity, tmp_g0, tp1)

end subroutine cal_g0_center



! compute G< = G^r ( S<_L + S<_R + Sn<) G^a
!
subroutine cal_G_less_center(self_less_L, self_less_R, non_self_less, g0r_center, g_less_center)
   implicit none
   double complex, intent(in):: self_less_L(:,:),  self_less_R(:,:), non_self_less(:,:), g0r_center(:,:)
   double complex, intent(out):: g_less_center(:,:)
   
   integer::  n, nL, nR, j 
   double complex, allocatable::  tmp_self(:,:), g_a_center(:,:), tmp_result(:,:)

   n = size(g0r_center, 1)
   nL = size(self_less_L, 1)
   nR = size(self_less_R, 1)
 
   allocate(tmp_self(1:n,1:n), g_a_center(1:n,1:n), tmp_result(1:n,1:n))

   tmp_self(:,:) = non_self_less(:,:)
  
   ! ����ߵ����ܼ������Ͻ�
   tmp_self(1:nL,1:nL) = tmp_self(1:nL,1:nL) + self_less_L(:,:)

   ! ���ұߵ����ܼ������½�
   j = n - nR + 1
   tmp_self(j:n, j:n) = tmp_self(j:n, j:n) + self_less_R(:,:)

! Get the advanced_Green function
   g_a_center(:,:) = conjg(transpose(g0r_center(:,:)))

! ������˵õ����         
! G^< = G^r * S^< G^a

   tmp_result(:,:) = matmul(g0r_center, tmp_self)
   g_less_center(:,:) = matmul(tmp_result, g_a_center)

   deallocate(tmp_self, g_a_center, tmp_result)

end subroutine cal_G_less_center



! ����lead��g<���ֺ��� (equilibrium version)
! g< = f(omega) (g^r - g^a)
! also applicable for lead self-energy Sig^r to Sig^<
!
subroutine cal_gless(gR, gLess, omega, temperature)
  use distribution_interface
  implicit none
  
  double complex, intent(in)::   gR(:,:)
  double complex, intent(out)::  gLess(:,:)
  double complex, intent(in)::   omega
  double precision, intent(in):: temperature
  double precision::  fb

  fb = fb_distribution(omega, temperature)
  gLess(:,:) = cmplx(fb, 0.0d0) * ( gR(:,:) - transpose(conjg(gR(:,:))) )

end subroutine  cal_gless

