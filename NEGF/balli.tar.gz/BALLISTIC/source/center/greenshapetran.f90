!----------------------------------------------------
subroutine tran_green_shape
!---------------------------------------------------------
   use  green_shape
   use  array_in_main
 
   implicit none
   
   ! ����shape����
   gLR_shape(1:2)=shape(gLR)
   gRR_shape(1:2)=shape(gRR)   
   g0_center_shape(1:2)=shape(g0r_center)
   left_sen_shape(1:2)=shape(left_sen)
   right_sen_shape(1:2)=shape(right_sen)

end subroutine tran_green_shape
!----------------------------------------


!----------------------------------------
!subroutine green_allocate
!
!   use  array_in_main
!
!   implicit none
!
!  ! Local variables 
!    integer::  tn, tm
!    integer::  num_dim(1:2)    
!  
!
!    ! less-than green function for the lead
!    num_dim(1:2) = shape(gLR)
!    tn = num_dim(1)
!    tm = num_dim(2)
!    allocate(g_less_L(1:tn,1:tm) )
! 
!    num_dim(1:2) = shape(gRR)
!    tn = num_dim(1)
!    tm = num_dim(2)
!    allocate( g_less_R(1:tn,1:tm))
!
!   note that g0r_center is already allocated in input.f90
!    num_dim(1:2) = shape(g0r_center)
!    tn = num_dim(1)
!    tm = num_dim(2)
!!    allocate( g0_less_center(1:tn,1:tm))
!    allocate(non_sen(1:tn,1:tm), non_sen_less(1:tn,1:tm))
!    allocate(Gn_retard(1:tn,1:tm), Gn_less(1:tn, 1:tm))
!    allocate(dG_retard(1:tn,1:tm), dG_less(1:tn, 1:tm))
!   
!    ! less-than self-energy for the lead
!    num_dim(1:2) = shape(left_sen)
!    tn = num_dim(1)
!    tm = num_dim(2)
!    allocate(self_less_L(1:tn,1:tm) )
! 
!    num_dim(1:2) = shape(right_sen)
!    tn = num_dim(1)
!    tm = num_dim(2)
!    allocate( self_less_R(1:tn,1:tm))
!
!end subroutine green_allocate


!------------------------------------------------
subroutine duplicate_complex_2dmatrix(matrix_a, matrix_b)
!------------------------------------------------
   implicit none
   
   double complex, intent(in):: matrix_a(:,:)
   double complex, dimension(:,:), pointer:: matrix_b

   integer::  tn, tm,  num_dim(1:2)
   
   num_dim(1:2) = shape(matrix_a)
   tn = num_dim(1);   tm = num_dim(2)

   if (associated(matrix_b)) then
      deallocate(matrix_b)
   end if
   allocate( matrix_b(1:tn, 1:tm) )
   
end subroutine duplicate_complex_2dmatrix
!########################################

!--------------------------------------------------------
subroutine  self_eng_augment(part_self, full_self, itype )
!--------------------------------------------------------
  implicit none
  double complex, dimension(:,:), intent(in)::   part_self
  double complex, dimension(:,:), intent(out)::  full_self
  integer, intent(in)::  itype
! itype = 1 �����ϽǷ���
! itype = 2 �����½Ƿ���

!  Local variables
  integer::  tn, tm, tnn, tmm, row_num, col_num
  integer::  num_dim(1:2)

  full_self(:,:) = cmplx(0.0d0, 0.0d0)

  num_dim = shape(part_self)
  tn = num_dim(1)
  tm = num_dim(2)

  if( itype == 1) then
     full_self(1:tn,1:tm) =  part_self(1:tn,1:tm)
  else if (itype == 2) then
     num_dim = shape(full_self)
     tnn = num_dim(1)
     tmm = num_dim(2)

     if(tnn<tn .or. tmm<tm ) then
       print*, 'error in self-energy augment matrix'
       stop
     end if

     row_num = tnn - (tn-1)
     col_num = tmm - (tm-1)

     full_self(row_num:tnn, col_num:tmm) =  part_self(1:tn,1:tm)
  else 
     print*, 'error in self-energy augment matrix'
     print*, 'itype should be 1 or 2 '
     stop
  end if
 
end subroutine self_eng_augment

!--------------------------------------
subroutine set_identity_matrix( matrix )
!---------------------------------------
   implicit none
   double complex, intent(out):: matrix(:,:)

   integer:: tn, tm, num_dim(1:2)
   integer::  i
   
   matrix(:,:) = cmplx(0.0d0, 0.0d0)
   num_dim(:) = shape(matrix)
   tn = num_dim(1)
   tm = num_dim(2)

   if(tn /= tm ) then
     print*, 'set identity matrix error'
     print*, 'matrix is not a square matrix'
     stop
   end if

   do i=1, tn
      matrix(i,i) = cmplx(1.0d0, 0.0d0)
   end do

end subroutine set_identity_matrix
