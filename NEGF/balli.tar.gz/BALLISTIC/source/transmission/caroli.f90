! Calculate transmission using Caroli formula
! T[w] = Tr( G^r E_L G^a E_R),  E_L = i (S^r - S^a) = i D
! note that matrix for self_eng_left/right can be smaller than
! that of g0_center_r
!
subroutine cal_tranmission(self_eng_left, self_eng_right, g0_center_r, transm)
   implicit none
   
   double complex, intent(in)::  self_eng_left(:,:), self_eng_right(:,:),  g0_center_r(:,:)
   double complex, intent(out)::  transm 

   integer:: i, j, ng, ns, ns_L, ns_R
   integer:: array_dim(1:2)
   double complex, dimension(:,:), allocatable:: g_rsub, g_asub, s_Lsub, s_Rsub
   double complex, dimension(:,:), allocatable:: tmp_left, tmp_right, eng_left, eng_right
   double complex::   tz
   
   array_dim(1:2) = shape(g0_center_r)
   ng = array_dim(1)
   array_dim(1:2) = shape(self_eng_left)
   ns_L = array_dim(1)
   array_dim(1:2) = shape(self_eng_right)
   ns_R = array_dim(1)

   ns = max(ns_L, ns_R)   ! use the bigger of two to work with
   if(ns > ng) then       ! this cannot happen
      print *, 'in caroli formula, ns > ng'
      stop
   end if

   allocate(g_rsub(1:ns, 1:ns), g_asub(1:ns, 1:ns))
   allocate(s_Lsub(1:ns, 1:ns), s_Rsub(1:ns, 1:ns))
   allocate(tmp_left(1:ns, 1:ns), tmp_right(1:ns, 1:ns))
   allocate(eng_left(1:ns, 1:ns), eng_right(1:ns, 1:ns))
   j = ng - ns + 1

! pick out the submatrices (N,1) in G_r
! also enlarge self-energy matrices if necessary
   g_rsub(:,:) = g0_center_r(j:ng, 1:ns)
   g_asub(:,:) = transpose(conjg(g_rsub))
   s_Lsub(:,:) = cmplx(0.0d0, 0.0d0)   ! s_Lsub() can be larger than eng_left
   s_Lsub(1:ns_L, 1:ns_L) = self_eng_left(:,:)  ! upper left corner
   s_Rsub(:,:) = cmplx(0.0d0, 0.0d0)   ! s_Rsub() is similar
   s_Rsub(ns-ns_R+1:ns, ns-ns_R+1:ns) = self_eng_right(:,:)  ! lower right
 
!  compute Gamma_L and _R
   eng_left(:,:) = cmplx(0.0d0, 1.0d0) * &
         (s_Lsub(:,:) - transpose(CONJG(s_Lsub(:,:))))
   eng_right(:,:) = cmplx(0.0d0, 1.0d0) * &
         (s_Rsub(:,:) - transpose(CONJG(s_Rsub(:,:))))

   tmp_left = matmul(g_rsub, eng_left)
   tmp_right = matmul(g_asub, eng_right)
   tmp_left = matmul(tmp_left, tmp_right)
  
   tz = cmplx(0.0d0, 0.0d0)
   do i = 1, ns 
     tz = tz + tmp_left(i, i)  ! take trace
   end do

   transm = tz

   deallocate(g_rsub, g_asub)
   deallocate(s_Lsub, s_Rsub)
   deallocate(tmp_left, tmp_right)
   deallocate(eng_left, eng_right)

end subroutine cal_tranmission


! A generalized Caroli formula for the effective transmission
!
! T_eff[w] = (1/2) Tr{ G^r (-D_L - D_n/2 + dS) G^a D_R
!                      G^a D_L G^r(-D_R - D_n/2 - dS) }
! where i D_R = i (Sig^r - Sig^a) = Gamma_R
!
! The formula is obtained by taking the temperature limit T_L -> T_R -> T.
! We setup the input arguments and then call Caroli routine
! which takes Sig^r as input, not Gamma_R.
!
subroutine eff_transmission(sigma_r_left, sigma_r_right,  &
                            sn_r, d_sn_r, d_sn_less, G_r, transm)
   use interface_commn
   implicit none
   double complex, dimension(:,:), intent(in):: sigma_r_left, sigma_r_right, &
                                                sn_r, d_sn_r, d_sn_less, G_r
   double complex, intent(out):: transm

   ! local variables
   double complex, dimension(:,:), allocatable:: D, G_a, dS
   double complex:: tz1, tz2
   integer:: n, nL, nR, j

   n = size(G_r, 1)
   nL = size(sigma_r_left, 1)
   nR = size(sigma_r_right, 1)
   allocate(D(1:n, 1:n), G_a(1:n, 1:n), dS(1:n, 1:n))

!  note f/df factor is absorbed in d_sn_r(), also dS - dS^\dagger
!  will reproduce the correct d_sn_less term
   dS(:,:) = d_sn_r(:,:) - 0.5*d_sn_less(:,:)

   D(:,:) = 0.5 * sn_r(:,:) - dS(:,:)
   D(1:nL, 1:nL) = D(1:nL,1:nL) + sigma_r_left(:,:)  ! upper left

   call cal_tranmission(D, sigma_r_right, G_r, tz1)

   j = n - nR + 1
   D(:,:) = 0.5 * sn_r(:,:) + dS(:,:)
   D(j:n, j:n) = D(j:n,j:n) + sigma_r_right(:,:)  ! lower right
   G_a(:,:) = transpose(conjg(G_r))

   call cal_tranmission(sigma_r_left, D, G_a, tz2)

   transm = 0.5*(tz1 + tz2)

   deallocate(D, G_a, dS)

end subroutine eff_transmission
