! Compute 1D real-time retarded surface Green's function g^L(t), self-energy
! Sigma_L(t) = V^CL g^L(t) V^LC, and the Fourier transform of the quantum 
! noise correlation function <eta(t) eta(0)^T>, using the results of A Dhar 
! and D Roy, J. Stat. Phys. 125, 805 (2006).
!
! One lead only, either left or right lead given by input data.
!
! Wang Jian-Sheng, 19 May 2007
!
program bath

   implicit none
   double precision:: k00, k11, k01, vlc
   double complex:: h00, h11, h01, omega, omega_square, gR
   double complex, allocatable:: X(:), Y(:), Y1(:)
   double precision:: omega_interval, dt, delta, w, d
   double precision:: gamma, nois
   double precision:: temperature
   integer:: i, array_length, sign, N_noise
   character*1 side_char
   character*20 filename
   double precision, parameter::  pi = 3.141592653589793238d0
   double precision, parameter::  hbar = 0.06466 ! in units of eV,amu,A^0


   print *, 'quadratic force constants in units of eV, amu, A^0'
   print *, 'enter lead k00, k11, k01 (k00 is close to center, k11 is repeated)'
   read(*, *) k00, k11, k01
   print *, 'enter lead-center coupling V^{LC or RC}'
   read(*, *) vlc
   print *, 'enter FFT points array_length (power of 2)'
   read(*,*) array_length
   print *, 'enter time interval dt (in units of 1.018 x 10^(-14) sec)'
   read(*,*) dt
   print *, 'enter a small delta'
   read(*,*) delta
   print *, 'enter sampling points for noise spectrum'
   read(*,*) N_noise
   print *, 'enter temperature T (in units of eV/k_B)'
   read(*,*) temperature
   print *, 'enter a string for the output file name'
   read(*,*) filename
   print *, 'enter a character to specify the lead side'
   read(*,*) side_char

!  compute the real-time retarded surface green function
!  use the exact result, and then do FFT to get g(t)
!  then Sigma(t) = V^(CR) g^R V^(RC)

   allocate(X(1:array_length))
   allocate(Y(1:array_length))
   allocate(Y1(1:array_length))

   h00 = k00      ! sfg_solve() require complex type
   h11 = k11
   h01 = k01

   omega_interval = 2.0*pi/(array_length*dt)

   do i = 1, array_length
      if(i <= array_length/2) then
         omega = cmplx((i-1)*omega_interval, delta)
      else
         omega = cmplx((i-1-array_length)*omega_interval, delta)
      end if
      omega_square = omega * omega
      call  sfg_solve(gR, omega_square, h00, h11, h01)
      X(i) = gR*vlc*vlc
   end do
   sign = -1
   call FFT(sign, X, Y, array_length, omega_interval)    ! omega to t
   call FFT(-sign, Y, Y1, array_length, omega_interval)  ! t to omega

   d = 0.0
   do i = 1, array_length
     d = d + abs(X(i) - Y1(i))
   end do
   print *, 'check FFT, err = ', d     ! d should be of order 10^(-14)

   open(11, file=trim(filename)//'gRt_'//side_char//'.dat', status='unknown')
   write(11, '(A, F7.3, A, F7.3, A, F7.3, A, F7.3, A)') '# k00=', k00, &
       & ' k11=', k11, ' k01=', k01, ' vlc=', vlc, ' in units of eV, amu, A'
   write(11, '(A, F8.4, A, I8, A, F8.5)') '# dt=', dt, & 
       & ' array_length/2=', array_length/2, ' delta=', delta
   do i = 1, array_length/2
      w = (i-1)*dt
      write(11, '(3G18.9)') w, real(Y(i))
   end do
   close(11)


!  Using different omega interval for the noise spectrum 
!  the upper limit of the phonon band is sqrt(4K + K0) for 1D onsite
!  should be more careful not to cut the data here for other models
!
!  The formula for the noise spectrum is 
!  hbar * ( f(w) + 1/2 ) * Gamma_L[w]
!  where f(w) = 1/[exp(hbar w/(k_B T)) -1], 
!  Gamma_L[w] = i (Sigma^r[w] - Sigma^a[w])
!  See Eq.(3.5) of Dhar and Roy on page 811.
!
   omega_interval = sqrt(2*k00)/N_noise

   open(15, file=trim(filename)//'spectra_'//side_char//'.dat', status='unknown')
   write(15, '(A, F7.3, A, F7.3, A, F7.3, A, F7.3, A)') '# k00=', k00, &
       & ' k11=', k11, ' k01=', k01, ' vlc=', vlc, ' in units of eV, amu, A'
   write(15, '(A, F8.4, A)') '# T=', temperature, ' (in eV/k_B)'
   write(15, '(A, F9.6, A, I8, A, F8.5)') '# dw=', omega_interval, & 
       & ' N_noise=', N_Noise, ' delta=', delta
   write(15, '(2G18.8)') 0.0, 0.0
   do i = 2, N_noise
      w = (i-1)*omega_interval
      omega = cmplx(w, delta)
      omega_square = omega * omega
      call sfg_solve(gR, omega_square, h00, h11, h01)
      gamma = -2.0*aimag(gR*vlc*vlc)
      nois = hbar * gamma * (1.0/(exp(hbar*w/temperature)-1.0) + 0.5)
      write(15, '(2G18.8)') w, nois
   end do
   close(15)

   deallocate(X,Y,Y1)


contains


! solve the equation  ( (w+i detla)^2 - K^L ) g^R = I.
! return only the g_00 element.

subroutine  sfg_solve(gR, square_omega, h00, h11, h01)
   implicit none
   
   double complex, intent(out)::  gR
   double complex, intent(in) ::  square_omega 
   double complex, intent(in)::  h00, h11, h01
   double complex:: a, lambda, lambda_1, lambda_2
         
!  exact result in 1D
   a = (square_omega - h11)/h01
   lambda_1 = cmplx(0.5d0, 0.0d0) * ( a + sqrt(a*a-cmplx(4.0d0, 0.0d0)) )
   lambda_2 = cmplx(0.5d0, 0.0d0) * ( a - sqrt(a*a-cmplx(4.0d0, 0.0d0)) )
   if(abs(lambda_1) .LT. 1.0) then 
      lambda = lambda_1
   else
      lambda = lambda_2
   end if
   gR = cmplx(1.0d0,0.0d0)/(h11-h00+h01/lambda)
   return

end subroutine sfg_solve


! If sign = -1 (the sign in the complex exponent), we
! transform from frequency domain G[w] to time domain G(t)
! G(t) = 1/(2pi) int_{-inf}^{+inf} G[w] exp(-i*w*t) dw
! Note that the negative t or w must be in the upper part
! of the array.  
!
! if sign = +1, we do transform from time domain G(t) to frequency domain
! G[w] = int_{-inf}^{+inf} G(t) exp(+i*w*t) dt
!
subroutine FFT(sign, X, Y, array_length, omega_interval)
   implicit none

   integer, intent(in):: sign
   double complex, intent(in):: X(:)
   double complex, intent(out):: Y(:)
   integer, intent(in):: array_length
   double precision:: omega_interval

   double complex, allocatable:: Z(:), Zout(:)
   double complex:: factor
   double precision, parameter::  pi = 3.141592653589793238d0

   integer*8:: plan
   integer:: rank, n_arr(1), howmany, istride, idist, ostride, odist, flags

   allocate(Z(1:array_length))      ! fft in
   allocate(Zout(1:array_length))   ! fft output

   ! FFTW need to use the array Z(:) and Zout(:)
   rank = 1           ! 1D FFT
   n_arr(1) = array_length
   howmany = 1        ! number of sets to do FFT
   istride = howmany  ! stride in FFT omega direction
   idist = 1          ! distance between two sets
   ostride = howmany  ! output has same format as input
   odist = 1
   flags = 0          ! means measure speed, ibed, obed is 0 for NULL

   call dfftw_plan_many_dft(plan, rank, n_arr, howmany, &
                          Z, 0, istride, idist,  &
                          Zout, 0, ostride, odist,  &
                          sign, flags)
   if(plan .EQ. 0) then
      print *, 'cannot start fftw3'
      stop
   end if

   Z(:) = X(:)
   call dfftw_execute(plan)
   Y(:) = Zout(:)
   call dfftw_destroy_plan(plan)

   factor = cmplx(0.0d0, 0.0d0)
   if(sign .EQ. -1) then              ! omega to t
      factor = omega_interval/(2.0*pi)
   else if (sign .EQ. + 1) then       ! t to omega
      factor = 2.0*pi/(array_length*omega_interval)
   else                               ! this cannot happen
      print *, 'FFT, sign must be +1, or -1'
      stop
   end if

   Y(:) = Y(:) * factor

   deallocate(Z, Zout)

end subroutine FFT

end program bath
