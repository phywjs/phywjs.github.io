#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

/* arg[1] = "stub"
   arg[2] = T
   arg[3] = dT
   arg[4] = Tpts
   arg[5] = output filename
*/
int main(int argc, char **argv)
{
   double T, dT, alpha;
   int Tpts, n;
   char stub[20];
   char filename[100], fileout[100], cmmd[100], line[100];
   FILE *fp;

   if(argc == 1) {
      printf("use: %s stub T (eV/k) dT Tpts filename\n", argv[0]);
      exit(0);
   }
   T = atof(argv[2]);
   dT = atof(argv[3]);
   Tpts = atoi(argv[4]);
   n = 0;
   alpha = 0.1;

Next: 
 
   printf("n = %d\n", n);

   strcpy(stub, argv[1]);
   strcpy(filename, "baths/");
   strcat(filename, stub);
   strcat(filename, ".inp");
   
/* handle left lead */
   fp = fopen(filename, "w");
   assert(fp != NULL);
   printf("file %s opened\n", filename);
   fprintf(fp, "2.1 2.1 -1.0\n");                     /* k00, k11, k01 */
   fprintf(fp, "-1.0\n");                                    /* V^{LC} */
   fprintf(fp, "8192\n");                                /* FFT points */
   fprintf(fp, "0.010\n");                                      /*  dt */
   fprintf(fp, "0.00001\n");                                  /* delta */
   fprintf(fp, "500\n");                                    /* N_noise */
   fprintf(fp, "%8.5f\n", T*(1.0-alpha));             /* T (in eV/k_B) */
   fprintf(fp, "%s\n", stub);                              /* filename */
   fprintf(fp, "L\n");                                         /* side */
   fclose(fp);

   sprintf(cmmd, "cd baths; ./qbath < %s.inp\n", stub);
   printf("command is %s\n", cmmd);
   system(cmmd);

/* handle right lead */
   fp = fopen(filename, "w");
   assert(fp != NULL);
   printf("file %s openned\n", filename);
   fprintf(fp, "2.1 2.1 -1.0\n");                     /* k00, k11, k01 */
   fprintf(fp, "-1.0\n");                                    /* V^{LC} */
   fprintf(fp, "8192\n");                                /* FFT points */
   fprintf(fp, "0.010\n");                                      /*  dt */
   fprintf(fp, "0.00001\n");                                  /* delta */
   fprintf(fp, "500\n");                                    /* N_noise */
   fprintf(fp, "%8.5f\n", T*(1.0+alpha));             /* T (in eV/k_B) */
   fprintf(fp, "%s\n", stub);                              /* filename */
   fprintf(fp, "R\n");                                         /* side */
   fclose(fp);

   sprintf(cmmd, "cd baths; ./qbath < %s.inp\n", stub);
   printf("command is %s\n", cmmd);
   system(cmmd);

   strcpy(filename, stub);
   strcat(filename, "input.dat");
   
   fp = fopen(filename, "w");
   assert(fp != NULL);
   printf("file %s openned\n", filename);
   fprintf(fp, "8\n");                                            /* N */
   fprintf(fp, "1.0  0.1  -1.0 -1.0\n");           /* Kc, K0, Vlc, Vrc */
   fprintf(fp, "0.0\n");                                    /* t_{ijk} */
   fprintf(fp, "0.0\n");                                         /* mu */
   fprintf(fp, "1.0\n");                                       /* mass */
   fprintf(fp, "%8.5f\n", T);                                     /* T */
   fprintf(fp, "%8.4f\n", alpha);                             /* alpha */
   fprintf(fp, "0.010\n");                                       /* dt */
   fprintf(fp, "20\n");                                     /* power X */
   fprintf(fp, "2\n");                                     /* Max pass */
   fprintf(fp, "baths/%sgRt_L.dat\n", stub);
   fprintf(fp, "baths/%sspectra_L.dat\n", stub);
   fprintf(fp, "baths/%sgRt_R.dat\n", stub);
   fprintf(fp, "baths/%sspectra_R.dat\n", stub);
   fclose(fp);

   sprintf(fileout, "%s%d.out", stub, n);

   sprintf(cmmd, "./qlangevin %s %s\n", filename, fileout);
   printf("command is %s\n", cmmd);
   system(cmmd);

   fp = fopen(fileout, "r");
   do { 
      fgets(line, 99, fp);
   } while (line[0] == '#');
   fclose(fp);

   fp = fopen(argv[5], "a");
   fputs(line, fp);
   fclose(fp);

   ++n;
   if(n < Tpts) {
      T += dT;
      goto Next; 
   }

  return 0;
}
