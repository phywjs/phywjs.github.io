/*    Molecular dynamics of cubic/quartic nonlinear onsite model
      with langevin-like quantum heat-bath of Dhar (cond-mat/0606465,
      cond-mat/0604170).

      Using 2nd order symplectic algorithm, with flux computation 
      By Jian-Sheng Wang, 19 May 2007

      Important parameters and variables --
        n:  total number of particles (central part only)
        p,q:  dynamical variables (momenta and position vectors). The
            i-th particle is at p[i], q[i], counting from 0. 
        f:  force vector. 
        J:  microscopic heat current, same convention as p, q, and f.
        h:  integration step size.
      model parameters Kc, t_ijk, Mass, etc are defined with global variables.
      many global arrays (q_past, eta_, self_, ...) 
      are defined to handle the baths.

      Function defined are symplectic() (a second-order symplectic
      step) and force() (calculation the force vector), flux(), etc.
      Use fftw3 library.
*/
#include  <stdio.h>
#include  <stdlib.h>
#include  <math.h>
#include  <assert.h>
#include  <time.h>

typedef double  real;         /* can change to long double, double, or float */

                                                         /* model parameters */
real Kc;                                               /* quadratic coupling */
real K0;                                                 /* quadratic onsite */
real Vlc, Vrc;                                       /* lead/center coupling */
real t_ijk;                                         /* cubic onsite coupling */
real t_ijkl;                                      /* quartic onsite coupling */
real Mass;                                                  /* particle mass */
real T_low;                                    /* temperature low end, i = 0 */
real T_high;                                  /* temperatures of heat bathes */ 


real kinetic(real p[], int n)                        /* total kinetic energy */
{
   real KE;
   int i;

   KE = 0.0;
   for(i = 0; i < n; ++i) {
      KE += p[i]*p[i];
   }
   return 0.5*KE/Mass;                                       /* sum p^2/(2M) */
}


real potential(real q[], int n)                    /* total potential energy */
{
   real Vk, V0, Vt, Vq, dq, Vtot, e;
   int i;

   Vk = 0.0;
   for(i = 0; i < n-1; ++i) {                        /* sum V(q_i - q_{i+1}) */
      dq = q[i] - q[i+1];                     /* where V(x) = (1/2) Kc x^2 + */
      e = dq * dq;                      
      Vk += e;
   }
   V0 = 0.0;  
   Vt = 0.0;  
   Vq = 0.0;
   for(i = 0; i < n; ++i) {               /* onsite contribution, sum U(q_i) */
      V0 += q[i]*q[i];
      Vt += pow(q[i], 3.0);
      Vq += pow(q[i], 4.0);
   }
   Vtot = 0.5*Kc*Vk + 0.5*K0*V0 + (1.0/3.0)*t_ijk*Vt + 0.25*t_ijkl*Vq;
                          /* ends are effectively connected to site -1 and n */
   Vtot += 0.5*(-Vlc)*q[0]*q[0] + 0.5*(-Vrc)*q[n-1]*q[n-1];
   return Vtot;
}

 
/*
   Energy current use Lepri's formula, defined by dh_i/dt + J_i - J_{i-1}=0.
   J_i = (1/2) (p_i + p_{i+1}) V'(q_i - q_{i+1})/M
   J_i is the flux between site i and i+1.  Onsite part does not contribute.
*/
void flux(real p[], real q[], real J[], int n)
{
   int i;
   real dq, fu;

   for(i = 0; i < n-1; ++i) {
      dq = q[i] - q[i+1];
      fu =  Kc*dq;
      J[i] = 0.5*(p[i] + p[i+1])*fu/Mass;
   }
   J[n-1] = 0.0;
}

real h;                                      /* integration step size dt = h */
real *q_past_left;             /* remember q of past time, a circular buffer */
real *q_past_right;
real *self_left, *self_right;             /* lead self energy in time domain */
real *eta_left, *eta_right;                             /* stochastic forces */
int length_kernel;          /* size of the array for kernel, integration pts */
int length_FFT;                                /* FFT size for random forces */
int ipt_now = 0;                     /* current time, a pointer for q_past_* */
int ipt_eta = 0;                                       /* current use of eta */
real lead_F_left, lead_F_right;                     /* extra forces in leads */

/* the force set must be consistent with the K^C matrix in negf program      */

void force(real q[], real f[], int n)
{
   int i, j;
   real dq_m, dq_p, f_linear;
   real fric_left, fric_right;

   for(i = 0; i < n; ++i) {     /* F_i = V'(u_{i-1}-u_i) - V'(u_i - u_{i+1}) */
      f_linear = 0.0;
      if(i > 0) {                                            /* V'(x) = Kc x */
         dq_m = q[i-1] - q[i];                     /* two ends are different */
         f_linear += Kc*dq_m;
      } else {
         f_linear += (-Vlc)*(-q[0]);
      }
      if(i < n-1) {
         dq_p = q[i] - q[i+1];
         f_linear -= Kc*dq_p;
      } else {
         f_linear -= (-Vrc)*q[n-1];
      }
      f[i] = f_linear - K0*q[i] - t_ijk*q[i]*q[i] - t_ijkl*q[i]*q[i]*q[i];
   }

  fric_left = 0.0;                      /* compute int Sigma(t-t') q(t') dt' */
  fric_right = 0.0;                            /* so-called frictional force */
  for(j = 0; j < length_kernel; ++j) {            /* simple rectangular rule */
     i = (ipt_now-j+length_kernel)%length_kernel;
     fric_left += self_left[j] * q_past_left[i];
     fric_right += self_right[j] * q_past_right[i];
  }

  lead_F_left = -fric_left*h + eta_left[ipt_eta]; 
  lead_F_right = -fric_right*h + eta_right[ipt_eta];
  f[0] += lead_F_left;                               /* add random force eta */
  f[n-1] += lead_F_right;
  ++ipt_eta;

  assert(ipt_eta <= length_FFT);
}


/*	Perform a second-order symplectic step using the algorithm
		p- = p + h/2 f(q)
		q^ = q + h/m p-
		p^ = p- + h/2 f(q^)
	where p,q are old values, p^,q^ are new values, and p- is
	the half-size intermediate value, f is force.  All of them
        are vectors of dimension n (the number of degrees of freedom).
        h is step size, m is mass of the particles.
        Note that we don't need to calculate the force twice.  We can
        use the old value f in the previous call to this subroutine.
        [force() must be called at least once first]. The algorithm
	is also called velocity Verlet.
       
        To handle heat-baths, we add extra force to the 0th and (n-1)th
        particle of the form
               -int_{-inf}^t Sigma(t-t') q(t') dt' + eta(t)
        where eta(t) is colored noise satisfying
        beta < eta(t) eta(0) > = - int_{t}^{inf} Sigma(t') dt', t>0.
        This is done in the force calculation.

        Quantum noises corresponding to Bose-Einstein distribution of
        semi-infinite 1D harmonic chains are used.  See baths/qbath.f90.
*/

void symplectic(real p[], real q[], real f[], int n)
{
  real hh;
  int i;

  hh = 0.5*h;
  for (i = 0; i < n; ++i) {
    p[i] += hh * f[i];
  }
                         
  for(i = 0; i < n; ++i) {
    q[i] = q[i] + h * p[i]/Mass; 
  }

  ipt_now = (ipt_now + 1) % length_kernel;
  q_past_left[ipt_now] = q[0];              /* ipt_now contains valid entry */
  q_past_right[ipt_now] = q[n-1];                   /* force() need q_past_ */

  force(q,f,n);                   /* force f includes the stochastic forces */

  for (i = 0; i < n; ++i) {
    p[i] += hh * f[i];
  }
}


                                           /* 64-bit random number generator */
                 /* from Knuth "Art of Computer Programming Vol 2", page 108 */
static unsigned long long int x = 1;

double drand64(void) 
{
   x = 6364136223846793005ll * x + (long long int) 1;
   return (double) x * 5.4210108624275218e-20; 
}

void srand64(int seed)
{
   assert(sizeof(long long int) == 8);
   x = seed;
}


/* Do FFT to compute noise in time domain from the spectrum,
   len: FFT grid points, N is size for noise[] array, 
   d_omega is omega spacing.  Temperature is implicitly contained
   in the noise spectra.

   The spacing in omega is not consistent with the step size h,
   since we want to generate a large number of points in t, we 
   linearly interpolate the spectrum function. 
*/

#include <fftw3.h>

void get_noise(real noise[], int N, real d_omega, real eta[], int len)
{
   fftw_complex *eta_w, *eta_t;
   fftw_plan p;
   real r1, r2, y, a, b, var, noise_val;
   real w, dw, r;
   int i, j;

   eta_w = (fftw_complex *) fftw_malloc(sizeof(fftw_complex) * len);
   eta_t = (fftw_complex *) fftw_malloc(sizeof(fftw_complex) * len);

   assert(eta_w != NULL);
   assert(eta_t != NULL);
   assert(len == length_FFT);

   /* forward is exp(-iwt) i.e., omega to t, must do plan first */
   p = fftw_plan_dft_1d(len, eta_w, eta_t, FFTW_FORWARD, FFTW_ESTIMATE);

   /* for discrete value in omega space, <eta_k eta_{-k}> = noise_k h len,
      but fourier transform 1/(2pi) int dw gives a factor 1/(h len)
    */
   dw = 2.0*M_PI/(h*len);

   for(i = 1; i <len/2; ++i) {
      w = i * dw;                              /* omega needed in simulation */
      r = w/d_omega;
      j = (int) r;                                /* location in array noise */
      if(j < N-1) {
         r -= j;                                    /* do linear interpolate */
         noise_val = (1.0-r)*noise[j] + r*noise[j+1];  
      } else {
         noise_val = 0.0;
      }
      var = 0.5 * noise_val / (h * len); 
      r1 = drand64();
      r2 = drand48();
      y = sqrt(-2.0*log(r1)*var);                 /* box-muller for gaussian */
      a = y*cos(2*M_PI*r2);
      b = y*sin(2*M_PI*r2);
      eta_w[i][0] = a;
      eta_w[i][1] = b;
   }
   eta_w[0][0] = 0.0;              /* make sure the average of noise is zero */
   eta_w[0][1] = 0.0;
   eta_w[len/2][0] = 0.0;                            /* len/2 has no partner */
   eta_w[len/2][1] = 0.0;
   for(i = len/2+1; i < len; ++i) {    /* set according to eta_{-k} = eta_k* */
      eta_w[i][0] = eta_w[len-i][0];
      eta_w[i][1] = -eta_w[len-i][1];
   }
   fftw_execute(p);
                                    /* integration factor taking care in var */
   for(i = 0; i < len; ++i) {
      eta[i] = eta_t[i][0];                                /* eta(t) is real */
   }

   fftw_destroy_plan(p);
   fftw_free(eta_w);
   fftw_free(eta_t);
}


/* Internal units for computation:
   energy - eV  (electron volt),  E0 = 1 eV
   length - A0  (Angstrom),       u0 = 1 sqrt(amu) A0 = q[i]
   mass   - amu (atomic mass unit), (carbon is 12)
   time   - t0 = u0 sqrt(1/E0) = 1.018 x 10^(-14) sec
   k_B*temperature - eV, T0 = 1 eV/k_B = 11604 Kelvin
   conductance - lambda0 = 1 (eV/t0/T0) = 1.356 nano-watts/Kelvin

   eV = 1.6022 x 10^(-19) joule
   k_B = 1.3807 x 10^(-23) joule/K
   amu = 1.6605 x 10^(-27) kg
   hbar = 1.0546 x 10^(-34) m^2kg/s
*/

int main(int argc, char **argv)
{
  const real cof_eV_to_Kelvin = 11604.5;
  const real cof_to_nW = 1.356;
  real cof;
  real *p, *q, *f, *J;
  real *pav, *Jav;
  real *noise_left, *noise_right;            /* noise spectra in frequencies */
  real E0, E, Ek, Ep, Tav, Eav, E2av;
  real dE_low, dE_high;
  real jpass, jpass2, Jtot, norm;
  real T_begin, T_end, T, alpha;
  real D_omega;
  int n, i, mdstep, cnt, MAX, MAX10, MAX_pass, pass, len;
  int no_T_points, N_noise;
  double d, d1, d2, d3, dt, r1, r2, Ti;
  FILE *prompt_file, *in_file, *out_file, *lead_file;
  char filename_left[80], filename_right[80];             /* files for sigma */
  char filename_noise_left[80], filename_noise_right[80];
  char tmp_s[101];

  prompt_file = stdout;
  in_file = stdin;
  out_file = stdout;

  if(argc > 1) {        /* command line: a.out, or a.out in, or a.out in out */
    prompt_file = stderr;
    in_file = fopen(argv[1], "r");
    assert(in_file != NULL);
  }
  if(argc > 2) {
    out_file = fopen(argv[2], "w");
    assert(out_file != NULL);
  }

  fprintf(prompt_file,"enter number of particles of the center " );
  fscanf(in_file, "%d", &n);
  fprintf(prompt_file,"enter coupling Kc, K0, V^LC, V^RC [in eV/(amu A0^2)] ");
  fscanf(in_file, "%lf%lf%lf%lf", &d, &d3, &d1, &d2); 
  Kc = d;
  K0 = d3;
  Vlc = d1;
  Vrc = d2;
  fprintf(prompt_file,"enter onsite coupling t=t_{ijk} [in eV/(amu^(3/2) A0^3)] ");
  fscanf(in_file, "%lf", &d); 
  t_ijk = d;
  fprintf(prompt_file,"enter onsite coupling mu=t_{ijkl} [in eV/(amu^2 A0^4)] ");
  fscanf(in_file, "%lf", &d); 
  t_ijkl = d;
  fprintf(prompt_file,"enter Mass [in Mass of the particle, must be 1] ");
  fscanf(in_file, "%lf", &d); 
  Mass = d;
  if(Mass != 1.0) {
     fprintf(prompt_file,"Warning: the effect of mass is absorbed in the force constant so it must be 1!\n");
  }
  fprintf(prompt_file,"enter temperature T [in eV/k_B] ");
  fscanf(in_file, "%lf", &d); 
  T_begin = d;
//  fprintf(prompt_file,"enter temperature T_end [in Kelvin] ");
//  fscanf(in_file, "%lf", &d); 
//  T_end = d/cof_eV_to_Kelvin;
  fprintf(prompt_file,"enter alpha (so that T_low/high = T (1-/+alpha)) ");
  fscanf(in_file, "%lf", &d); 
  alpha = d;
//  fprintf(prompt_file,"enter number of points for temperature sampling ");
//  fscanf(in_file, "%d", &no_T_points); 
  no_T_points = 1;
  T = T_begin;
  T_low = T * (1.0 - alpha);
  T_high = T * (1.0 + alpha);
  fprintf(prompt_file,"enter MD step size h [in units of 1.018x10^(-14) sec] ");
  fscanf(in_file, "%lf", &d); 
  h = d;
  fprintf(prompt_file,"enter power X, such that number of MD steps is 2^X ");
  fscanf(in_file, "%d", &MAX); 
  MAX = pow(2.0, (double) MAX);
  fprintf(prompt_file,"enter maximum number of passes MAX_pass ");
  fscanf(in_file, "%d", &MAX_pass);
  fprintf(prompt_file,"enter left lead self-energy filename ");
  fscanf(in_file, "%s", filename_left);
  fprintf(prompt_file,"enter left lead noise spectrum filename ");
  fscanf(in_file, "%s", filename_noise_left);
  fprintf(prompt_file,"enter right lead self-energy filename ");
  fscanf(in_file, "%s", filename_right);
  fprintf(prompt_file,"enter right lead noise spectrum filename ");
  fscanf(in_file, "%s", filename_noise_right);
  fprintf(prompt_file,"\n");
  fclose(in_file);


  fprintf(out_file, "# Cubic/quartic onsite model\n");
  fprintf(out_file, "# N= %d, Kc= %g K0= %g V^LC= %g V^RC= %g (eV/amu A^2)\n", 
                    n, (double) Kc, (double) K0, (double) Vlc, (double) Vrc);
  fprintf(out_file, "# t_{ijk}= %g (eV/amu^(3/2)A^3), t_{ijkl}= %g (eV/(amu^2 A^4)), Mass= %g\n",
                    (double) t_ijk, (double) t_ijkl, (double) Mass);
  fprintf(out_file, "# sizeof(real)= %d, h= %g (10^(-14)sec), MD steps MAX= %d,  MAX_pass= %d\n", 
                    sizeof(real), (double) h, MAX, MAX_pass);
  fprintf(out_file, "# T_begin= %g (eV/k_B), T_end= %g (eV/k_B), alpha= %g\n",
                       (double) T_begin, (double) T_end, (double) alpha);
  fprintf(out_file, "# left lead self-energy reading from %s:\n", filename_left);

  lead_file = fopen(filename_left, "r");
  assert(lead_file != NULL);
                                                  /* read in specific format */
  fgets(tmp_s, 100, lead_file);                   /* header line for k00 etc */
  fputs(tmp_s, out_file);
  fgets(tmp_s, 100, lead_file);                       /* second line with dt */
  fputs(tmp_s, out_file);
  sscanf(tmp_s, "# dt= %lf array_length/2= %d", &dt, &length_kernel);
  if( fabs(dt -h) > 1.0e-6) {
      fprintf(prompt_file, "left lead dt != h, abort!\n");
      exit(1);
  }
  self_left = malloc(length_kernel*sizeof(real));
  assert(self_left != NULL);
  for(i = 0; i < length_kernel; ++i) {
     fscanf(lead_file, "%lf%lf", &dt, &d);
     self_left[i] = d;
  }
  fclose(lead_file);

  fprintf(out_file, "# left lead noise spectrum reading from %s:\n", filename_noise_left);
  lead_file = fopen(filename_noise_left, "r");
  assert(lead_file != NULL);
  fgets(tmp_s, 100, lead_file);                   /* header line for k00 etc */
  fputs(tmp_s, out_file);
  fgets(tmp_s, 100, lead_file);                        /* second line with T */
  fputs(tmp_s, out_file);
  sscanf(tmp_s, "# T= %lf", &d);
  assert( fabs(d - T_low) < 0.0001);               /* stop if T inconsistent */
  fgets(tmp_s, 100, lead_file);                        /* third line with dw */
  fputs(tmp_s, out_file);
  sscanf(tmp_s, "# dw= %lf N_noise= %d", &d, &N_noise);
  D_omega = d;
  noise_left = malloc(N_noise*sizeof(real));
  assert(noise_left != NULL);
  for(i = 0; i < N_noise; ++i) {
     fscanf(lead_file, "%lf%lf", &dt, &d);
     noise_left[i] = d;
  }
  fclose(lead_file);

  fprintf(out_file, "#\n# right lead self-energy reading from %s:\n", filename_right);
  lead_file = fopen(filename_right, "r");                /* right lead sigma */
  assert(lead_file != NULL);
  fgets(tmp_s, 100, lead_file);                 
  fputs(tmp_s, out_file);
  fgets(tmp_s, 100, lead_file);              
  fputs(tmp_s, out_file);
  sscanf(tmp_s, "# dt= %lf array_length/2= %d", &dt, &i);

  if( fabs(dt -h) > 1.0e-6) {
      fprintf(prompt_file, "right lead dt != h, abort!\n");
      exit(1);
  }
  if(i != length_kernel) {
      fprintf(prompt_file, "right lead data length must be the same as left!\n");
      exit(1);
  }
  self_right = malloc(length_kernel*sizeof(real));
  assert(self_right != NULL);
  for(i = 0; i < length_kernel; ++i) {
     fscanf(lead_file, "%lf%lf", &dt, &d);
     self_right[i] = d;
  }
  fclose(lead_file);

  fprintf(out_file, "# right lead noise spectrum reading from %s:\n", filename_noise_right);
  lead_file = fopen(filename_noise_right, "r");
  assert(lead_file != NULL);
  fgets(tmp_s, 100, lead_file);                   /* header line for k00 etc */
  fputs(tmp_s, out_file);
  fgets(tmp_s, 100, lead_file);                        /* second line with T */
  fputs(tmp_s, out_file);
  sscanf(tmp_s, "# T= %lf", &d);
  assert( fabs(d - T_high) < 0.0001);              /* stop if T inconsistent */
  fgets(tmp_s, 100, lead_file);                        /* third line with dw */
  fputs(tmp_s, out_file);
  sscanf(tmp_s, "# dw= %lf N_noise= %d", &d, &i);
  if( fabs(d - D_omega) > 1.0e-6) {
      fprintf(prompt_file, "right lead dw != left dw, abort!\n");
      exit(1);
  }
  if(i != N_noise) {
      fprintf(prompt_file, "right lead N_noise must be the same as left!\n");
      exit(1);
  }
  noise_right = malloc(N_noise*sizeof(real));
  assert(noise_right != NULL);
  for(i = 0; i < N_noise; ++i) {
     fscanf(lead_file, "%lf%lf", &dt, &d);
     noise_right[i] = d;
  }
  fclose(lead_file);

  fprintf(out_file, "#\n# T (Kelvin)   kappa_bar (nW/K)    error\n");
  fflush(out_file);

  p = malloc(n*sizeof(real));                           /* memory for arrays */
  q = malloc(n*sizeof(real));
  f = malloc(n*sizeof(real));
  J = malloc(n*sizeof(real));
  Jav = malloc(n*sizeof(real));
  pav = malloc(n*sizeof(real));
  assert(p != NULL);
  assert(q != NULL);
  assert(f != NULL);
  assert(J != NULL);
  assert(Jav != NULL);
  assert(pav != NULL);
  eta_left = malloc(MAX*sizeof(real));
  eta_right = malloc(MAX*sizeof(real));
  assert(eta_left != NULL);
  assert(eta_right != NULL);
  q_past_left = calloc(length_kernel, sizeof(real));
  q_past_right = calloc(length_kernel, sizeof(real));
  assert(q_past_left != NULL);
  assert(q_past_right != NULL);

  srand48(time(NULL));
  srand64(time(NULL));

  for(i = 0; i < n; ++i) {
     r1 = drand48();
     r2 = drand64();
     Ti = T_low + i*(T_high-T_low)/n;
     p[i] = sqrt(-2.0*log(r1)*Mass*Ti)*cos(2*M_PI*r2);         /* box-muller */
     q[i] = 0.4*sqrt(Ti/Kc)*(2.0*drand48()-1.0);
  }

  len = MAX;
  length_FFT = MAX;

Next_T:
  T_low = T * (1.0 - alpha);
  T_high = T * (1.0 + alpha);
  get_noise(noise_left, N_noise, D_omega, eta_left, len);
  get_noise(noise_right, N_noise, D_omega, eta_right, len);
  ipt_eta = 0;                                       /* pointer start from 0 */

/*    We must calculate the force once before start, because it is needed 
      for the first call of symplectic().  Otherwise the force f would have 
      not been defined and cause error.  force() need the noise.
*/
  force(q,f,n);

  for(mdstep = 1; mdstep < MAX; ++mdstep) {                   /* equilibrate */
     symplectic(p,q,f,n);
  }

  Eav = 0.0;                  
  E2av = 0.0;
  dE_low = 0.0;                   /* energy pumped in/out of the center part */
  dE_high = 0.0;
  Tav = 0.0;
  for(i = 0; i < n; ++i) {
    pav[i] = 0.0;
    Jav[i] = 0.0;
  }
  Ek = kinetic(p,n);          
  Ep =  potential(q,n);
  E0 = Ek + Ep;

  jpass = 0.0;                                            /* sum j over pass */
  jpass2 = 0.0;                                         /* sum j^2 over pass */
  MAX10 = MAX/10;
  for(pass = 1; pass <= MAX_pass; ++pass) {
                                        /* each pass uses a new random noise */
    get_noise(noise_left, N_noise, D_omega, eta_left, len);
    get_noise(noise_right, N_noise, D_omega, eta_right, len);
    ipt_eta = 0;
    Jtot = 0.0;
    for(mdstep = 0; mdstep < MAX10; ++mdstep) {
       symplectic(p,q,f,n);            /* omit 10 percents for equilibration */
    }
    for(mdstep = MAX10; mdstep < MAX; ++mdstep) { 
       symplectic(p,q,f,n);
       Ek = kinetic(p,n);
       Ep =  potential(q,n);
       E = Ek + Ep;
       Eav += E;
       E2av += E*E;
       Tav += Ek;
       flux(p, q, J, n);
       for(i = 0; i < n; ++i) {
          pav[i] += p[i]*p[i];
          Jav[i] += J[i];
       }
       for(i = 1; i < n-2; ++i) {                           /* skip the ends */
          Jtot += J[i];
       }
       dE_low += p[0] * lead_F_left;
       dE_high += p[n-1] * lead_F_right;
    }

    cnt = n - 3;
    if(cnt > 0) {
       Jtot = Jtot/(MAX-MAX10)/cnt;
    }
    jpass += Jtot;
    jpass2 += Jtot*Jtot;
  }                                                              /* end pass */
  if(T_low != T_high) {
     cof = cof_to_nW/(T_low-T_high);               /* internal units to nW/K */
  } else {
     cof = 1.0;
  }
  fprintf(out_file, "%g   %g ",  (double) (cof_eV_to_Kelvin*T), (double) (cof*jpass/MAX_pass)); 
  if (MAX_pass > 1) { 
    fprintf(out_file, "  %g\n",  (double) (
      -cof*sqrt((jpass2/MAX_pass - (jpass/MAX_pass)*(jpass/MAX_pass))/(MAX_pass-1)) ) );
  } else {
    fprintf(out_file, "\n"); 
  }
  fflush(out_file);

//  if(no_T_points > 1 && T < T_end) { 
//     T += (T_end - T_begin)/(no_T_points-1);
//     T = T * sqrt(10.0);
//     if(T <= T_end) goto Next_T;
//  }

  norm = (1.0/(MAX-MAX10))/ ((real) MAX_pass);
  Tav = 2.0*Tav*norm/n;                               /* <p^2/2m> = (1/2) kT */
  Eav *= norm;
  E2av = (E2av*norm - Eav*Eav)/n/n;
  if(E2av > 0.0) {
    E2av = sqrt(E2av);
  }
  dE_low = dE_low*norm/Mass;
  dE_high = dE_high*norm/Mass;

  Jtot = 0.0;                         /* exclude baths and one more particle */
  cnt = 0; 
  for(i = 1; i < n-2; ++i) {
     Jtot += Jav[i];
     ++cnt;
  }
  if(cnt > 0) {
     Jtot = Jtot*norm/cnt;
  }

  fprintf(out_file, "E=%g   <H>=%g   dH=%g  T=%g\n", (double) E,
                    (double) (Eav/n), (double) E2av, (double) (Tav*cof_eV_to_Kelvin)); 
  fprintf(out_file, "<j> = %g, dE(-)/dt= %g, dE(+)/dt= %g\n", 
                     (double) Jtot, (double) dE_low, (double) dE_high);
  fprintf(out_file, 
          "atom no  temperature (Kelvin)  conductance I/(T_high-T_low)(nW/K)\n");
  for(i = 0; i < n; ++i) {
    fprintf(out_file, "%5d     %10g   %10g\n", i,
            (double) (cof_eV_to_Kelvin*pav[i]*norm/Mass), (double) (cof*Jav[i]*norm) ); 
  }
  fclose(out_file);
  return 0;
}
